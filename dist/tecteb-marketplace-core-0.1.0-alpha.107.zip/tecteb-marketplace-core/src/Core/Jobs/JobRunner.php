<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Core\Jobs;

use Tecteb\Marketplace\Contracts\JobRepositoryInterface;

/**
 * Claims a job, runs exactly one batch, writes the checkpoint, lets go.
 *
 * The shape is the point. The runner does not loop until the queue is empty,
 * because the process it runs in has a time limit it does not know; it does one
 * batch and returns, and something — cron, a second visitor, a manager pressing
 * «اجرا» — calls it again. Everything about resuming then follows from the fact
 * that there was never a long-running loop to interrupt.
 *
 * Three failure modes and three different answers, which is why this is not a
 * try/catch around a while loop:
 *
 *  - **The handler says the work is wrong** (`JobBatch::failed`). The job stops
 *    in `failed` with the reason. It is not retried: the same instruction would
 *    be wrong the same way.
 *  - **The handler throws.** Same as above, with the exception message as the
 *    reason — a throw is a handler that did not consider this case, and
 *    replaying it silently would hide that.
 *  - **The process dies.** No batch comes back at all, nothing is written, and
 *    the lease simply expires. The next worker claims the job and re-runs the
 *    last cursor. That is why `step()` has to be idempotent against its cursor:
 *    work may have been done between the last checkpoint and the death.
 *
 * The lease is extended by every checkpoint, so a handler that keeps making
 * progress keeps its job, and one that stalls loses it to a worker that can.
 *
 * **And a batch is not the unit of checkpointing.** The runner hands the
 * handler a `$checkpoint` closure, so a handler whose units are expensive
 * records each one as it lands. Without that, «the process dies» above is only
 * half true: nothing is written, yes — but the work already done is written to
 * the SITE and not to the row, so the next worker repeats a page it cannot
 * finish and the progress figure stands still while products arrive. That is
 * what `alpha.71` did on staging, and `JobHandlerInterface::step()` carries the
 * measurement.
 */
final class JobRunner
{
    public const DEFAULT_LEASE = 300;

    /** @var array<string,JobHandlerInterface> */
    private array $handlers = [];

    /**
     * @param ?\Closure(): JobBudget $budgetFactory one budget per `run()`, not
     *        per batch: the thing being rationed is this REQUEST's time, and
     *        a cron tick asking for five batches must not get five budgets.
     *        `null` reads PHP's own limit — see `JobBudget::forRequest()` for
     *        why that is only part of the answer.
     */
    public function __construct(
        private readonly JobRepositoryInterface $jobs,
        private readonly \Closure $tokenFactory,
        private readonly int $leaseSeconds = self::DEFAULT_LEASE,
        private readonly ?\Closure $budgetFactory = null
    ) {
    }

    public function register(JobHandlerInterface $handler): void
    {
        $this->handlers[$handler->type()] = $handler;
    }

    /** @return list<string> */
    public function types(): array
    {
        return array_keys($this->handlers);
    }

    public function handles(string $type): bool
    {
        return isset($this->handlers[$type]);
    }

    /**
     * Run up to `$batches` batches, stopping early when nothing is due.
     *
     * @return list<array{job:int, type:string, outcome:string, done:int, failed:int, error:string, checkpoints?:int}>
     */
    public function run(int $batches = 1): array
    {
        $budget = $this->budgetFactory !== null
            ? ($this->budgetFactory)()
            : JobBudget::forRequest((int) ini_get('max_execution_time'));
        $results = [];
        for ($i = 0; $i < max(1, $batches); $i++) {
            // ⛔ Asked BEFORE claiming, not after: claiming a job and then
            // finding there is no time for it would take the lease for three
            // hundred seconds and do nothing with it — the exact cost this
            // budget exists to stop paying.
            if ($i > 0 && $budget->exhausted()) {
                break;
            }
            $result = $this->runOne($budget);
            if ($result === null) {
                break;
            }
            $results[] = $result;
        }
        return $results;
    }

    /** @return array{job:int, type:string, outcome:string, done:int, failed:int, error:string, checkpoints?:int}|null */
    public function runOne(?JobBudget $budget = null): ?array
    {
        if ($this->handlers === []) {
            return null;
        }
        $token = (string) ($this->tokenFactory)();
        $job = $this->jobs->claim($this->types(), $token, $this->leaseSeconds);
        if ($job === null) {
            return null;
        }

        $handler = $this->handlers[$job->type] ?? null;
        if ($handler === null) {
            // Claimed a type we no longer serve — a downgrade, or a renamed
            // handler. Put it back rather than failing somebody else's job.
            $this->jobs->release($job->id, $token);
            return ['job' => $job->id, 'type' => $job->type, 'outcome' => 'no_handler', 'done' => 0, 'failed' => 0, 'error' => ''];
        }

        // The handler's own checkpoint, so the cursor follows the WORK rather
        // than the page. Everything it records is counted here and not again
        // by the final checkpoint below, and a `false` tells the handler the
        // lease is gone — at which point it must stop rather than keep writing
        // over somebody else's job.
        $lost = false;
        $recorded = 0;
        $checkpoint = function (array $cursor, int $done = 0, int $failed = 0, int $total = 0) use ($job, $token, &$lost, &$recorded): bool {
            if ($lost) {
                return false;
            }
            $kept = $this->jobs->checkpoint($job->id, $token, $cursor, $done, $failed, $total, $this->leaseSeconds);
            if (!$kept) {
                $lost = true;
                return false;
            }
            $recorded++;
            return true;
        };

        // The unit-of-work gate, beside the checkpoint rather than instead of
        // it: the checkpoint is how a handler says where it is, and this is
        // how it writes anything that must not outlive its hold on the job.
        //
        // ⛔ `$lost` is read here too, so a handler that has already been
        // refused once cannot get a second write in by taking this door.
        $underLease = function (\Closure $write) use ($job, $token, &$lost): string {
            if ($lost) {
                return 'lease_lost';
            }
            $answer = $this->jobs->writingUnderLease($job->id, $token, $write);
            if ($answer === 'lease_lost') {
                $lost = true;
            }
            return $answer;
        };

        try {
            $batch = $handler->step($job, $checkpoint, $underLease, $budget);
        } catch (\Throwable $e) {
            $this->jobs->finish($job->id, $token, JobStatus::Failed, 'exception: ' . $e->getMessage());
            return ['job' => $job->id, 'type' => $job->type, 'outcome' => 'failed', 'done' => 0, 'failed' => 0, 'error' => $e->getMessage()];
        }

        // The checkpoint goes in first in every case, including failure: what a
        // failing batch did before it gave up is still done, and re-doing it
        // would be the duplicate this table exists to prevent.
        $kept = $this->jobs->checkpoint(
            $job->id,
            $token,
            $batch->cursor,
            $batch->done,
            $batch->failed,
            $batch->total,
            $this->leaseSeconds
        );
        if (!$kept || $lost) {
            // The lease expired mid-batch and somebody else owns this now. Say
            // so rather than writing over their work — and say it even when
            // the FINAL write would have landed, because a mid-batch
            // checkpoint that was refused means the rest of this batch was
            // written by whoever holds the job now.
            return ['job' => $job->id, 'type' => $job->type, 'outcome' => 'lease_lost', 'done' => 0, 'failed' => 0, 'error' => ''];
        }

        if ($batch->isFailure()) {
            $this->jobs->finish($job->id, $token, JobStatus::Failed, $batch->error);
            $outcome = 'failed';
        } elseif ($batch->more) {
            $this->jobs->release($job->id, $token);
            $outcome = 'more';
        } else {
            $this->jobs->finish($job->id, $token, JobStatus::Done, '');
            $outcome = 'done';
        }

        return [
            'job' => $job->id,
            'type' => $job->type,
            'outcome' => $outcome,
            'done' => $batch->done,
            'failed' => $batch->failed,
            'error' => $batch->error,
            // How many times the handler checkpointed inside this batch. A
            // handler with expensive units should never report zero here, and
            // the evidence asserts it.
            'checkpoints' => $recorded,
        ];
    }
}
