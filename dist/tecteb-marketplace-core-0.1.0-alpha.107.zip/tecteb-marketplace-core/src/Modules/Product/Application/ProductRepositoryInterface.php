<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Application;

use Tecteb\Marketplace\Modules\Product\Domain\ApprovedBaseline;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\ProductCreation;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\ProductSeo;
use Tecteb\Marketplace\Modules\Product\Domain\ProductSort;
use Tecteb\Marketplace\Modules\Product\Domain\LinkOwnership;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;

/**
 * Product persistence.
 *
 * Every read that a vendor can reach takes the owner as an argument rather
 * than trusting the caller to filter afterwards: the query itself is scoped,
 * so a forgotten `if` cannot leak another shop's catalogue (AC-PRIV).
 */
interface ProductRepositoryInterface
{
    public function find(int $productId): ?Product;

    /** The same row, but only if it belongs to this vendor. */
    public function findOwned(int $productId, int $vendorUserId): ?Product;
    /**
     * These products, in ONE read, keyed by id.
     *
     * For a page whose row identities came from somewhere else — from
     * `alpha.56` the unified catalogue list is a union over WooCommerce posts
     * and marketplace rows, so the marketplace half of a page arrives as a
     * list of ids. `find()` per row would be twenty statements for one
     * screen, which is the cost this list was rebuilt to put a ceiling on.
     *
     * An id with no row is simply absent from the answer: a row that is not
     * there is not an error here, it is half of a pair.
     *
     * @param list<int> $productIds
     * @return array<int,Product>
     */
    public function findMany(array $productIds): array;


    /**
     * @param string $search matched against title and SKU; empty means no filter
     * @return list<Product>
     */
    public function forVendor(
        int $vendorUserId,
        ?ProductStatus $status = null,
        int $limit = 200,
        int $offset = 0,
        string $search = ''
    ): array;

    public function countForVendor(int $vendorUserId, ?ProductStatus $status = null, string $search = ''): int;

    /** @return array<string,int> status value => count, for the vendor's filter chips */
    public function countsByStatus(int $vendorUserId): array;

    /** @return list<Product> the manager's review queue, newest request first */
    public function inStatus(ProductStatus $status, int $limit = 200, int $offset = 0): array;

    /**
     * The manager's catalogue — every shop, every status, searchable.
     *
     * `inStatus(Submitted)` was the only manager-facing read, so a product
     * that had been decided any way at all disappeared from the marketplace
     * admin while its WooCommerce post carried on existing. There is no new
     * status here and no second copy of one: the marketplace status is the
     * column it has always been, and the shop's own status is READ from
     * WordPress at render time rather than mirrored into a column that could
     * then be wrong.
     *
     * **The limit is in the query.** `$limit`/`$offset` are a real `LIMIT` and
     * a real `OFFSET`, so a catalogue of two hundred products reads twenty
     * rows; a page that fetched everything and hid the rest with CSS would
     * still cost every row, every image lookup and every store name.
     *
     * @param ?ProductSort $sort                null means the default order
     * @param bool         $onlyNeedsReview narrow the list to products that
     *                                      NEED REVIEW, by the one definition
     *                                      `ReviewQueueSql::waiting()` holds:
     *                                      submitted, or carrying an
     *                                      unanswered change proposal, or
     *                                      carrying an open brand request.
     *                                      The badge, the counter, this filter
     *                                      and its pager all read that one
     *                                      fragment, so they cannot describe
     *                                      different sets — which is exactly
     *                                      what they did until `alpha.48`.
     * @return list<Product>
     */
    public function forManager(
        ?ProductStatus $status = null,
        string $search = '',
        int $limit = 20,
        int $offset = 0,
        int $vendorUserId = 0,
        ?ProductSort $sort = null,
        bool $onlyNeedsReview = false
    ): array;

    public function countForManager(
        ?ProductStatus $status = null,
        string $search = '',
        int $vendorUserId = 0,
        bool $onlyNeedsReview = false
    ): int;

    /**
     * The same page of rows, each with the identity of the submission on it.
     *
     * **One statement, and that is the whole point.** The red count on the menu
     * is per manager and cleared by opening the list, so the page has to record
     * WHICH submission it showed. Read in a second query, that token could be
     * newer than the row above it — a vendor submitting between the two reads
     * would have their submission counted as seen by somebody who was looking at
     * the previous one. Selected as part of the row, there is no «between».
     *
     * The token names a submission out of the two APPEND-ONLY trails that
     * already record one: the newest `submitted` row of the decision trail, and
     * the id of the unanswered proposal. It is deliberately not the status and
     * not `updated_at` — an edited price must not look like a new submission,
     * and a resubmission of an unchanged product must.
     *
     * @return list<array{product:Product, submission:string}>
     */
    public function forManagerWithSubmission(
        ?ProductStatus $status = null,
        string $search = '',
        int $limit = 20,
        int $offset = 0,
        int $vendorUserId = 0,
        ?ProductSort $sort = null,
        bool $onlyNeedsReview = false
    ): array;

    /**
     * One product, its pending proposal and its submission identity — together.
     *
     * The detail page's half of the one-statement rule. Reading the product, the
     * proposal and the token separately leaves a window: a submission arriving
     * between the first read and the last lets the page show the previous
     * content while recording the newer identity as seen. `revisionId` names the
     * exact proposal the identity refers to, so the caller can load that
     * proposal BY ID rather than asking again for «the pending one».
     *
     * @return array{product:Product, submission:string, revisionId:int, waiting:bool}|null
     */
    public function findWithSubmission(int $productId): ?array;

    /**
     * Which of these products are waiting, and under which submission.
     *
     * The badge's second read: the input is what one manager has already looked
     * at, so the query is bounded by that rather than by the size of the queue.
     * A product that has LEFT the queue is absent from the answer, which is how
     * a decided product stops subtracting from a count it is no longer part of.
     *
     * @param list<int> $productIds
     * @return array<int,string> product id => submission token
     */
    public function submissionsOf(array $productIds): array;

    /**
     * How many products are in each status, under the same filter.
     *
     * One GROUP BY, so no two numbers on the page can come from two moments.
     *
     * @return array<string,int>
     */
    /**
     * How many products are waiting for the MANAGER, counted as products.
     *
     * A product waits when it has been submitted, or when the version live in
     * the shop has a proposed change nobody has answered. Both are one
     * decision on one product, so the count is of products and not of rows: a
     * submitted product that also carries a proposal is one thing to look at,
     * not two, and the badge that shows this number must not say otherwise.
     *
     * Drafts are not counted. A draft is the vendor's own work in progress and
     * has not been handed to anybody.
     */
    public function countAwaitingReview(): int;

    public function countsByStatusForManager(
        string $search = '',
        int $vendorUserId = 0,
        bool $onlyNeedsReview = false
    ): array;

    public function countInStatus(ProductStatus $status): int;

    /** @return int the new product id, or 0 when the insert failed */
    /**
     * @param LinkOwnership $ownership whether this row will OWN the storefront
     *        product it is later linked to. Everything the marketplace's own
     *        flow creates is `Marketplace`; only a migration writes `Observed`.
     */
    /**
     * Create one product row — whole, in one statement.
     *
     * `$wcProductId` and `$importRunId` are parameters rather than follow-up
     * writes because a row that is half made is a row a resumed import cannot
     * recognise. See the implementation for the duplicate this prevents.
     *
     * `$mirroredStatus` is a parameter for the SAME reason, and the reason is
     * sharper here: it is what stops the first projection overwriting a
     * storefront status nobody in this marketplace decided, so a row that
     * exists without it for even one request is a row whose status the next
     * projection destroys. `''` means «not observed» — the answer for
     * everything the marketplace's own flow creates — and only an intake of
     * an existing WooCommerce product passes a value.
     */
    public function create(
        int $vendorUserId,
        ProductDetails $details,
        ProductStatus $status,
        LinkOwnership $ownership = LinkOwnership::Marketplace,
        ?int $wcProductId = null,
        string $importRunId = '',
        string $createToken = '',
        string $mirroredStatus = ''
    ): int;

    /**
     * The same insert, for the form path, saying whether THIS call made the row.
     *
     * An id alone cannot carry it. Two requests holding one `create_token`
     * both get past the «already made?» read, the unique key refuses one of
     * them, and the loser resolves to the winner's row — holding the same
     * integer the winner holds, with no way to tell that it did not create
     * it. It then wrote the gallery and the specifications over that row,
     * which on a replayed POST means over whatever has been edited since.
     *
     * `ProductCreation::$created` is what the caller hangs «write nothing to a
     * row I did not create» on.
     */
    public function createForForm(
        int $vendorUserId,
        ProductDetails $details,
        ProductStatus $status,
        string $createToken
    ): ProductCreation;

    /**
     * The id one submitted create form produced, or 0.
     *
     * `$createToken` is the one-time value a rendered create form carries, and
     * the products table has a unique key over `(vendor_user_id, create_token)`
     * so one form can only ever have made one product. A replayed POST — what
     * a browser sends after a request times out — therefore asks this instead
     * of creating a second row, and a deliberately-identical second product
     * comes from a freshly rendered form with a fresh token.
     */
    public function findByCreateToken(int $vendorUserId, string $createToken): int;

    /**
     * Write the details, refusing when `$expectedVersion` no longer matches.
     *
     * **A token this cannot compare is refused, not waived.** Pass the row's
     * counter, or `ProductRowVersion::UNGUARDED` to say in words that this
     * write is deliberately unchecked. An empty string is neither and returns
     * false — an omission must not become a silent unguarded write.
     *
     * The version has to reach the WHERE clause; an implementation that
     * compares it in PHP and then writes has reintroduced the race this
     * parameter exists to close. An empty string means «do not check», which is
     * what a form from an older build sends.
     */
    public function updateDetails(int $productId, ProductDetails $details, string $expectedVersion = ''): bool;

    /**
     * Take the version, atomically, without changing anything else.
     *
     * For the paths that do not write details — proposing a revision of a
     * published product, for instance — but still must not act on a view of the
     * product somebody else has already replaced. One statement, so exactly one
     * of two concurrent callers wins. An empty expectation succeeds: there is
     * nothing to compare against.
     */
    public function bumpVersion(int $productId, string $expectedVersion): bool;

    /** The row's current optimistic-lock counter, as the form should carry it. */
    public function rowVersion(int $productId): string;

    /**
     * Mark a row as created by an import run.
     *
     * The stamp lives on the row rather than in a manifest beside it, so a
     * process killed mid-import leaves nothing that no run claims.
     */
    public function stampImportRun(int $productId, string $runId): bool;

    /**
     * Remove one OBSERVED row that a named intake run created — and only such
     * a row.
     *
     * Every condition is in the `WHERE`, so this cannot be talked into
     * deleting anything else: the id, the run that stamped it, and
     * `link_ownership = observed`. A row somebody has since accepted into
     * marketplace management is not an intake's any more and is left standing
     * (the caller reports it); a row from another run is another run's to
     * undo.
     *
     * It deletes the marketplace row and the specification and image rows
     * that belong to it, and NOTHING in WooCommerce: not the product, not an
     * attachment, not an order line. It could not — this repository's only
     * tables are the marketplace's own, which is what makes «بازگشت نباید
     * محصول ووکامرس، رسانه یا سفارش را حذف کند» a property rather than a
     * promise.
     *
     * Unlike `deleteDraft()` it does not require the row to be a draft: an
     * intake mirrors WooCommerce's publish state, so most intaken rows are
     * `published` and a draft-only delete would leave every one of them
     * behind.
     *
     * @return string `''` when the row and every row of it went; otherwise
     *                the part that would not — `product_row`, `not_this_run`,
     *                `revisions`, `decisions`, `specs` or `images`. A `bool`
     *                could not say that, and `alpha.55` proved the cost:
     *                specs and images were deleted with their answers thrown
     *                away, so a half-emptied row reported success and a
     *                rollback that had kept a product reported it removed.
     *                The caller wraps the call in a transaction, so a named
     *                part is a whole unit undone rather than a deleted
     *                product with its images still in the table.
     */
    public function deleteObservedFromRun(int $productId, string $runId): string;

    /**
     * The OBSERVED rows an intake made, bounded — so «which intakes are half
     * written» is one statement rather than a walk over every run.
     *
     * Observed only, because a row somebody has accepted is not an intake's
     * any more; and stamped only, because a row with no run behind it was
     * not made by an intake at all.
     *
     * @return list<int>
     */
    public function observedFromImportRuns(int $limit = 200): array;

    /**
     * @return list<string> every import run the catalogue remembers, newest first
     *
     * Read from the rows, so a run whose process died before it could write a
     * manifest entry still appears — which is the whole point of the stamp.
     */
    public function importRunIds(): array;

    /** @return list<int> the products this run created, read from the rows */
    public function idsFromImportRun(string $runId): array;

    /**
     * The imported rows that are still waiting for a category — bounded, and
     * counted separately so an incomplete page says so.
     *
     * This is the half of «نگاشت دسته‌ها» that is readable on OUR side with
     * nothing else installed. An imported product whose source category
     * nobody had mapped was created with `category_key = ''` (see
     * `CategoryMap`), and that empty string is a fact in this table: it
     * survives Dokan being switched off, it is what keeps the product a
     * draft, and it is the only thing that changes when somebody finally
     * applies a mapping.
     *
     * ⛔ Asking Dokan instead — which is what `MigrationCompleteness` did
     * until `alpha.80` — answers a different question. Saving a mapping
     * empties Dokan's «unmapped» list immediately, while every row here
     * still carries the empty category; the gate went green and 184 products
     * stayed uncategorised. «صرف ذخیرهٔ option و سبز شدن وضعیت کافی نیست.»
     *
     * Stamped only (`import_run_id <> ''`): a row nobody imported is the
     * vendor's own draft and its empty category is the vendor's to fill on
     * the form, not a migration decision.
     *
     * ⛔ And «without a category» means NEITHER the key NOR a recorded set,
     * exactly as {@see self::countImportedWithoutCategory()} counts it. Until
     * `alpha.87` this list asked the key alone, so a multi-category product
     * whose whole WooCommerce relationship was recorded — which keeps
     * `category_key = ''` by design, because the single key is written only
     * for a one-term set — stayed on it for ever, and the card listed it as
     * «منتظر نگاشت» while the total beside it did not count it.
     *
     * @return list<array{id:int, vendor_user_id:int, wc_product_id:int, title:string}>
     */
    public function importedWithoutCategory(int $limit = 500): array;

    /**
     * How many of them there are — the whole number, with no `LIMIT`.
     *
     * A page that hit its cap cannot say «این‌همه مانده», and a report built
     * from `count($page)` is the `alpha.76` counter all over again. Pass a
     * vendor to scope it to one shop, which is how the completeness gate asks.
     *
     * ⛔ `-1` means the read failed. Nought here would read as «nothing left
     * to decide» and close a gate on a statement that never ran.
     */
    public function countImportedWithoutCategory(int $vendorUserId = 0): int;

    /**
     * How many imported rows have NO recorded category relationship at all —
     * the whole catalogue, no `LIMIT`, our own two tables only.
     *
     * This is a different question from {@see self::countImportedWithoutCategory()}
     * and the difference is the point. That one asks «the single key is empty
     * AND there is no link row», which is what the completeness gate needs; so
     * a row whose recorded set is a STRICT SUBSET of the product's real
     * categories — exactly the shape migration 35's backfill creates, one id
     * written from `category_key` on a product that carries three — reads there
     * as answered. This one counts the rows where nothing is recorded, so the
     * owner has one number to watch reach nought.
     *
     * ⛔ **Three answers, and `-1` is not nought.** `-1` means the question
     * could not be asked: the link table is absent (schema 34) or its read
     * failed. Nought would say «every imported row has a recorded
     * relationship», which is the one reading that must never come from a
     * statement that never ran (`alpha.67`).
     *
     * ⛔ **And it does not claim the recorded sets are COMPLETE.** Completeness
     * can only be judged against each product's own `product_cat` relationship,
     * which is a WooCommerce read and is done per page. A screen printing this
     * number has to say which question it answers.
     */
    public function countImportedWithoutCategorySet(): int;

    /**
     * Write a category onto a product THAT HAS NONE — the condition inside the
     * statement, never around it.
     *
     * `alpha.50`'s rule, one column over: a read that answers «this row has no
     * category» and then an unconditional write is two statements with a
     * window between them, and in that window a manager can have set the
     * category by hand on the product page. So `category_key = ''` is in the
     * `WHERE`, and what this method cannot do is overwrite a category anybody
     * chose — the marketplace's own included.
     *
     * Only that one column moves. Not the status, not the ownership, not the
     * price, not the stock, not the brand — which is why this exists instead
     * of `updateDetails()`: that one rewrites every detail column from
     * whatever the caller read a moment ago.
     *
     * ⛔ And a RECORDED SET is not a key this may replace. A multi-category
     * row keeps `category_key = ''`, so the «empty column» guard above is
     * satisfied by exactly the product that must not be written: measured on
     * `alpha.86`, the mapped id landed beside a recorded set that does not
     * contain it, and the key then named a category the product does not
     * have. The condition is in the statement (`alpha.50`), and a link table
     * that cannot be READ is a refusal rather than a write.
     *
     * @return string `''` when it was written; otherwise why not —
     *                `already_set` (a category is there and is not ours to
     *                replace), `category_set_recorded` (this product's own
     *                WooCommerce relationship is recorded, so the key would
     *                contradict it), `category_table_unreadable` (the set
     *                could not be asked about, and guessing is what this
     *                guard exists to stop), `not_found` (no such row),
     *                `bad_category` (an empty key is not a category),
     *                `not_imported` (the row exists and no import made it, so
     *                no migration decision reaches it) or `storage_failed`. A
     *                `bool` would fuse the first ones, and they are opposite
     *                answers: one is «somebody decided» and the other is
     *                «there is nothing here».
     */
    /**
     * Every imported row with the category key it currently carries.
     *
     * One read for BOTH populations, on purpose. `importedWithoutCategory()`
     * answers about rows whose key is empty — the 184 that came from Dokan
     * with nothing mapped. A product taken from the EXISTING WooCommerce
     * catalogue is not in that list: `ImportExistingProducts` stored
     * `category_ids[0]`, so its key is already set, and measured on
     * `alpha.80`'s bytes the whole waiting list was therefore empty
     * (`waiting_total=0`) while three real relationships sat unrecorded.
     *
     * ⛔ Two reads, one per population, would be two code paths answering one
     * question — and `alpha.79` is the round where two halves derived from the
     * same tables agreed until the first short read, with no test going red.
     * So the key comes back as DATA and one rule classifies it.
     *
     * Keyset pagination on `id`, because the caller walks the whole catalogue
     * and `OFFSET` on a moving table skips rows (`alpha.13`).
     *
     * @return list<array{id:int, vendor_user_id:int, wc_product_id:int, title:string, category_key:string}>
     */
    public function importedWithCategoryKeys(int $limit = 500, int $afterId = 0): array;

    /**
     * How many imported rows there are at all — no `LIMIT`, no filter.
     *
     * ⛔ `-1` means the read failed, for the same reason as
     * `countImportedWithoutCategory()`: nought would read as «there is
     * nothing to look at» and let a preview call itself complete
     * (`alpha.70`).
     */
    public function countImported(): int;

    public function setCategoryWhenEmpty(int $productId, string $categoryKey): string;

    /**
     * Record the storefront status an observed row never had — ONLY when it
     * has none.
     *
     * The stamp is what stops a projection writing a publish state nobody in
     * this marketplace decided (`alpha.67`). Migration 38 fills it for every
     * imported row whose WooCommerce product still exists; this is the path
     * for the rest — a row whose product was unreadable when the migration
     * ran, or one imported by an older package after the migration.
     *
     * ⛔ **«Only when it has none» is in the `WHERE`, not in a read before
     * it** (`alpha.50`). The reason is not concurrency alone: a stamp that is
     * ALREADY there may have been cleared and re-set by `updateStatus()` when
     * a human made a decision, and overwriting it would hold open a status
     * that person deliberately released. The statement therefore cannot
     * overwrite one, whatever the caller believes.
     *
     * `true` means the row now carries a stamp — written by this call or
     * already there. `false` means the statement was refused, which a caller
     * inside a transaction must treat as a reason to roll back.
     */
    public function recordMirroredStatusWhenAbsent(int $productId, string $storefrontStatus): bool;

    /**
     * Bring `status` into line with the storefront, for ONE row whose status
     * this plugin has provably never decided.
     *
     * The rule that chooses the rows is `StorefrontStatusReconciliation` and
     * its docblock carries the reasoning. This method's job is to make that
     * rule unforgeable, so three things are in the statement rather than in a
     * read before it (`alpha.50`):
     *
     *  * **the stamp, by value.** A `NULL` stamp never matches, so a row whose
     *    status the projector owns cannot be written by this path however the
     *    caller is mistaken; and a stamp that MOVED between the preview and
     *    the press refuses, because `updateStatus()` clears it in the same
     *    statement as a manager's decision and that decision must win.
     *  * **the status, by value.** A row that changed status in between — a
     *    vendor pressing «ارسال برای بررسی» — refuses rather than having the
     *    submission overwritten.
     *  * **`row_version = row_version + 1`**, so a column always changes and
     *    zero rows unambiguously means the `WHERE` did not match rather than
     *    «it already said that» — wpdb does not set `CLIENT_FOUND_ROWS`
     *    (`alpha.50`), so without this a same-second rewrite would read as a
     *    storage failure.
     *
     * ⛔ **It writes `status` and nothing else.** Not the stamp — clearing it
     * would release the catalogue visibility and let the next projection
     * write `visible` over a deliberate `exclude-from-catalog`. Not
     * `review_note`, which carries a manager's sentence to the vendor. Not
     * `published_at`, because this marketplace did not publish the product
     * and inventing a date would be a worse record than an empty one. And
     * nothing in `wp_posts`: the storefront is the reference here, not the
     * subject.
     *
     * `true` means this row now carries the storefront's status. `false` means
     * the guards did not match or the statement was refused, and the caller
     * must report the row by name rather than counting it as repaired.
     */
    public function reconcileStatusToStorefront(
        int $productId,
        ProductStatus $target,
        ProductStatus $expectedStatus,
        string $expectedStamp
    ): bool;

    /**
     * Every `product_cat` term recorded for this product, or `null`.
     *
     * THREE answers, and the third is the point: `null` means the question
     * could not be asked — the link table is not there yet (schema 34), or the
     * read failed — and a caller must then fall back to the single key rather
     * than conclude the product has no categories (`alpha.8`). An empty ARRAY
     * means the table answered and holds nothing for this product, which is
     * «not recorded», still not «has none».
     *
     * @return list<int>|null
     */
    public function categoryIdsFor(int $productId): ?array;

    /**
     * The recorded sets for a page of products, in one read.
     *
     * `null` means the question could not be asked — the table is absent or
     * the read failed — and the caller must fall back rather than conclude
     * that none of them is recorded.
     *
     * @param list<int> $productIds
     * @return array<int,list<int>>|null keyed by product id; a product with
     *         nothing recorded is absent from the map
     */
    public function categorySetsFor(array $productIds): ?array;

    /**
     * Replace the recorded set for one product, as one unit of work.
     *
     * ⛔ An EMPTY set is ALWAYS refused, because «هیچ رابطه‌ای خودکار حذف
     * نشود»: clearing what is recorded is a decision, and in this package no
     * path takes it.
     *
     * The parameter that used to say «this caller means it» is gone. It had
     * **no caller** — `alpha.80`'s rule, in a new place: a parameter nobody
     * passes is not a capability, it is a door with no room behind it, and
     * leaving it there invites the next round to flip it without finding out
     * who clears a relationship and on whose authority. What it would take to
     * clear one is written as an open decision
     * (`docs/open-decisions-alpha82.md` §2), unanswered.
     *
     * @param list<int> $termIds
     * @return string '' on success, otherwise a named refusal:
     *         `bad_product` · `category_table_unreadable` ·
     *         `category_set_unsupported` (schema 34) · `category_set_empty` ·
     *         `not_atomic` · `storage_failed`
     */
    public function saveCategorySet(int $productId, array $termIds): string;

    /**
     * Record a product's whole relationship — adding only, never replacing.
     *
     * Three answers rather than two, because three things are genuinely
     * different: an imported row with nothing recorded gets the whole set; a
     * row whose recorded set is a strict SUBSET of this one is COMPLETED (the
     * missing ids go in, nothing is removed); and a row carrying an id this
     * product does not have is somebody's decision and is refused by name.
     *
     * ⛔ The completion case is what makes the upgrade work at all: migration
     * 35 backfills one row from `category_key`, which on staging is
     * `category_ids[0]`, so the multi-category products arrive with one of
     * their ids recorded. «مجموعهٔ کامل دسته‌ها باید حفظ شود… مدیر نباید
     * مجبور به انتخاب مجدد دسته‌های موجود شود.»
     *
     * The recorded set is read inside the transaction under a locking read
     * (`alpha.64`), and the single key is written only into an empty one —
     * a legacy key is left exactly as it is, because what it means for a
     * multi-category product is the owner's open decision.
     *
     * @param list<int> $termIds
     * @return string `category_set_written` · `already_set` ·
     *         `category_set_decided` · `bad_category` · `not_found` ·
     *         `not_imported` · `not_atomic` · `storage_failed` ·
     *         `category_set_unsupported` · `category_table_unreadable`
     */
    public function recordCategorySet(int $productId, array $termIds): string;

    /**
     * WooCommerce products that more than one of our rows points at.
     *
     * ⛔ This is physically possible: `tmc_products` has NO unique index on
     * `wc_product_id` (`alpha.56`), so «no duplicates» is a property of the
     * code that writes it and not of the table — which makes it something to
     * COUNT rather than something to assume. A completion report that cannot
     * answer this question is the reassuring kind.
     *
     * @return list<int> the WooCommerce ids, bounded
     */
    public function duplicateWcMappings(int $limit = 50): array;

    /**
     * @return list<int> every vendor owning at least one product an import stamped
     *
     * The companion to `idsFromImportRun()`, asked of the whole catalogue
     * rather than of one run: not «what did this run create» but «which shops
     * did the migration touch at all». `MigrationCompleteness` needs it
     * because a shop can arrive carrying nothing but a catalogue — no balance
     * row, no withdrawal, no staff — and a shop missing from that list is not
     * judged incomplete, it is absent, which reads as nothing left to do.
     */
    public function vendorsFromImportRuns(): array;

    /**
     * A status transition — and the moment the storefront's status becomes ours.
     *
     * This is the one chokepoint every explicit status decision goes through
     * (submit, approve, reject, publish, suspend, archive, restore), so it is
     * where `mirrored_status` is cleared: before it, the status on an intaken
     * product is somebody else's and the projector holds it; after it, a
     * human inside this marketplace has decided, and the decision is written.
     *
     * Cleared in the SAME statement as the status, because a transition whose
     * second half failed would leave a status this marketplace decided and a
     * hold that stops it being written — a third value nobody asked for
     * (`alpha.61`).
     */
    public function updateStatus(int $productId, ProductStatus $status, string $reviewNote = ''): bool;

    /**
     * Which APPROVED brand this product's brand is, or null.
     *
     * Its own column and its own pair of methods, deliberately NOT a field on
     * `ProductDetails`. The brand a shopper sees is the NAME, which every
     * form, payload, CSV column, diff and projection already carries; the term
     * id is identity, and adding it to the details object would put a second
     * value into every one of those places for one question nothing else asks.
     *
     * Null has a meaning and it is not «no brand»: it says this row's brand
     * predates the registry (migration 25 adds the column with no backfill),
     * or that nobody has picked from the list since. A legacy free-text brand
     * therefore keeps working and is never silently declared approved — the
     * owner asked for exactly that restraint.
     */
    public function brandTermIdOf(int $productId): ?int;

    /**
     * Columns of `tmc_products` whose SHAPE would make a write store wrong
     * data. Empty when nothing is wrong with the columns that could be read.
     *
     * Asked at the WRITE rather than at the migration, and asked about the
     * shape rather than about the schema version — «شمارهٔ ساختار به‌تنهایی
     * کافی نیست». A column that is missing, and a column present with the
     * wrong nullability, type, length or default, all come back here, so «the
     * structure is behind» needs no second question.
     *
     * EMPTY IS NOT A CLEAN BILL OF HEALTH: an unreadable `information_schema`
     * answers empty as well, and `structureKnown()` is the question that tells
     * them apart. A caller that refuses on this list alone would let the
     * unknown case through, which is precisely what `alpha.48` did.
     *
     * @return list<string>
     */
    public function unsoundColumns(): array;

    /**
     * Whether the shape of `tmc_products` could be READ at all.
     *
     * False means there is no answer to the question above — never that the
     * answer is «sound». Measured on the `alpha.48` bytes, where this question
     * did not exist: `reads_as_sound=yes problem=product_table_unreadable
     * wrote=1`. Every write refuses while this is false, under its own name.
     */
    public function structureKnown(): bool;

    /**
     * The brand name AND the approved brand it is, written together.
     *
     * Together because they are one fact. A name without its id would leave
     * the next reader unable to tell a picked brand from free text, and an id
     * without its name would show a shopper nothing.
     *
     * Unguarded by design: this is the manager applying a decision they have
     * just made, which is the same reason `approveRevision()` writes the
     * details unguarded. The vendor's own brand change travels on
     * `updateDetails()` and keeps its version guard.
     */
    public function setBrandTerm(int $productId, string $brand, ?int $termId): bool;

    /**
     * Record the values both sides agreed on, so the NEXT vendor edit can be
     * measured against something.
     *
     * Called by an approval or an explicit field decision — never by a
     * projection, which is the marketplace writing rather than the two sides
     * agreeing. `null` clears it, which is what a rollback of a decision
     * means: back to «no record of agreement», not to a guessed one.
     */
    public function saveBaseline(int $productId, ?ApprovedBaseline $baseline): bool;

    /**
     * The price and its sale, written at once at every status.
     *
     * ⛔ **This method exists because `alpha.83` took the price out of the
     * approval cycle, and without it that change would have DISCARDED the
     * vendor's price silently.** `saveAsRevision()` writes only
     * `updateInventory()` straight through; once `between()` stopped
     * reporting the price, a price-only change on a published product reached
     * the early `inventory_saved` return and nothing wrote it anywhere — the
     * same shape as `alpha.82`'s §1-ب, where a multi-category edit answered
     * «saved» and was thrown away.
     *
     * Unguarded by version, like `updateInventory()` and for the reason A.1
     * gives for stock: the vendor's own number's latest value is the true
     * one, and refusing it because a colleague renamed the product two
     * minutes ago is a queue nobody asked for. The optimistic lock still
     * guards the PROPOSAL of every sensitive field.
     *
     * All four values together, because they are one fact: a sale price
     * without the regular price it discounts, or a window without the sale,
     * is a combination nobody chose.
     */
    public function updatePrice(
        int $productId,
        int $priceMinor,
        ?int $salePriceMinor,
        ?string $saleFrom,
        ?string $saleTo
    ): bool;

    /** Stock and the other immediate fields, which never wait for a review. */
    public function updateInventory(
        int $productId,
        int $stock,
        string $sku,
        int $minPurchase,
        ?int $maxPurchase,
        int $purchaseStep = 1
    ): bool;

    /** @param array<string,string> $values */
    public function saveSpecs(int $productId, array $values, int $schemaVersion): bool;

    /** @return array<string,string> */
    public function specs(int $productId): array;

    /** @param list<int> $mediaIds */
    public function saveImages(int $productId, array $mediaIds, int $mainImageId): bool;

    /** @return list<int> */
    public function images(int $productId): array;

    /**
     * Whether ANY product, gallery or variation names this attachment.
     *
     * Asked before an upload is discarded, and it is the whole licence for
     * that discard: «پاک‌سازی عمومی ممنوع», so the only media this plugin
     * ever deletes is media it just created AND that this query says nothing
     * points at. Scoped to no vendor on purpose — a reference belonging to
     * somebody else is still a reference, and the safe answer to «is anyone
     * using this» is never «not in your shop».
     */
    public function mediaInUse(int $mediaId): bool;

    /** Whether this vendor already used this SKU on a different product. */
    public function skuTaken(int $vendorUserId, string $sku, int $exceptProductId = 0): bool;

    /**
     * The WooCommerce link, one product each way (ADR-008).
     *
     * Passing null unlinks — used when the projected post has gone (somebody
     * deleted it in wp-admin), so the next projection creates a fresh one
     * instead of writing into a hole.
     */
    public function link(int $productId, ?int $wcProductId): bool;

    /**
     * The row that OWNS this storefront product — never one that merely maps
     * it. Every purchase decision ends here, so an `observed` row answering
     * this question is how a migration silently takes over another plugin's
     * catalogue.
     */
    public function findByWcProduct(int $wcProductId): ?Product;

    /** The row that merely POINTS at this storefront product, if any. */
    public function findObservedByWcProduct(int $wcProductId): ?Product;

    /** @return list<Product> rows a migration mapped but nobody took over */
    public function observed(int $limit = 200): array;

    /**
     * One shop's `observed` rows, from a cursor — the staged hand-over's read.
     *
     * ⛔ **Why a cursor and a vendor.** `observed()` is global and defaults to
     * `LIMIT 200`, and the only screen that can transfer ownership calls it
     * with no argument. On a catalogue with more than two hundred observed
     * rows, row 201 is unreachable from the one page that can move it and
     * nothing goes red — the shape `alpha.85` found one module over, where a
     * computed cursor had no consumer. It was a LIMIT rather than damage on
     * 184 rows, which is exactly why nobody saw it.
     *
     * Keyset on `id`, because the caller walks a shop's whole catalogue and
     * `OFFSET` on a moving table skips rows (`alpha.13`).
     *
     * @return list<Product> hydrated, because the planner needs each row's
     *         details to compare them against the shop
     */
    public function observedForVendorAfter(int $vendorUserId, int $afterId = 0, int $limit = 50): array;

    /**
     * One shop's STAMPED rows, from a cursor — whatever their ownership.
     *
     * ⛔ **Why not `observedForVendorAfter()`.** That read filters to
     * `observed`, and the rows this one is for are the ones a staged transfer
     * has ALREADY moved to `marketplace`: `setLinkOwnership()` does not touch
     * the stamp, so a transferred row keeps it and keeps the wrong status
     * column with it. Scoping the status repair to `observed` would make it
     * unable to reach the only site that needs it.
     *
     * The stamp is the scope instead, and it is the right one: a stamp means
     * `project()` has never written this row's status, so the column cannot
     * be a decision this marketplace made — the whole argument in
     * `StorefrontStatusReconciliation`. Ownership says who manages the
     * product and answers a different question.
     *
     * Keyset on `id` for the reason the method above gives: the caller walks
     * a whole catalogue and `OFFSET` on a moving table skips rows.
     *
     * @return list<Product> hydrated, because the caller needs each row's
     *         status and stamp to decide, and its WooCommerce id to ask the shop
     */
    public function stampedForVendorAfter(int $vendorUserId, int $afterId = 0, int $limit = 50): array;

    public function linkOwnership(int $productId): LinkOwnership;

    /** The explicit transfer, in both directions. Never called implicitly. */
    public function setLinkOwnership(int $productId, LinkOwnership $ownership): bool;

    /**
     * How many of a shop's rows are the marketplace's to run, and how many
     * are still only notes — counted in SQL.
     *
     * The migration report needs this and needs it cheap: «is this shop
     * actually migrated» is asked about every imported shop on one page, and
     * hydrating each catalogue to look at one column would make the answer
     * cost the catalogue.
     *
     * ⛔ **`readable` is a fact of its own, and false is not nought.** A
     * `GROUP BY` that failed answers with an empty list, exactly as a shop
     * with no products does, so the two numbers alone cannot say which
     * happened — and a readiness gate standing on them read a broken read as
     * «this shop holds nothing». The total is therefore counted separately
     * first and the breakdown has to add up to it; anything else sets
     * `readable` false, and `OwnershipState` then answers `UNREADABLE` rather
     * than a verdict.
     *
     * @return array{marketplace:int, observed:int, readable:bool}
     */
    public function ownershipTallyForVendor(int $vendorUserId): array;

    /**
     * Mirrors the stock WooCommerce now holds onto the marketplace row.
     *
     * This is the ONLY way stock travels from WooCommerce to here, and there
     * is deliberately no method for the other direction that a sync could
     * call: a sale must never be undone by a mirror (ADR-008).
     */
    public function mirrorStock(int $productId, int $stock): bool;

    public function updateSeo(int $productId, ProductSeo $seo): bool;

    /**
     * @return list<Product> every product of this vendor, whatever its status
     *
     * Use it when you genuinely need every row. For a page use `forVendor()`,
     * for a total `countForVendor()`, for the stock figures `stockSummary()` —
     * all three answer in SQL. Hydrating a whole catalogue into objects to
     * count it costs the same on a shop with twelve products and falls over on
     * one with twelve thousand.
     */
    public function allForVendor(int $vendorUserId): array;

    /**
     * Stock figures for the published catalogue, counted in SQL.
     *
     * The report used to walk every product, hydrate each one and add up in
     * PHP — three figures at the cost of the whole catalogue, on every page
     * load. These are three `COUNT`s behind the index the table already has.
     *
     * @return array{on_sale:int, out:int, low:int}
     */
    public function stockSummary(int $vendorUserId, int $lowThreshold): array;

    /** @return list<Product> products that are live and projected */
    public function projected(int $limit = 500): array;

    /**
     * HOW MANY rows `projected()` would return if nothing capped it.
     *
     * ⛔ Asked SEPARATELY and on purpose. `projected()` carries a `LIMIT`, so
     * its length answers «how many did I get» and never «how many are there»
     * — and the one caller that matters is the deactivation stop, where the
     * difference between those two is «products left on sale that nothing
     * reported». `alpha.8`, on the one path a silent truncation is worst.
     *
     * `null` means the count could not be read, which is not nought.
     */
    public function countProjected(): ?int;

    /**
     * ONE PAGE OF A VENDOR'S CATALOGUE, BOTH OWNERSHIPS, AGAINST THE SHOP.
     *
     * §۴ wants a reconciliation that can be matched by ID: «تعداد و شناسه Woo
     * parent/variation، نوع، وضعیت، `link_ownership`، مسئولیت مدیریت محصول،
     * قیمت/انبار قابل‌خرید بودن، و موارد mismatch/duplicate/unreadable» — and
     * «حداقل باید بتوان ۱۸۴ محصول #102 را با مجموعه شناسه‌ها … تطبیق داد».
     *
     * ⛔ NOT `forVendor()`. That one filters `link_ownership = marketplace`,
     * which is the right scope for every operational screen and the wrong one
     * here: an imported row is `observed`, and a reconciliation that cannot
     * see the imported rows cannot reconcile an imported shop.
     *
     * Keyset by `id`, because a reconciliation read with OFFSET over a table
     * somebody is still writing to skips and repeats rows (`alpha.72`).
     *
     * `post_type` and `post_status` are `null` when the shop has no such post
     * — which is a fact — and `shop_readable` is `false` when the join could
     * not be made at all, which is not. `rows_naming_it` counts how many of
     * OUR rows name the same product, so a duplicate is found from the data
     * rather than from a list somebody keeps.
     *
     * @return ?list<array{id:int, wc_product_id:?int, title:string, sku:string,
     *     type:string, status:string, link_ownership:string, price_minor:int,
     *     stock:int, post_type:?string, post_status:?string,
     *     rows_naming_it:int, shop_readable:bool}>
     *     `null` when the page could not be read — never an empty list
     */
    public function reconciliationPage(int $vendorUserId, int $limit, int $afterId = 0): ?array;

    /**
     * HOW MANY rows that reconciliation covers, asked separately.
     *
     * The page carries a `LIMIT`, so its length is «how many did I get».
     * `null` is «could not count», which the screen must not print as nought
     * (`alpha.8`, `alpha.100`).
     */
    public function countForReconciliation(int $vendorUserId): ?int;

    /**
     * Shop products that claim this vendor and have NO row of ours, by id.
     *
     * The other direction of the same audit — §۴'s «یک رکورد فقط Woo». The
     * claim is the projector's own vendor stamp, because that is the only
     * mark this plugin writes on a shop product; `post_author` is NOT read
     * here, since §۴ keeps those four facts apart and a shop product authored
     * by a Dokan seller is not evidence of a marketplace row.
     *
     * @return ?list<array{wc_product_id:int, post_status:string}>
     */
    public function shopProductsWithoutRow(int $vendorUserId, int $limit = 200): ?array;
}
