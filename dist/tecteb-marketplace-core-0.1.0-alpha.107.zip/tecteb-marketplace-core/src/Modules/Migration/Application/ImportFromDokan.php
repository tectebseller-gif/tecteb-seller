<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Migration\Application;

use Tecteb\Marketplace\Contracts\CapabilityCheckerInterface;
use Tecteb\Marketplace\Contracts\ClockInterface;
use Tecteb\Marketplace\Contracts\OptionStoreInterface;
use Tecteb\Marketplace\Core\Audit\AuditEventCatalog;
use Tecteb\Marketplace\Core\Audit\AuditLogger;
use Tecteb\Marketplace\Core\Lifecycle\Capabilities;
use Tecteb\Marketplace\Modules\Finance\Application\LedgerRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Domain\LeaseHold;
use Tecteb\Marketplace\Modules\Migration\Domain\UnitClaim;
use Tecteb\Marketplace\Modules\Product\Application\ProductImageLibraryInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductRepositoryInterface;
use Tecteb\Marketplace\Modules\Product\Domain\LinkOwnership;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;
use Tecteb\Marketplace\Modules\Vendor\Application\OperationResult;
use Tecteb\Marketplace\Modules\Vendor\Application\VendorRepositoryInterface;

/**
 * Bringing a Dokan shop into the marketplace — as a dry run first, and
 * reversibly.
 *
 * Three properties make this safe enough to run on a live site, and they are
 * the reason the code looks the way it does:
 *
 * 1. **Nothing of Dokan's is written, ever.** Not the seller's user, not the
 *    product's `post_author`, not a single Dokan table. DokanReaderInterface
 *    has no write method, so the capability is absent rather than guarded.
 *    What the import creates is marketplace rows that POINT at the existing
 *    WooCommerce product — which is also how «شناسه، URL، محصول، کاربر و سفارش
 *    حفظ می‌شوند» is satisfied: nothing is recreated, so nothing changes id.
 * 2. **The dry run is the default.** `plan()` writes nothing and returns a
 *    row-by-row mapping with a verdict each. A conflict is reported, never
 *    resolved by guessing.
 * 3. **Every import is one run, and a run can be undone.** Each created row's
 *    id is written into a manifest under the run id, and `rollback()` deletes
 *    exactly those and nothing else. Because nothing outside our own tables
 *    was touched, undoing a run really does restore the state before it.
 *
 * What this does NOT do, deliberately: it does not make the imported products
 * the marketplace's to sell. They arrive as drafts AND as `observed` links,
 * which are two different refusals and both are needed.
 *
 * Draft alone was not enough, and finding that out is what produced the
 * second one. A `marketplace` link makes every "is this ours?" question
 * answer yes — so after a dry-run import, Dokan's own vendor product answered
 * `vendor_stopped` and `is_purchasable()` went false, and a stop would have
 * drafted a post Dokan manages. Nothing of Dokan's had been written; the hash
 * of Dokan's data was identical; and the shop behaved differently anyway.
 * That is precisely why a fingerprint is not a proof of unchanged behaviour,
 * and why TransferOwnership is a separate, explicit act.
 */
final class ImportFromDokan
{
    /** Where each run's manifest lives, so a rollback knows what it made. */
    public const RUNS_OPTION = 'tmc_dokan_migration_runs';

    public function __construct(
        private readonly DokanReaderInterface $dokan,
        private readonly VendorRepositoryInterface $vendors,
        private readonly ProductRepositoryInterface $products,
        private readonly OptionStoreInterface $options,
        private readonly AuditLogger $audit,
        private readonly ClockInterface $clock,
        private readonly ?CapabilityCheckerInterface $capabilities = null,
        /**
         * Optional so an install without schema 15 still loads. A null here
         * means history is not imported, and the plan says so rather than
         * silently dropping it.
         */
        private readonly ?OrderHistoryRepositoryInterface $history = null,
        /**
         * The rest of a shop's past: staff, balance ledger, withdrawals.
         * Optional for the same reason as `$history` — an install without
         * schema 17 still loads, and the plan says so rather than pretending
         * it imported something it could not store.
         */
        private readonly ?ShopRecordRepositoryInterface $shopRecords = null,
        /**
         * Asked one question and one only: «does our own ledger already
         * account for this order?» FIN-02 says one financial engine per order,
         * and a rule nothing can check is a wish.
         */
        private readonly ?LedgerRepositoryInterface $ledger = null,
        // Optional: without it nothing is mapped and every product keeps an
        // empty category, which is the old behaviour rather than a wrong new
        // one.
        private readonly ?CategoryMap $categories = null,
        // Optional: without it a migrated product keeps no picture, which is
        // the old behaviour rather than a wrong new one.
        private readonly ?ProductImageLibraryInterface $images = null,
        /**
         * The admission list the record preview draws, asked on the WRITE
         * path.
         *
         * ⛔ **Why it is here and not only on the page.** `alpha.78` built one
         * shared scope and used it for the preview table and for the button;
         * the three record walks still read Dokan's own keysets, which hold
         * every shop at once. The two halves agreed because both were derived
         * from the same tables — a correspondence that happened to hold, not
         * one anything enforced — and the owner asked for the real path:
         * «دامنهٔ مشترک را در مسیر واقعی اجرا اعمال کن… دامنهٔ ناقص یا ناخوانا
         * نباید اجازهٔ ورودِ صاحبان نمایش‌داده‌نشده بدهد.»
         *
         * Optional, and `null` means the old behaviour rather than a refusal:
         * an install or a tool that does not supply one writes what it reads,
         * exactly as before. A missing dependency must not silently start
         * refusing somebody's records.
         */
        private readonly ?RecordScopeInterface $recordScope = null
    ) {
    }

    /**
     * Import every page of a shop's staff, balance ledger and withdrawals.
     *
     * Records, all three — Dokan's own figures, no rate applied, no ledger
     * line written. A balance is the clearest case: a shop that earned under a
     * 5% commission and is now on 8% must still see the number Dokan recorded,
     * so the amounts travel as strings straight into `DECIMAL(19,4)` columns
     * and nothing here multiplies anything.
     *
     * ⛔ **This is the unleased, walk-to-the-end path, and it is no longer
     * where the three kinds are actually imported.** It kept its signature
     * because the evidence tool calls it, and it now delegates to the three
     * per-kind pages below so there is ONE definition of what importing a
     * record does. The queue goes through `DokanRecordImportJob`, which holds
     * a lease, asks a time budget between units, and keeps a cursor per kind.
     *
     * @return array{staff:int, balance:int, withdrawals:int, failed:int, last_balance:int, last_withdraw:int, more:bool}
     */
    public function importShopRecordPage(string $runId, int $afterBalanceId, int $afterWithdrawId, int $limit): array
    {
        $done = ['staff' => 0, 'balance' => 0, 'withdrawals' => 0, 'failed' => 0];
        if ($this->shopRecords === null) {
            return $done + ['last_balance' => $afterBalanceId, 'last_withdraw' => $afterWithdrawId, 'more' => false];
        }

        // Staff from the beginning, every time, and unconditionally.
        //
        // ⛔ **What this replaced.** It used to run `if ($afterBalanceId === 0
        // && $afterWithdrawId === 0)`, with the reasoning «a shop has a
        // handful of staff, and paging a handful is machinery with nothing to
        // do». True of the handful, and false of the coupling it bought: once
        // the balance cursor moved past nought, an interrupted staff walk
        // could never resume, so every shop after the interruption had no
        // staff records and no page said so. Re-walking is free of
        // consequence because the unique key answers a repeat — which is also
        // why the figure below counts only what was newly RECORDED.
        $after = 0;
        for ($page = 0; $page < self::RECORD_PAGE_CAP; $page++) {
            $staff = $this->importStaffRecordPage($runId, $after, $limit);
            $done['staff'] += $staff['done'];
            $done['failed'] += $staff['failed'];
            if (!$staff['more'] || $staff['last'] <= $after) {
                break;
            }
            $after = $staff['last'];
        }

        $balance = $this->importBalanceRecordPage($runId, $afterBalanceId, $limit);
        $done['balance'] = $balance['done'];
        $done['failed'] += $balance['failed'];

        $withdraw = $this->importWithdrawalRecordPage($runId, $afterWithdrawId, $limit);
        $done['withdrawals'] = $withdraw['done'];
        $done['failed'] += $withdraw['failed'];

        return $done + [
            'last_balance' => $balance['last'],
            'last_withdraw' => $withdraw['last'],
            'more' => $balance['more'] || $withdraw['more'],
        ];
    }

    /**
     * How many pages the unleased walk above will take before it gives up.
     *
     * A bound rather than a `while (true)`: the loop's exit depends on the
     * cursor advancing, and a reader that answered the same page twice would
     * otherwise spin for the length of a request with nothing to show. The old
     * code walked every shop in one pass, so any cap large enough to cover a
     * real catalogue of shops is not a behaviour change — it is the loop
     * admitting it can be wrong.
     */
    private const RECORD_PAGE_CAP = 200;

    /**
     * One page of STAFF records. The unit is a SHOP.
     *
     * `staffFor()` answers for one vendor and Dokan gives its staff rows no id
     * of their own, so a shop is the smallest thing that can be finished and
     * written down. The cursor is therefore a vendor id: a run cut off after
     * the third shop resumes at the fourth, not at the first.
     *
     * A shop's staff are written as ONE unit of work, so a shop is never left
     * holding two of its three people with nothing saying which third is
     * missing.
     *
     * @return array{kind:string, done:int, recorded:int, already:int, failed:int, skipped:int, last:int, more:bool, lease_lost:bool, stopped:string, notes:list<string>}
     */
    public function importStaffRecordPage(string $runId, int $afterVendorId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        return $this->recordPage(
            'staff',
            $afterVendorId,
            $limit,
            $progress,
            fn (int $after, int $size): array => array_map(
                static fn (array $row): int => (int) $row['user_id'],
                $this->dokan->vendorsAfter($after, $size)
            ),
            static fn (mixed $unit): int => (int) $unit,
            // The unit IS the shop, so the owner is the unit.
            static fn (mixed $unit): int => (int) $unit,
            function (mixed $unit) use ($runId): array {
                $tally = ['recorded' => 0, 'already' => 0, 'failed' => 0];
                foreach ($this->dokan->staffFor((int) $unit) as $member) {
                    $this->tally($tally, $this->shopRecords?->recordStaff($runId, $member) ?? ShopRecordRepositoryInterface::FAILED);
                }
                return $tally;
            }
        );
    }

    /**
     * One page of BALANCE LEDGER records. The unit is a row.
     *
     * Dokan's own `row_id`, ascending, strictly after the cursor — the same
     * keyset the reader already does in SQL. The amounts are not touched: a
     * debit of `'700000.0000'` is written as `'700000.0000'`.
     *
     * @return array{kind:string, done:int, recorded:int, already:int, failed:int, skipped:int, last:int, more:bool, lease_lost:bool, stopped:string, notes:list<string>}
     */
    public function importBalanceRecordPage(string $runId, int $afterRowId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        return $this->recordPage(
            'balance',
            $afterRowId,
            $limit,
            $progress,
            fn (int $after, int $size): array => $this->dokan->balanceRowsAfter($after, $size),
            // `row_id` is the table's own key; `trn_id` is the transaction it
            // belongs to and is NOT unique across types — the fallback is
            // only for a reader that cannot supply the first.
            static fn (mixed $unit): int => (int) (is_array($unit) ? ($unit['row_id'] ?? $unit['trn_id'] ?? 0) : 0),
            static fn (mixed $unit): int => (int) (is_array($unit) ? ($unit['vendor_user_id'] ?? 0) : 0),
            function (mixed $unit) use ($runId): array {
                $tally = ['recorded' => 0, 'already' => 0, 'failed' => 0];
                $this->tally($tally, $this->shopRecords?->recordBalance($runId, (array) $unit) ?? ShopRecordRepositoryInterface::FAILED);
                return $tally;
            }
        );
    }

    /**
     * One page of WITHDRAWAL records. The unit is a request.
     *
     * ⛔ These are a RECORD and not a liability. Dokan books an approved
     * withdrawal twice by design — a row here and a debit in the balance
     * ledger — so the closing balance has already subtracted it, and nothing
     * written by this method creates anything payable. `WithdrawalRepository`
     * is where a request this marketplace must honour lives, and this writes
     * nothing there.
     *
     * @return array{kind:string, done:int, recorded:int, already:int, failed:int, skipped:int, last:int, more:bool, lease_lost:bool, stopped:string, notes:list<string>}
     */
    public function importWithdrawalRecordPage(string $runId, int $afterWithdrawId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        return $this->recordPage(
            'withdrawals',
            $afterWithdrawId,
            $limit,
            $progress,
            fn (int $after, int $size): array => $this->dokan->withdrawalsAfter($after, $size),
            static fn (mixed $unit): int => (int) (is_array($unit) ? ($unit['withdraw_id'] ?? 0) : 0),
            static fn (mixed $unit): int => (int) (is_array($unit) ? ($unit['vendor_user_id'] ?? 0) : 0),
            function (mixed $unit) use ($runId): array {
                $tally = ['recorded' => 0, 'already' => 0, 'failed' => 0];
                $this->tally($tally, $this->shopRecords?->recordWithdrawal($runId, (array) $unit) ?? ShopRecordRepositoryInterface::FAILED);
                return $tally;
            }
        );
    }

    /**
     * The one loop the three kinds share: claim, budget, write, land.
     *
     * Shared rather than copied three times because every property the owner
     * asked for is a property of this loop — resumable, budgeted, guarded
     * against a second worker, and never counting a write that did not land —
     * and three copies would be three places for one of them to go missing.
     * What differs between the kinds is only how a page is read, what names a
     * unit, and what writing one means, so those three are arguments.
     *
     * @param \Closure(int,int):array<int,mixed> $read
     * @param \Closure(mixed):int $idOf
     * @param \Closure(mixed):int $ownerOf
     * @param \Closure(mixed):array{recorded:int, already:int, failed:int} $write
     * @return array{kind:string, done:int, recorded:int, already:int, failed:int, skipped:int, last:int, more:bool, lease_lost:bool, stopped:string, notes:list<string>}
     */
    private function recordPage(
        string $kind,
        int $after,
        int $limit,
        ?ImportProgressInterface $progress,
        \Closure $read,
        \Closure $idOf,
        \Closure $ownerOf,
        \Closure $write
    ): array {
        $empty = [
            'kind' => $kind,
            'done' => 0,
            'recorded' => 0,
            'already' => 0,
            'failed' => 0,
            'skipped' => 0,
            'last' => $after,
            'more' => false,
            'lease_lost' => false,
            'stopped' => '',
            'notes' => [],
        ];
        if ($this->shopRecords === null) {
            // Nowhere to keep records. Reported as «more => false» with
            // nothing done, which is what is true; the page says why.
            return $empty;
        }

        $size = max(1, $limit);
        $stopped = '';
        $progress?->entering('page_read', 0);
        $page = $read($after, $size);
        $progress?->left();

        $last = $after;
        $done = 0;
        $already = 0;
        $failed = 0;
        $recorded = 0;
        $skipped = 0;
        $leaseLost = false;
        $notes = [];

        foreach ($page as $unit) {
            $id = $idOf($unit);
            // ⛔ **The admission question, asked before anything about this
            // unit is claimed or written.** The scope is the list the preview
            // drew and the button checked; an owner outside it is an owner
            // nobody has been shown, and writing its records is the defect
            // this whole round is about. It is SKIPPED and NAMED — never
            // deleted, never written, and never counted as done.
            //
            // In the ordinary case this filter does nothing, and that is the
            // point: the scope is a union of the very tables walked below, so
            // agreement is the normal state and a disagreement means the
            // enumeration came back short or somebody's row arrived between
            // the two reads.
            if ($this->recordScope !== null) {
                $owner = $ownerOf($unit);
                if (!$this->recordScope->admits($owner)) {
                    $last = max($last, $id);
                    $skipped++;
                    $note = $kind . ':' . $id . ':owner_' . $owner . '_outside_the_shown_scope';
                    $notes[] = $note;
                    // The cursor still has to move past it, or the walk reads
                    // the same page for ever.
                    if ($progress !== null && !$progress->landed($last, 0, 0, [$note])) {
                        $leaseLost = true;
                        break;
                    }
                    continue;
                }
            }
            // Asked BETWEEN units, never inside one. A unit that has started
            // runs to its end: stopping inside one is what the host already
            // does, and the whole point of asking is not to be there when it
            // happens.
            if ($progress !== null && !$progress->keepGoing()) {
                $stopped = $progress->stopReason();
                break;
            }
            if ($progress !== null) {
                $claim = $progress->claim($id);
                if ($claim === UnitClaim::LeaseLost) {
                    $leaseLost = true;
                    break;
                }
                if ($claim === UnitClaim::GiveUp) {
                    $last = max($last, $id);
                    $failed++;
                    $note = $kind . ':' . $id . ':stalled_after_' . $progress->attempts($id) . '_attempts';
                    $notes[] = $note;
                    if (!$progress->landed($last, 0, 1, [$note])) {
                        $leaseLost = true;
                        break;
                    }
                    continue;
                }
            }
            $last = max($last, $id);

            if ($progress !== null && !$progress->entering('record_write', $id)) {
                $leaseLost = true;
                break;
            }
            $tally = ['recorded' => 0, 'already' => 0, 'failed' => 0];
            $hold = LeaseHold::Held;
            if ($progress === null) {
                $tally = $write($unit);
            } else {
                // The write and the question «is this job still mine» are one
                // unit of work: `alpha.74`'s rule, because a check that
                // returns is a report and a guarantee is one the write sits
                // inside of.
                $hold = $progress->writing(function () use ($write, $unit, &$tally): bool {
                    $tally = $write($unit);
                    return $tally['failed'] === 0;
                });
                $progress->left();
            }

            if ($hold === LeaseHold::LeaseLost) {
                $leaseLost = true;
                break;
            }
            if ($hold === LeaseHold::NotWritten) {
                // Rolled back whole, so nothing of this unit is held — the
                // counts it reported are not banked, and the position is named
                // rather than passed over in silence.
                $failed++;
                $notes[] = $kind . ':' . $id . ':not_written';
                $tally = ['recorded' => 0, 'already' => 0, 'failed' => 0];
            }
            $done += $tally['recorded'];
            $already += $tally['already'];

            if ($progress !== null) {
                if (!$progress->landed($last, $tally['recorded'], $hold === LeaseHold::NotWritten ? 1 : 0)) {
                    $leaseLost = true;
                    break;
                }
                $recorded += $tally['recorded'];
            }
        }

        return [
            'kind' => $kind,
            // ⛔ Derived from what was actually banked by `landed()`, never
            // from the length of the page: `alpha.76`'s rule, because the
            // first `break` breaks the assumption that the loop reached the
            // end and nothing turns red when it does.
            'done' => max(0, $done - $recorded),
            'recorded' => $recorded,
            'already' => $already,
            'failed' => $failed,
            'skipped' => $skipped,
            'last' => $last,
            'more' => $leaseLost ? false : ($stopped !== '' || count($page) >= $size),
            'lease_lost' => $leaseLost,
            'stopped' => $stopped,
            'notes' => $notes,
        ];
    }

    /**
     * @param array{recorded:int, already:int, failed:int} $tally
     */
    private function tally(array &$tally, string $outcome): void
    {
        match ($outcome) {
            ShopRecordRepositoryInterface::RECORDED => $tally['recorded']++,
            ShopRecordRepositoryInterface::FAILED => $tally['failed']++,
            default => $tally['already']++,       // the unique key answered
        };
    }

    /** What a shop's imported past adds up to, in Dokan's own figures. */
    public function shopRecordsFor(int $vendorUserId): array
    {
        if ($this->shopRecords === null) {
            return ['available' => false, 'staff' => 0, 'balance_rows' => 0, 'debit' => '0', 'credit' => '0', 'withdrawals' => 0, 'withdrawn' => '0'];
        }
        return $this->shopRecords->summaryForVendor($vendorUserId) + ['available' => true];
    }

    /**
     * Whether a past order may be recorded as history at all.
     *
     * FIN-02: one financial engine per order. If this marketplace's ledger
     * already carries lines for it — because the order was placed here, or
     * because somebody transferred it — then Dokan's figures for the same
     * order would be a second, contradictory answer to «what is this worth»,
     * with nothing to say which is authoritative. So it is refused and named,
     * not written and reconciled later.
     */
    public function orderIsAlreadyOurs(int $wcOrderId): bool
    {
        return $this->ledger?->coversOrder($wcOrderId) ?? false;
    }

    /**
     * The dry run. Reads Dokan, reads us, writes nothing.
     */
    public function plan(): DokanMigrationPlan
    {
        $now = $this->clock->now()->format('Y-m-d H:i:s');
        $runId = 'dokan-' . $this->clock->now()->format('Ymd-His');

        $vendorRows = [];
        foreach ($this->dokan->vendors() as $vendor) {
            $existing = $this->vendors->findProfileByUser($vendor['user_id']);
            $vendorRows[] = [
                'dokan_id' => $vendor['user_id'],
                'title' => $vendor['store_name'],
                'verdict' => $existing !== null ? DokanMigrationPlan::SKIP : DokanMigrationPlan::IMPORT,
                'reason' => $existing !== null ? 'already_a_marketplace_vendor' : '',
                'target' => $existing !== null ? 'tmc_vendor:' . $vendor['user_id'] : 'tmc_vendor:new',
            ];
        }

        $productRows = [];
        foreach ($this->dokan->products() as $product) {
            [$verdict, $reason] = $this->judgeProduct($product);
            $productRows[] = [
                'dokan_id' => $product['wc_product_id'],
                'title' => $product['title'],
                'verdict' => $verdict,
                'reason' => $reason,
                'target' => $verdict === DokanMigrationPlan::IMPORT
                    ? 'tmc_product:new → wc:' . $product['wc_product_id']
                    : 'wc:' . $product['wc_product_id'],
            ];
        }

        // Orders are REPORTED and not imported in this round. A Dokan order
        // line carries a commission worked out under Dokan's rules, and
        // re-recording it under ours would either invent a rate (FIN-02
        // forbids it) or write a ledger line that contradicts the money that
        // actually moved. So the plan counts them and says so.
        // The verdict changed in `alpha.14`, and the REASON it changed is worth
        // keeping. These orders were skipped because re-recording them under
        // our rules would either invent a rate (FIN-02 forbids it) or write a
        // ledger line contradicting money that already moved. Both are still
        // true — so the history arrives as a RECORD carrying Dokan's own
        // figures, with no ledger line and no rate applied. «Imported» here
        // means «written down», never «recalculated».
        $orderRows = [];
        foreach ($this->dokan->orders() as $order) {
            $orderRows[] = [
                'dokan_id' => $order['wc_order_id'],
                'title' => (string) $order['wc_order_id'],
                // A figure Dokan stored with more precision than this shop's
                // currency can express is SKIPPED and named, never rounded.
                // Dokan's columns are `decimal(19,4)`; a shop with two
                // decimals cannot hold `10.0050` and a rounded import would
                // be this plugin changing somebody's recorded share by a
                // hundredth and reporting success.
                'verdict' => $this->history === null || ($order['amount_not_exact'] ?? false)
                    ? DokanMigrationPlan::SKIP
                    : DokanMigrationPlan::IMPORT,
                'reason' => ($order['amount_not_exact'] ?? false)
                    ? 'amount_not_exact_for_this_currency'
                    : ($this->history === null
                        ? 'history_storage_unavailable'
                        : 'history_recorded_without_recomputing'),
                'target' => 'wc_order:' . $order['wc_order_id'],
            ];
        }

        $plan = new DokanMigrationPlan($runId, $vendorRows, $productRows, $orderRows, $now);
        $summary = $plan->summary();
        $this->audit->log(AuditEventCatalog::DOKAN_DRY_RUN, $this->actorId(), 'migration', $runId, [
            'vendors' => $summary['vendors'],
            'products' => $summary['products'],
            'orders' => count($orderRows),
            'conflicts' => $summary['conflicts'],
            'run_id' => $runId,
        ]);
        return $plan;
    }

    /**
     * Runs a plan for real — the rows it marked `import`, and nothing else.
     *
     * Refuses a plan with conflicts outright. «تطبیق داده‌ها» means a person
     * looked at the conflicts and dealt with them; importing around them would
     * make the dry run decorative.
     */
    public function import(DokanMigrationPlan $plan): OperationResult
    {
        if ($this->capabilities === null || !$this->capabilities->can(Capabilities::REVIEW_VENDOR)) {
            return OperationResult::failure('forbidden');
        }
        if (!$plan->isClean()) {
            return OperationResult::failure('migration_has_conflicts', [
                'conflicts' => $plan->summary()['conflicts'],
            ]);
        }
        $created = ['vendors' => [], 'products' => []];
        $byId = [];
        foreach ($this->dokan->vendors() as $vendor) {
            $byId[$vendor['user_id']] = $vendor;
        }

        foreach ($plan->vendors as $row) {
            if ($row['verdict'] !== DokanMigrationPlan::IMPORT) {
                continue;
            }
            $vendor = $byId[$row['dokan_id']] ?? null;
            if ($vendor === null) {
                continue;
            }
            // canSell false: an imported shop is present, not yet trading. The
            // owner turns that on per shop once the mapping has been read.
            // Stamped IN the insert, like the products: the profile that was
            // created IS the record that this run created it, and there is no
            // second write for a crash to fall between.
            $this->vendors->upsertProfile(
                $vendor['user_id'],
                $vendor['store_name'],
                false,
                false,
                $plan->runId
            );
            $created['vendors'][] = $vendor['user_id'];
        }

        $productsById = [];
        foreach ($this->dokan->products() as $product) {
            $productsById[$product['wc_product_id']] = $product;
        }
        foreach ($plan->products as $row) {
            if ($row['verdict'] !== DokanMigrationPlan::IMPORT) {
                continue;
            }
            $product = $productsById[$row['dokan_id']] ?? null;
            if ($product === null) {
                continue;
            }
            // THE STATUS THE SHOP ACTUALLY HOLDS, through the one total map.
            //
            // ⛔ Until `alpha.92` this path passed neither — not the mapped
            // row status and not `create()`'s seventh argument — so every
            // imported row said «پیش‌نویس» with NO stamp. Measured in
            // `docs/dokan-exit-drift-analysis-alpha91-fa.md` §2 on shop 102's
            // 184 rows: the first projection AFTER an ownership transfer would
            // write `draft` + `hidden` over a product the vendor is selling
            // today, and no screen said a word. The catalogue path has
            // recorded both since `alpha.66`; this one is the half that was
            // missed, and two intake paths recording their origin differently
            // is two paths for a rollback to miss.
            //
            // ⛔ `array_key_exists`, NOT `??`, and for the same reason
            // `conflictOf()` uses it one method down: «the reader did not
            // tell me the status» and «the status is one I cannot express»
            // are different problems, and the plan treats only the second as
            // a conflict. With `??` a build whose reader supplies no status
            // at all would have EVERY product silently skipped here while the
            // plan said the run was fine — a guard wider than the defect
            // (`alpha.60`). A reader that says nothing gets what it got
            // before this round: a draft, and NO stamp, because there is no
            // observation to record and inventing one would be worse than
            // leaving the row for `take()` to refuse by name.
            $toldTheStatus = array_key_exists('post_status', $product);
            $shopStatus = $toldTheStatus ? (string) $product['post_status'] : '';
            $mirrored = $toldTheStatus
                ? ProductStatus::forIntakeOf($shopStatus)
                : ProductStatus::Draft;
            if ($mirrored === null) {
                // A status this marketplace has no field for. The plan refuses
                // it too, so reaching this is a status that moved between the
                // two reads — and the honest answer to a state we cannot hold
                // is to leave the product alone (`ProductStatus::forIntakeOf`).
                continue;
            }
            $productId = $this->products->create(
                $product['vendor_user_id'],
                new ProductDetails(
                    title: $product['title'],
                    // Mapped, or empty. Empty keeps the product a draft,
                    // which is the visible «somebody must decide this» —
                    // see `CategoryMap`.
                    categoryKey: $this->categories?->marketplaceCategoryFor(
                        (string) ($product['source_category_key'] ?? '')
                    ) ?? '',
                    priceMinor: $product['price_minor'],
                    sku: $product['sku'],
                    // Never below zero.
                    //
                    // Dokan permits backorders, so a live shop really does
                    // carry products at `-2`, and this marketplace's own
                    // validation refuses a negative stock — every such
                    // product would arrive and then be unsaveable, which is
                    // the worst of both. Zero is the conservative reading of
                    // «somebody already sold more than they had»: none
                    // available, nothing oversold twice. The count is
                    // reported, so it is a number the owner sees rather than
                    // a correction nobody was told about.
                    stock: max(0, (int) $product['stock'])
                ),
                // The status the shop holds, mapped — not «Draft, always».
                //
                // ⛔ That older comment said «publishing would write to a post
                // Dokan manages», and the stamp passed as the last argument is
                // precisely what stops that write: a held row's projection
                // touches neither the status nor the catalogue visibility. What
                // «Draft, always» actually produced was the opposite of its
                // intention — a row that disagreed with the shop, so that the
                // moment anything cleared the stamp the projection wrote
                // `draft` over `publish`. The catalogue path has mapped it
                // since `alpha.55` and observed+Published has been a shipped,
                // measured combination ever since: nothing follows from an
                // observed row until a manager accepts management.
                $mirrored,
                // OBSERVED, always. The row knows which WooCommerce product it
                // corresponds to and nothing else follows: the purchase guard,
                // the storefront stop and the projector all skip it. Without
                // this, a dry-run import made Dokan's own vendor product
                // unpurchasable — measured, and the reason this value exists.
                LinkOwnership::Observed,
                // Linked to the EXISTING WooCommerce product — in the SAME
                // insert, so the id and the URL a customer bookmarked keep
                // working AND a process killed here cannot leave a row whose
                // link is missing. An unlinked row is invisible to the resume
                // lookup, which then makes a second one.
                (int) $product['wc_product_id'],
                // And the same stamp the paged path writes, in that one
                // statement too. Two import paths that record their origin
                // differently is two paths for a rollback to miss.
                $plan->runId,
                '',
                // THE STATUS, RECORDED AS OBSERVED — so the projector knows it
                // has never written this product's status and leaves it, and
                // its catalogue visibility, alone. Blank when the reader named
                // none, which is «no stamp» rather than a stamp of nothing.
                $shopStatus
            );
            if ($productId === 0) {
                continue;
            }
            // The picture the product already has.
            //
            // Unlike the CATEGORY — two vocabularies, no reliable
            // correspondence, so a mapping the owner writes — the featured
            // image needs no decision at all: it is the same photograph of
            // the same product, hanging on the very WooCommerce post this row
            // now points at. Carrying it is not a guess; leaving it behind
            // would just make every migrated product fail readiness with
            // `missing_image` and wait for somebody to re-upload a file that
            // is already there.
            //
            // A SECOND write, deliberately, and safe in a way the run stamp
            // was not: a row that lost its image between the two is still
            // findable, still stamped, still rolled back with its run — and
            // it says `missing_image` out loud instead of turning into a
            // duplicate on the next pass.
            $sourceImageId = (int) ($product['source_image_id'] ?? 0);
            if ($sourceImageId > 0 && $this->images !== null) {
                // COPIED into the vendor's own media, not referenced.
                //
                // The gallery only keeps images the vendor owns, and the
                // source attachment belongs to whoever uploaded it in the old
                // system — so a reference survives the import and then
                // vanishes the first time the vendor saves the product, which
                // is the worst possible moment to lose it. Measured: the
                // picture arrived, the vendor filled in the specs, and the
                // save dropped it again.
                $ownCopy = $this->images->duplicateForVendor($sourceImageId, (int) $product['vendor_user_id']);
                if ($ownCopy > 0) {
                    $this->products->saveImages($productId, [$ownCopy], $ownCopy);
                }
            }
            $created['products'][] = $productId;
        }

        // The history, through the same recorder the job uses. Two import
        // paths that write history differently is two paths for a rollback to
        // miss — the same lesson the run stamp just taught.
        $historyRecorded = 0;
        $historyFailed = 0;
        $historyRefused = 0;
        if ($this->history !== null) {
            foreach ($this->dokan->orders() as $order) {
                // FIN-02, enforced rather than asserted. An order our own
                // ledger already carries must not also get Dokan's figures:
                // two answers to «what is this worth» and nothing to say
                // which one settlement should believe.
                if ($this->orderIsAlreadyOurs((int) $order['wc_order_id'])) {
                    $historyRefused++;
                    continue;
                }
                if (($order['amount_not_exact'] ?? false) === true) {
                    $historyRefused++;
                    continue;           // named in the plan, never rounded in
                }
                match ($this->history->record($plan->runId, $order)) {
                    OrderHistoryRepositoryInterface::RECORDED => $historyRecorded++,
                    OrderHistoryRepositoryInterface::FAILED => $historyFailed++,
                    default => null,            // already there: a re-run, not a fault
                };
            }
        }

        $this->rememberRun($plan->runId, $created);
        $this->audit->log(AuditEventCatalog::DOKAN_IMPORTED, $this->actorId(), 'migration', $plan->runId, [
            'vendors' => count($created['vendors']),
            'products' => count($created['products']),
            'history' => $historyRecorded,
            // Counted separately and never folded into the total: a run that
            // reports «۶ سفارش وارد شد» while two of them failed is a run
            // somebody will trust.
            'history_failed' => $historyFailed,
            // Named separately from «failed»: an order this marketplace
            // already owns is not a fault, it is the rule working.
            'history_already_ours' => $historyRefused,
            'run_id' => $plan->runId,
            'mode' => 'trial',
        ]);
        return OperationResult::success('dokan_imported', [
            'run_id' => $plan->runId,
            'vendors' => count($created['vendors']),
            'products' => count($created['products']),
            'history' => $historyRecorded,
            'history_already_ours' => $historyRefused,
        ]);
    }

    /**
     * Undoes one run: exactly the rows it created.
     *
     * Deletion, not archiving, and that is the one place in this plugin where
     * deleting is the right answer: these rows are not a record of anything
     * that happened, they are a copy that turned out to be unwanted. Nothing
     * of Dokan's is touched, because nothing of Dokan's was ever written.
     */
    public function rollback(string $runId): OperationResult
    {
        if ($this->capabilities === null || !$this->capabilities->can(Capabilities::REVIEW_VENDOR)) {
            return OperationResult::failure('forbidden');
        }
        $runs = $this->runs();
        $run = $runs[$runId] ?? null;
        // Rows stamped with this run id are authoritative; the manifest is the
        // fallback for runs imported before the stamp existed, and for rows a
        // pre-stamp build created. A run with neither is genuinely unknown.
        $stamped = $this->products->idsFromImportRun($runId);
        if ($run === null && $stamped === []) {
            return OperationResult::failure('not_found', ['run_id' => $runId]);
        }
        // The union, de-duplicated: a row can be in both and must be deleted
        // once. This is also what makes a crash mid-page recoverable — those
        // rows are stamped and absent from the manifest.
        $productIds = array_values(array_unique(array_merge(
            array_map('intval', $run['products'] ?? []),
            $stamped
        )));
        sort($productIds);

        $removedProducts = 0;
        $keptProducts = [];
        /** @var array<int,string> $failedProducts product id => the part that would not go */
        $failedProducts = [];
        foreach ($productIds as $productId) {
            $productId = (int) $productId;
            if ($this->products->linkOwnership($productId) === LinkOwnership::Marketplace) {
                // Somebody transferred operational ownership of this product
                // since the import. It is not a trial copy any more — it is a
                // product this marketplace now runs — so undoing the import
                // must not take it away silently. It stops carrying the run
                // for the same reason: the run is over, and the row is ours.
                $keptProducts[] = $productId;
                // Guarded exactly as the branch at the bottom is, and for the
                // same reason: the id can be here from the MANIFEST while the
                // stamp already belongs to a later run.
                if (in_array($productId, $stamped, true)) {
                    $this->products->stampImportRun($productId, '');
                }
                continue;
            }
            // DELETED BY WHAT THE IMPORT MADE, NOT BY THE ROW'S STATUS.
            //
            // ⛔ Until `alpha.92` this called `deleteDraft()`, which refuses
            // any row whose status is not `Draft`. From this round an
            // imported row MIRRORS the shop's status (§1), so every row
            // beside a published product would have been left behind AND
            // un-stamped — invisible to `runs()`, unreachable by a second
            // rollback, and belonging to nothing. Four tests in this class
            // caught it, which is the only reason it is not in the package.
            //
            // The status of an `observed` row is a mirror of somebody else's
            // product and never a publication of ours, so it says nothing
            // about whether the row is a trial copy. What does say so is the
            // pair the import wrote — this run's id and `observed`
            // ownership — and that pair is the guard INSIDE the statement
            // (`alpha.50`), so the ownership check above cannot be raced
            // past it. `deleteObservedFromRun()` also reads the answer of
            // every dependent delete (`alpha.31`), which `deleteDraft()`
            // threw away.
            $notRemoved = $this->products->deleteObservedFromRun($productId, $runId);
            if ($notRemoved === '') {
                $removedProducts++;
                continue;
            }
            if ($notRemoved !== 'not_this_run') {
                // A STORAGE failure, and «نمی‌دانم» is not «it was not
                // mine». Clearing the stamp here would make the row
                // unreachable by the retry this failure exists to invite, so
                // the row keeps its run and the rollback says which part
                // would not go.
                $failedProducts[$productId] = $notRemoved;
                continue;
            }
            // Not this run's row any more. It stops carrying this run for
            // the reason it always did — a row left behind still carrying the
            // run id makes `runs()` resurrect a run that has been undone and
            // offer to undo it again. It is NOT added to `keptProducts`: that
            // list is the narrower «somebody took ownership» case, which the
            // branch above already answers.
            //
            // ⛔ And only when the row still carries THIS run. The id came
            // from the union of the manifest and the stamped rows, so a row
            // can be in the list while its stamp has moved to a LATER run —
            // and clearing it then would destroy that run's own record of the
            // row. The old code cleared unconditionally and could do exactly
            // that; `$stamped` was already read above, so asking costs
            // nothing.
            if (in_array($productId, $stamped, true)) {
                $this->products->stampImportRun($productId, '');
            }
        }
        // The history goes with the products. A rollback that removed the
        // catalogue but left the past orders would leave a shop half-migrated
        // with no way back — and the next import would find its own rows there.
        $removedHistory = $this->history?->deleteRun($runId) ?? 0;
        // The staff, balance and withdrawal records go with them. A rollback
        // that removed the catalogue and left a shop's balance history behind
        // would show figures for an import that no longer exists.
        $removedRecords = $this->shopRecords?->deleteRun($runId) ?? ['staff' => 0, 'balance' => 0, 'withdrawals' => 0];

        // The same union on the vendor side. `0014` stamped products only, and
        // the first evidence run with the manifest deleted removed the
        // products and left the shop standing, reporting «vendors=0» about a
        // profile that was plainly there. Half a fix is not a fix.
        $vendorIds = array_values(array_unique(array_merge(
            array_map('intval', $run['vendors'] ?? []),
            $this->vendors->idsFromImportRun($runId)
        )));
        sort($vendorIds);

        $removedVendors = 0;
        foreach ($vendorIds as $vendorUserId) {
            // The PROFILE goes; the WordPress user does not. The user was
            // Dokan's before this ran and is Dokan's after it.
            if ($this->vendors->deleteEmptyProfile((int) $vendorUserId)) {
                $removedVendors++;
                continue;
            }
            // The shop stays — it has an application of its own, or products
            // that are not this run's. The run does not: clearing the stamp is
            // what makes «the run is gone» true of the rows as well as of the
            // manifest.
            $this->vendors->stampImportRun((int) $vendorUserId, '');
        }
        unset($runs[$runId]);
        $this->options->set(self::RUNS_OPTION, $runs);
        $this->audit->log(AuditEventCatalog::DOKAN_ROLLED_BACK, $this->actorId(), 'migration', $runId, [
            'vendors' => $removedVendors,
            'products' => $removedProducts,
            'history' => $removedHistory,
            'staff' => $removedRecords['staff'],
            'balance' => $removedRecords['balance'],
            'withdrawals' => $removedRecords['withdrawals'],
            'run_id' => $runId,
        ]);
        if ($failedProducts !== []) {
            // Reported BEFORE the kept list, because a storage failure is a
            // rollback that did not finish while a kept row is a rollback
            // that finished and left a decision alone.
            return OperationResult::failure('rollback_not_removed', [
                'run_id' => $runId,
                'vendors' => $removedVendors,
                'products' => $removedProducts,
                'failed' => implode('، ', array_map(
                    static fn (int $id, string $part): string => $id . ':' . $part,
                    array_keys($failedProducts),
                    array_values($failedProducts)
                )),
            ]);
        }
        if ($keptProducts !== []) {
            return OperationResult::failure('rollback_kept_transferred', [
                'run_id' => $runId,
                'vendors' => $removedVendors,
                'products' => $removedProducts,
                'kept' => implode('، ', array_map('strval', $keptProducts)),
            ]);
        }
        return OperationResult::success('dokan_rolled_back', [
            'run_id' => $runId,
            'vendors' => $removedVendors,
            'products' => $removedProducts,
            'history' => $removedHistory,
            'staff' => $removedRecords['staff'],
            'balance' => $removedRecords['balance'],
            'withdrawals' => $removedRecords['withdrawals'],
        ]);
    }

    /** @return array<string,array{vendors:list<int>, products:list<int>, at:string}> */
    /**
     * Every run this install knows about — from the manifest AND from the rows.
     *
     * A run whose process died before writing its first manifest entry exists
     * only as stamped rows, and leaving it out of this list would leave a
     * manager looking at products they cannot undo. So the two sources are
     * merged, and a run present only in the rows is reported with the count
     * read back from them.
     *
     * @return array<string, array{vendors:list<int>, products:list<int>, at?:string, source?:string}>
     */
    public function runs(): array
    {
        $stored = $this->options->get(self::RUNS_OPTION, []);
        $runs = is_array($stored) ? $stored : [];
        foreach ($runs as $runId => $run) {
            $runs[$runId]['source'] = 'manifest';
        }
        // Both tables, because a run killed between the vendor loop and the
        // product loop created a shop and no products at all — and asking
        // only the products would call that run nonexistent.
        $stampedRuns = array_values(array_unique(array_merge(
            $this->products->importRunIds(),
            $this->vendors->importRunIds()
        )));
        rsort($stampedRuns);
        foreach ($stampedRuns as $runId) {
            if (isset($runs[$runId])) {
                continue;
            }
            $runs[$runId] = [
                'vendors' => $this->vendors->idsFromImportRun($runId),
                'products' => $this->products->idsFromImportRun($runId),
                'at' => '',
                // Named so the page can say «this run was interrupted» rather
                // than showing a row with no date and letting somebody guess.
                'source' => 'rows_only',
            ];
        }
        return $runs;
    }

    public function dokanIsPresent(): bool
    {
        return $this->dokan->isAvailable();
    }

    /**
     * @param array{wc_product_id:int, vendor_user_id:int, title:string, sku:string, price_minor:int, stock:int, post_status?:string, price_recorded?:bool, price_not_exact?:bool} $product
     * @return array{0:string, 1:string}
     */
    private function judgeProduct(array $product): array
    {
        if ($this->products->findByWcProduct($product['wc_product_id']) !== null) {
            return [DokanMigrationPlan::SKIP, 'already_owned_by_the_marketplace'];
        }
        if ($this->products->findObservedByWcProduct($product['wc_product_id']) !== null) {
            return [DokanMigrationPlan::SKIP, 'already_mapped_by_an_earlier_run'];
        }
        if ($product['sku'] !== ''
            && $this->products->skuTaken($product['vendor_user_id'], $product['sku'])) {
            // Two products with one SKU is a decision about which is the real
            // one, and nobody here can make it.
            return [DokanMigrationPlan::CONFLICT, 'sku_already_used_in_this_shop'];
        }
        if (array_key_exists('post_status', $product)
            && ProductStatus::forIntakeOf((string) $product['post_status']) === null) {
            // A status this marketplace has no field for. Named rather than
            // mapped to the nearest one: collapsing `private` into
            // «پیش‌نویس» means the first projection turns a published-private
            // product into a draft, and `future` loses its schedule the same
            // way — a public change from an intake.
            //
            // `array_key_exists` and not `??`, because «the reader did not
            // tell me the status» and «the status is one I cannot express»
            // are different problems and only the second is this product's.
            // A reader that supplies no status at all is a shape mismatch,
            // and answering it by putting every product in conflict is a
            // guard wider than the defect (`alpha.60`).
            return [DokanMigrationPlan::CONFLICT, 'status_not_expressible'];
        }
        if (($product['price_not_exact'] ?? false) === true) {
            // The same answer `plan()` already gives a Dokan ORDER whose
            // figure carries more precision than this shop's currency can
            // hold — «never rounded», one row type over. A price moved by half
            // a unit is this plugin changing somebody's catalogue and
            // reporting success.
            return [DokanMigrationPlan::CONFLICT, 'price_not_exact_for_this_currency'];
        }
        if ($product['price_minor'] < 0) {
            return [DokanMigrationPlan::CONFLICT, 'price_is_negative'];
        }
        if (($product['price_recorded'] ?? true) !== true || $product['price_minor'] === 0) {
            // ⛔ NOT A CONFLICT ANY MORE, and this was the owner's thirty-four.
            //
            // `alpha.65` returned `CONFLICT/no_price_recorded` here, so a
            // `draft` or `pending` product nobody had priced yet could not be
            // taken in at all — «محصول draft یا pending نباید فقط به‌دلیل
            // نداشتن قیمت از ورود مسدود شود». It comes in, the row says it has
            // no price (`ProductDetails::hasPrice()` reads nought that way),
            // and three separate things keep that honest without blocking it:
            // `ProductReadiness` refuses to approve or publish it and names
            // `price`, the projector leaves the shop's own price alone from
            // `alpha.66`, and the review page reports it.
            //
            // The verdict carries the reason so the plan can SAY so: an import
            // a manager has to finish is not the same as one they do not.
            return [DokanMigrationPlan::IMPORT, 'imported_without_a_price'];
        }
        return [DokanMigrationPlan::IMPORT, ''];
    }

    /**
     * Write down what this run has created SO FAR — appending, never replacing.
     *
     * The old version built the whole list in memory and wrote it once, after
     * both loops. That made the manifest a record of runs that finished, and
     * only those: a run killed by a PHP timeout half way through had created
     * real rows and left nothing that knew about them, so `rollback()` could
     * not undo it and a re-run had no idea they were there. Appending after
     * every batch means the manifest is always at least as complete as the
     * work, which is the direction the error has to lean.
     *
     * @param array{vendors:list<int>, products:list<int>} $created
     */
    public function rememberRun(string $runId, array $created): void
    {
        $runs = $this->runs();
        $existing = $runs[$runId] ?? ['vendors' => [], 'products' => []];
        $runs[$runId] = [
            'vendors' => array_values(array_unique(array_merge(
                array_map('intval', $existing['vendors'] ?? []),
                $created['vendors']
            ))),
            'products' => array_values(array_unique(array_merge(
                array_map('intval', $existing['products'] ?? []),
                $created['products']
            ))),
            'at' => $this->clock->now()->format('Y-m-d H:i:s'),
        ];
        $this->options->set(self::RUNS_OPTION, $runs);
    }

    /**
     * Import one page of vendors, starting strictly after `$afterUserId`.
     *
     * Idempotent against its cursor, because a worker can die between doing the
     * work and writing the checkpoint: `upsertProfile` on a shop that is
     * already there changes nothing, and the manifest de-duplicates.
     *
     * @return array{done:int, failed:int, recorded:int, last:int, more:bool, created:array{vendors:list<int>, products:list<int>}, notes:list<string>, lease_lost:bool}
     */
    public function importVendorPage(string $runId, int $afterUserId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        $created = ['vendors' => [], 'products' => []];
        $recorded = 0;
        $recordedFailed = 0;
        $notes = [];
        $failed = 0;
        // One page from the reader, not every seller sliced in PHP. The old
        // version read the whole shop on every batch — which is the cost a
        // batched job exists to avoid, paid once per batch instead of once.
        $stopped = '';
        $progress?->entering('page_read', 0);
        $page = $this->dokan->vendorsAfter($afterUserId, $limit);
        $progress?->left();
        $last = $afterUserId;
        $leaseLost = false;
        foreach ($page as $vendor) {
            $id = (int) $vendor['user_id'];
            // The same time question as the product loop, asked before the
            // claim for the same reason. A shop is cheap next to a picture,
            // but `rememberRun()` is called once per shop and this phase is
            // fifty of them in one batch.
            if ($progress !== null && !$progress->keepGoing()) {
                $stopped = $progress->stopReason();
                break;
            }
            // CLAIMED BEFORE THE PROFILE IS WRITTEN, not after it.
            //
            // ⛔ `alpha.72` recorded a unit once it had landed, which left a
            // worker whose lease had been handed on still writing rows into an
            // import it no longer owned. The claim is the guard, and it is
            // only a guard if it comes first.
            if ($progress !== null) {
                $claim = $progress->claim($id);
                if ($claim === UnitClaim::LeaseLost) {
                    $leaseLost = true;
                    break;
                }
                if ($claim === UnitClaim::GiveUp) {
                    $last = $id;
                    $ours = $this->vendors->findProfileByUser($id) !== null;
                    $note = $id . ':' . ($ours
                        ? 'arrived_before_the_worker_died'
                        : 'stalled_after_' . $progress->attempts($id) . '_attempts');
                    $notes[] = $note;
                    $failed += $ours ? 0 : 1;
                    if (!$progress->landed($id, $ours ? 1 : 0, $ours ? 0 : 1, [$note])) {
                        $leaseLost = true;
                        break;
                    }
                    $recorded++;
                    $recordedFailed += $ours ? 0 : 1;
                    continue;
                }
            }
            $last = $id;
            if ($this->vendors->findProfileByUser($last) === null) {
                // canSell false: an imported shop is present, not yet trading.
                $this->vendors->upsertProfile($last, $vendor['store_name'], false, false, $runId);
                $created['vendors'][] = $last;
                if ($progress !== null) {
                    // Per unit, because the manifest has to be at least as
                    // complete as the work (`alpha.55`) and the work is now
                    // recorded per unit too.
                    $this->rememberRun($runId, ['vendors' => [$last], 'products' => []]);
                }
            }
            // Every shop on the page is a unit, the ones already ours
            // included: a page that begins with a skip still has to move.
            if ($progress !== null) {
                if (!$progress->landed($last, 1, 0)) {
                    // The lease is gone: whoever holds the job now is writing
                    // these very rows. Stop and report what landed.
                    $leaseLost = true;
                    break;
                }
                $recorded++;
            }
        }
        if ($created['vendors'] !== [] && $progress === null) {
            $this->rememberRun($runId, $created);
        }
        return [
            // WHAT THE CALLER STILL HAS TO COUNT — and with a sink, nothing.
            //
            // ⛔ This was `count($page) - $recorded`, which is only the same
            // thing while the loop runs to the END of the page. It does not:
            // a batch that stops itself for time breaks out after the units
            // it managed, and the expression then counts every shop it never
            // looked at as done. `JobRepositoryInterface::checkpoint()` adds
            // that delta to `done_count`, so the figure the owner reads on
            // the queue page walks forward over work nobody did — the one
            // number this whole round is trying to make trustworthy.
            //
            // Measured by putting the old expression back and running the
            // suite: the product loop's version reported `done = 50` for a
            // batch that claimed NOTHING at all, because the budget was
            // already spent when it was asked. The vendor loop has the same
            // budget check and the same shape.
            //
            // `$failed` had a second shape of the same fault: the give-up
            // branch raises it AND lands it, so a stalled shop was counted
            // twice. Products already subtracted `$recordedFailed`; this did
            // not.
            'done' => $progress === null ? max(0, count($page) - $failed) : 0,
            'failed' => $progress === null ? $failed : max(0, $failed - $recordedFailed),
            'recorded' => $recorded,
            'last' => $last,
            // A short page is the end. Asking «are there more?» by counting the
            // whole set again would undo the reason for paging at all — and a
            // page the batch stopped itself in is not the end either.
            'more' => $leaseLost ? false : ($stopped !== '' || count($page) >= $limit),
            'created' => $created,
            'notes' => $notes,
            'lease_lost' => $leaseLost,
            'stopped' => $stopped,
        ];
    }

    /**
     * Import one page of products, starting strictly after `$afterProductId`.
     *
     * A row the plan would have called a conflict is counted as failed and
     * SKIPPED rather than aborting the job, because a job that stops on the
     * first bad SKU leaves a half-imported shop and tells the manager nothing
     * about the other 300 rows. The reasons come back in the notes.
     *
     * ⛔ And a page that SKIPS a product does not count it done without
     * asking whether it is finished — see the skip branch, and
     * `importCompletion()` for the report that separates the numbers.
     *
     * @return array{done:int, failed:int, recorded:int, repaired:int, last:int, more:bool, created:array{vendors:list<int>, products:list<int>}, notes:list<string>, lease_lost:bool}
     */
    public function importProductPage(string $runId, int $afterProductId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        $created = ['vendors' => [], 'products' => []];
        $recorded = 0;
        $recordedDone = 0;
        $recordedFailed = 0;
        $repaired = 0;
        $notes = [];
        $failed = 0;
        $leaseLost = false;
        // ⛔ `more` has to be true when the batch stops itself, even on a page
        // shorter than the limit: without this, a budget that ran out on the
        // LAST page would read as «the phase is finished» and the products
        // after this one would never be looked at again.
        $stopped = '';
        $progress?->entering('page_read', 0);
        $page = $this->dokan->productsAfter($afterProductId, $limit);
        $progress?->left();
        $last = $afterProductId;

        // One product is one unit of work AND one unit of record. Everything
        // the caller still has to count is what the sink did not take, so a
        // page that stops half way has already written down the half that
        // landed — see `JobHandlerInterface::step()` for what this cost on
        // staging when it was the page instead.
        $landed = function (int $at, int $done, int $bad, array $note = []) use ($progress, &$recorded, &$recordedDone, &$recordedFailed, &$leaseLost): bool {
            if ($progress === null) {
                return true;
            }
            if (!$progress->landed($at, $done, $bad, $note)) {
                $leaseLost = true;
                return false;
            }
            $recorded++;
            $recordedDone += $done;
            $recordedFailed += $bad;
            return true;
        };

        foreach ($page as $product) {
            $wcId = (int) $product['wc_product_id'];
            $vendorId = (int) $product['vendor_user_id'];

            // THE TIME QUESTION, ASKED BEFORE THE CLAIM.
            //
            // ⛔ Before, not after: claiming a unit raises its attempt count,
            // and a unit counted against without being tried would be three
            // strikes away from being stepped over for something that was
            // never its fault. Between units and never inside one — stopping
            // inside a unit is what the host already does, and the whole
            // point of asking is to not be there when it happens.
            if ($progress !== null && !$progress->keepGoing()) {
                $stopped = $progress->stopReason();
                break;
            }

            // CLAIMED BEFORE THE ROW, THE COPY AND THE MANIFEST.
            //
            // ⛔ Every one of those writes used to happen before anything
            // token-guarded, so the guard arrived too late to be one: measured
            // on `alpha.72`'s own bytes, a worker parked inside the first
            // product's image work, whose job was then handed to a second
            // worker, carried on and wrote a product and an image into an
            // import it no longer owned — `a_wrote_after_losing_the_job=yes`.
            if ($progress !== null) {
                $claim = $progress->claim($wcId);
                if ($claim === UnitClaim::LeaseLost) {
                    $leaseLost = true;
                    break;
                }
                if ($claim === UnitClaim::GiveUp) {
                    $last = $wcId;
                    [$done, $bad, $note] = $this->giveUpOnProduct($wcId, $product, $progress->attempts($wcId));
                    $failed += $bad;
                    if ($note !== '') {
                        $notes[] = $note;
                    }
                    if (!$landed($wcId, $done, $bad, $note === '' ? [] : [$note])) {
                        break;
                    }
                    continue;
                }
            }
            $last = $wcId;

            $progress?->entering('judge', $wcId);
            [$verdict, $reason] = $this->judgeProduct($product);
            $progress?->left();
            if ($verdict === DokanMigrationPlan::CONFLICT) {
                $failed++;
                $notes[] = $wcId . ':' . $reason;
                if (!$landed($wcId, 0, 1, [$wcId . ':' . $reason])) {
                    break;
                }
                continue;
            }
            if ($verdict !== DokanMigrationPlan::IMPORT) {
                // A SKIP means this product is already ours — and that is
                // where `alpha.72` counted it `done` and moved on.
                //
                // ⛔ A MAPPED PRODUCT IS NOT A FINISHED PRODUCT. The row and
                // its mapping are written before the picture is copied, so a
                // worker killed in between leaves a row that exists, is
                // stamped with its run, is findable by its WooCommerce id —
                // and has no image. Measured on `alpha.72`: killed inside the
                // first product's image work and resumed, the import reported
                // `done=8` of 8 with `products_without_image=1`, and nothing
                // anywhere named it. A hundred per cent that is not a hundred
                // per cent is worse than a number that admits it is short.
                //
                // So the skip asks what is MISSING rather than whether a row
                // exists, and finishes it. Nothing is created: the row stays,
                // its id stays, its run stamp stays.
                $mine = $this->products->findObservedByWcProduct($wcId)
                    ?? $this->products->findByWcProduct($wcId);
                $gap = $mine === null ? 'row_vanished_between_two_reads' : $this->importGap($mine->id, $product);
                if ($gap === '') {
                    if (!$landed($wcId, 1, 0)) {
                        break;
                    }
                    continue;
                }
                if ($mine !== null && $gap === 'image') {
                    $repairId = $mine->id;
                    $why = $this->carryImage(
                        $repairId,
                        $vendorId,
                        (int) ($product['source_image_id'] ?? 0),
                        $progress,
                        $wcId,
                        // The manifest has to know about a row it will be
                        // asked to roll back, and a repaired row is one — so
                        // it is written in the SAME hold as the attach rather
                        // than in a second statement after it.
                        $progress === null ? null : function () use ($runId, $repairId): bool {
                            $this->rememberRun($runId, ['vendors' => [], 'products' => [$repairId]]);
                            return true;
                        }
                    );
                    if ($why === 'lease_lost') {
                        $leaseLost = true;
                        break;
                    }
                    if ($why === '') {
                        $repaired++;
                        if (!$landed($wcId, 1, 0)) {
                            break;
                        }
                        continue;
                    }
                    $gap = $why;
                }
                // Still not finished, and said out loud rather than counted.
                $failed++;
                $notes[] = $wcId . ':' . $gap;
                if (!$landed($wcId, 0, 1, [$wcId . ':' . $gap])) {
                    break;
                }
                continue;
            }

            // THE STATUS THE SHOP ACTUALLY HOLDS — see the whole-plan path
            // above for the measured consequence of not recording it. A
            // status this marketplace cannot express is a REFUSAL by name,
            // counted and reported, never the nearest one.
            $toldTheStatus = array_key_exists('post_status', $product);
            $shopStatus = $toldTheStatus ? (string) $product['post_status'] : '';
            $mirrored = $toldTheStatus
                ? ProductStatus::forIntakeOf($shopStatus)
                : ProductStatus::Draft;
            if ($mirrored === null) {
                $last = $wcId;
                $failed++;
                $notes[] = $wcId . ':status_not_expressible';
                if (!$landed($wcId, 0, 1, [$wcId . ':status_not_expressible'])) {
                    break;
                }
                continue;
            }

            $details = new ProductDetails(
                    title: $product['title'],
                    // Mapped, or empty. Empty keeps the product a draft,
                    // which is the visible «somebody must decide this» —
                    // see `CategoryMap`.
                    categoryKey: $this->categories?->marketplaceCategoryFor(
                        (string) ($product['source_category_key'] ?? '')
                    ) ?? '',
                    priceMinor: $product['price_minor'],
                    sku: $product['sku'],
                    // Never below zero.
                    //
                    // Dokan permits backorders, so a live shop really does
                    // carry products at `-2`, and this marketplace's own
                    // validation refuses a negative stock — every such
                    // product would arrive and then be unsaveable, which is
                    // the worst of both. Zero is the conservative reading of
                    // «somebody already sold more than they had»: none
                    // available, nothing oversold twice. The count is
                    // reported, so it is a number the owner sees rather than
                    // a correction nobody was told about.
                    stock: max(0, (int) $product['stock'])
                );

            // THE ROW AND ITS MANIFEST ENTRY, AS ONE UNIT HELD UNDER THE LEASE.
            //
            // The manifest has to be at least as complete as the work
            // (`alpha.55`), and with a per-unit checkpoint that means per
            // unit: a worker killed after this product must leave a manifest
            // that already knows about it. Written BEFORE the picture, because
            // the row exists before the picture does — and inside the same
            // hold, because a lease that went between them would leave a row
            // nothing can roll back.
            //
            // ⛔ The other window the report named is this one, between
            // `claim(unit)` and `create()`. Measured on `alpha.73`'s installed
            // bytes it did NOT produce a duplicate — the UNIQUE key
            // `tmc_product_wc` refuses the stale worker's insert and
            // `create()` answers `0`. That is the schema holding it, not the
            // lease, which is worth knowing: the day that key goes, the window
            // reopens. Now the lease holds it too, and the index remains the
            // second line of defence it was always meant to be.
            $productId = 0;
            $make = function () use (&$productId, $vendorId, $details, $mirrored, $shopStatus, $wcId, $runId, $progress): bool {
                $productId = $this->products->create(
                    $vendorId,
                    $details,
                    $mirrored,
                    LinkOwnership::Observed,
                    // One statement: link and stamp included. The row that
                    // exists is complete, carries the run that made it, and is
                    // findable by its WooCommerce id — so a resumed page finds
                    // it instead of creating a second one.
                    $wcId,
                    $runId,
                    '',
                    // The stamp, in the SAME statement as the row. A row that
                    // exists without it for even one request is a row whose
                    // status the next projection destroys — the reason this is
                    // a parameter rather than a follow-up write
                    // (`ProductRepositoryInterface::create()`). Blank when
                    // the reader named none — «no stamp», not a stamp of
                    // nothing.
                    $shopStatus
                );
                if ($productId === 0) {
                    return false;
                }
                if ($progress !== null) {
                    $this->rememberRun($runId, ['vendors' => [], 'products' => [$productId]]);
                }
                return true;
            };
            if ($progress === null) {
                $make();
            } else {
                $progress->entering('row_and_manifest', $wcId);
                $held = $progress->writing($make);
                $progress->left();
                if ($held === LeaseHold::LeaseLost) {
                    // Nothing was written and nothing is half written. The
                    // product is left for whoever owns the import now.
                    $leaseLost = true;
                    break;
                }
                if ($held === LeaseHold::NotWritten) {
                    // ⛔ Rolled back, so the id the insert handed back names no
                    // row. A value captured by reference does not know a
                    // transaction ended, and carrying it on would attach a
                    // picture to a product that does not exist.
                    $productId = 0;
                }
            }
            if ($productId === 0) {
                $failed++;
                $notes[] = $wcId . ':create_failed';
                if (!$landed($wcId, 0, 1, [$wcId . ':create_failed'])) {
                    break;
                }
                continue;
            }
            $created['products'][] = $productId;

            $why = $this->carryImage($productId, $vendorId, (int) ($product['source_image_id'] ?? 0), $progress, $wcId);
            if ($why === 'lease_lost') {
                $leaseLost = true;
                break;
            }
            if ($why !== '') {
                // The row is in and the picture is not. Counted as failed and
                // NAMED, so the completion report and the next pass both know
                // there is something to finish — rather than a `done` that
                // hides it.
                $failed++;
                $notes[] = $wcId . ':' . $why;
                if (!$landed($wcId, 0, 1, [$wcId . ':' . $why])) {
                    break;
                }
                continue;
            }
            if (!$landed($wcId, 1, 0)) {
                break;
            }
        }
        if ($created['products'] !== [] && $progress === null) {
            // Still written, and still useful — it is where the VENDOR ids
            // live, and vendors have no row of ours to stamp. For products it
            // is now a convenience rather than the source of truth.
            $this->rememberRun($runId, $created);
        }
        return [
            // ⛔ `count($page) - $failed - $recordedDone`, until this round.
            // Same fault as the vendor loop above, and this is where it was
            // measured: with the old expression restored, a batch whose
            // budget was already spent — so not one product was claimed —
            // returned `done = 50`, and the runner's final checkpoint adds
            // that to `done_count`.
            //
            // With a sink every unit's figure has already been written by
            // `landed()`, so what is left for the caller is nought — in every
            // case, not just when the loop reaches the end.
            'done' => $progress === null ? max(0, count($page) - $failed) : 0,
            'failed' => $progress === null ? $failed : max(0, $failed - $recordedFailed),
            'recorded' => $recorded,
            'repaired' => $repaired,
            'last' => $last,
            // A page the lease was taken from is not a page that ended, and
            // neither is a page the batch stopped itself in the middle of.
            'more' => $leaseLost ? false : ($stopped !== '' || count($page) >= $limit),
            'created' => $created,
            'notes' => array_slice($notes, 0, 20),
            'lease_lost' => $leaseLost,
            'stopped' => $stopped,
        ];
    }

    /**
     * What an import really finished — four numbers, not one percentage.
     *
     * «۱۰۰٪» is not an answer on its own and this round is the proof: a job
     * can report every unit done while a product sits in the catalogue with no
     * picture, because the row was written before the picture and only the row
     * was counted. So the report says separately how many products are mapped,
     * how many are finished, how many are missing their picture, how many
     * could not be judged at all, and how many WooCommerce products have more
     * than one row pointing at them.
     *
     * **Derived from the rows and the shop, every time.** No column, no
     * counter, nothing to fall out of date — the same reasoning as
     * `ImportGap()` one method down and as `ImportExistingProducts`.
     *
     * **With no run id it scans every import this catalogue remembers**, which
     * is how a half-made product left by an EARLIER package is found: the job
     * that made it is finished and no batch will ever look at it again.
     *
     * ⛔ `source_unreadable` is not `complete`. A product whose Dokan row has
     * gone cannot be judged, and calling it finished would be the reassuring
     * half of exactly the defect above.
     *
     * @return array{run:string, mapped:int, complete:int, without_image:int, source_unreadable:int, duplicate_mappings:int, duplicates:list<int>, incomplete:list<int>, scanned:int, finished:bool}
     */
    public function importCompletion(string $runId = '', int $limit = 500): array
    {
        $ids = $runId === ''
            ? $this->products->observedFromImportRuns($limit)
            : $this->products->idsFromImportRun($runId);
        $ids = array_slice($ids, 0, $limit);
        $complete = 0;
        $withoutImage = 0;
        $unreadable = 0;
        $incomplete = [];
        foreach ($ids as $id) {
            $product = $this->products->find((int) $id);
            $wcId = (int) ($product?->wcProductId ?? 0);
            if ($product === null || $wcId <= 0) {
                $unreadable++;
                continue;
            }
            $source = $this->dokan->productsAfter($wcId - 1, 1)[0] ?? null;
            // The id is CHECKED, because a paged read answers with the next
            // row when the one asked for has gone — and that row is about a
            // different product.
            if ($source === null || (int) $source['wc_product_id'] !== $wcId) {
                $unreadable++;
                continue;
            }
            if ($this->importGap((int) $id, $source) === '') {
                $complete++;
                continue;
            }
            $withoutImage++;
            if (count($incomplete) < 50) {
                $incomplete[] = (int) $id;
            }
        }
        $duplicates = $this->products->duplicateWcMappings(50);
        return [
            'run' => $runId,
            'mapped' => count($ids),
            'complete' => $complete,
            'without_image' => $withoutImage,
            'source_unreadable' => $unreadable,
            'duplicate_mappings' => count($duplicates),
            'duplicates' => $duplicates,
            'incomplete' => $incomplete,
            'scanned' => count($ids),
            // Whether the scan saw everything. A bounded read that stopped at
            // its ceiling is not «no more» (`alpha.69`).
            'finished' => count($ids) < $limit,
        ];
    }

    /**
     * Finish the half-made imports, and only the half-made part of them.
     *
     * The row is never recreated and never touched: this copies the picture
     * that was already on the WooCommerce product and attaches it. The same
     * shape as `ImportExistingProducts::repair()` — a resumable path for work
     * that a batch will not come back to, because the job that owned it has
     * already finished.
     *
     * @return OperationResult carrying `repaired`, `still_incomplete` and
     *                         `refused` — the ids that could not be finished,
     *                         with the reason for each
     */
    public function repairImports(string $runId = '', int $limit = 50): OperationResult
    {
        if ($this->capabilities === null || !$this->capabilities->can(Capabilities::REVIEW_VENDOR)) {
            return OperationResult::failure('forbidden');
        }
        $report = $this->importCompletion($runId, 500);
        $repaired = 0;
        $refused = [];
        foreach (array_slice($report['incomplete'], 0, $limit) as $id) {
            $product = $this->products->find((int) $id);
            $wcId = (int) ($product?->wcProductId ?? 0);
            if ($product === null || $wcId <= 0) {
                $refused[] = $id . ':row_unreadable';
                continue;
            }
            $source = $this->dokan->productsAfter($wcId - 1, 1)[0] ?? null;
            if ($source === null || (int) $source['wc_product_id'] !== $wcId) {
                $refused[] = $id . ':source_unreadable';
                continue;
            }
            $why = $this->carryImage(
                (int) $id,
                (int) $product->vendorUserId,
                (int) ($source['source_image_id'] ?? 0),
                null
            );
            if ($why !== '') {
                $refused[] = $id . ':' . $why;
                continue;
            }
            if ($runId !== '') {
                $this->rememberRun($runId, ['vendors' => [], 'products' => [(int) $id]]);
            }
            $repaired++;
        }
        $this->audit->log(
            AuditEventCatalog::DOKAN_IMPORT_REPAIRED,
            $this->actorId(),
            'migration',
            $runId === '' ? 'every-import' : $runId,
            [
                'run_id' => $runId,
                'repaired' => $repaired,
                // Names, not a count: a manager reading the trail needs to
                // know WHICH product is still unfinished.
                'refused' => implode('، ', array_map('strval', $refused)),
            ]
        );
        return OperationResult::success('import_repaired', [
            'repaired' => $repaired,
            // A string, because `OperationResult` carries scalars — and names
            // rather than a count, because «two products are still
            // unfinished» does not tell a manager which two.
            'refused' => implode('، ', array_map('strval', $refused)),
            'still_incomplete' => max(0, count($report['incomplete']) - $repaired),
        ]);
    }

    /**
     * What this import still owes a product that is already mapped.
     *
     * `''` means finished. Otherwise the name of the part that is missing,
     * which today is only ever `image` — the row carries its title, price,
     * stock and category from the one statement that created it, so the
     * picture is the only thing written separately and therefore the only
     * thing that can be half there.
     *
     * **Derived, never stored.** The same shape as
     * `ImportExistingProducts::incomplete()`: completeness is decided by
     * comparing the row with the shop, so there is no column to go stale and
     * no state to be wrong about. A product whose source has no picture at
     * all is FINISHED without one — «نداشتن تصویر» and «نرسیدنِ تصویر» are
     * different facts and only the second is a gap.
     *
     * @param array<string,mixed> $product the Dokan row, carrying `source_image_id`
     */
    public function importGap(int $productId, array $product): string
    {
        $source = (int) ($product['source_image_id'] ?? 0);
        if ($source <= 0 || $this->images === null) {
            return '';
        }
        return $this->products->images($productId) === [] ? 'image' : '';
    }

    /**
     * Copy the source picture into the vendor's own media and attach it.
     *
     * The picture needs no decision at all — unlike the CATEGORY, with its two
     * vocabularies and no reliable correspondence — it is the same photograph
     * of the same product, hanging on the very WooCommerce post this row now
     * points at. Carrying it is not a guess; leaving it behind would make
     * every migrated product fail readiness with `missing_image` and wait for
     * somebody to re-upload a file that is already there.
     *
     * COPIED into the vendor's own media, not referenced: the gallery only
     * keeps images the vendor owns, so a reference survives the import and
     * then vanishes the first time the vendor saves the product, which is the
     * worst possible moment to lose it.
     *
     * **The lease is asked again between the copy and the attach**, because
     * the copy is the slow half — and ⛔ **of its two parts only one is
     * slow**, which this sentence used to blur: measured with nothing
     * registered on the filter at all, the `copy()` is well under a
     * millisecond and `wp_generate_attachment_metadata()` is 203 ms for an
     * 800-pixel source and 5.8 to 6.6 SECONDS for a 4500-pixel one. Both are
     * named and timed separately from `alpha.75`, because on
     * network-backed storage the copy could still be the slow one.
     * It is where a host gives up.
     * A worker that lost the job in there must attach nothing, and must not
     * leave its copy lying about either: the three conditions from `alpha.42`
     * decide that discard and all three are required — this request made it,
     * the vendor owns it, and nothing points at it. ⛔ No sweep, no age cut,
     * and never the WooCommerce original, which belongs to whoever uploaded
     * it.
     *
     * @return string `''` when the picture is on the product; otherwise
     *                `no_source`, `image_not_copied`, `image_not_attached`
     *                or `lease_lost`
     */
    private function carryImage(
        int $productId,
        int $vendorUserId,
        int $sourceImageId,
        ?ImportProgressInterface $progress,
        int $unitId = 0,
        ?\Closure $andThen = null
    ): string {
        if ($sourceImageId <= 0 || $this->images === null) {
            return '';
        }
        // THE SLOW HALF, AND IT IS OUTSIDE THE LEASE ON PURPOSE. A file copy
        // and a full `wp_generate_attachment_metadata()` must not run while a
        // row every worker of this type needs is held.
        //
        // ⛔ AND «HALF» IS ONE OF THE TWO, NOT BOTH — a correction to the
        // sentence above, which read as though the copy and the metadata were
        // comparable costs. Measured on the disposable environment with
        // nothing registered on `wp_generate_attachment_metadata` at all: the
        // copy is 0.15–0.80 ms and the metadata 203 ms at 800 pixels, rising
        // to 5.8–6.6 SECONDS at 4500. Three hundred to eight thousand times.
        // So the two are named and timed apart: on network-backed storage the
        // copy could still be the slow one, and assuming it is not is how a
        // diagnosis goes wrong.
        $ownCopy = $this->images->duplicateForVendor(
            $sourceImageId,
            $vendorUserId,
            $progress === null
                ? null
                : static function (string $step) use ($progress, $unitId): void {
                    // Named as each half STARTS, so a worker the host cuts
                    // off in one leaves that name behind. The answer is
                    // deliberately not acted on: a refused write here means
                    // the lease is gone, which `writing()` below reports
                    // properly — and abandoning the copy half way would leave
                    // a file with no row rather than a row with no file.
                    $progress->entering($step, $unitId);
                }
        );
        $progress?->left();
        if ($ownCopy <= 0) {
            return 'image_not_copied';
        }
        if ($progress === null) {
            // No lease to hold, and therefore nothing that could go stale:
            // the tools' and the preview's path.
            if (!$this->products->saveImages($productId, [$ownCopy], $ownCopy)) {
                $this->handBack($ownCopy, $vendorUserId);
                return 'image_not_attached';
            }
            return '';
        }
        // AND THE ATTACH IS INSIDE IT — one unit of work with the question it
        // depends on, not after an answer to it.
        //
        // ⛔ `alpha.73` asked `stillOurs()` here and then called
        // `saveImages()`, and the gap between those two statements is the
        // whole defect: measured on its own bytes, a worker parked in it was
        // refused at its next checkpoint and had ALREADY replaced the picture
        // a second worker attached, leaving that worker's copy orphaned. A
        // refusal after the write is a report.
        // `$andThen` rides INSIDE the same hold, because the manifest entry for
        // a row is not a separate decision from the row being finished: a
        // lease that went between the two would leave the manifest short by a
        // product, and a manifest shorter than the work is the direction
        // `alpha.55` says the error must never lean.
        $progress->entering('attach', $unitId);
        $held = $progress->writing(
            fn (): bool => $this->products->saveImages($productId, [$ownCopy], $ownCopy)
                && ($andThen === null || $andThen() === true)
        );
        $progress->left();
        if ($held === LeaseHold::Held) {
            return '';
        }
        // Either way nothing of ours is on the product, so the copy goes
        // back — under all three of `alpha.42`'s conditions, which
        // `handBack()` keeps in one place.
        $this->handBack($ownCopy, $vendorUserId);
        return $held === LeaseHold::LeaseLost ? 'lease_lost' : 'image_not_attached';
    }

    /**
     * Give a copy back, and only a copy this request made that nothing points
     * at.
     *
     * ⛔ A read that FAILED means «in use»: `mediaInUse()` answers `true` when
     * it could not look, because the cost of keeping an unused file is a file
     * and the cost of the other answer is somebody's photograph (`alpha.43`).
     * No sweep, no age cut, and never the WooCommerce original.
     */
    private function handBack(int $ownCopy, int $vendorUserId): void
    {
        if ($this->images === null) {
            return;
        }
        if (!$this->products->mediaInUse($ownCopy)) {
            $this->images->discard($ownCopy, $vendorUserId);
        }
    }

    /**
     * Give up on one product, and say which kind of giving up it is.
     *
     * Three answers, because the position may have killed three workers for
     * three different reasons: the row arrived in one of those attempts and
     * only its bookkeeping was lost; the row arrived and is still missing its
     * picture; or nothing arrived at all. Counting the first as a failure
     * would blame a row that is sitting there complete, and counting the
     * second as done is the very defect this round is about.
     *
     * @param array<string,mixed> $product
     * @return array{0:int, 1:int, 2:string} done, failed, note
     */
    private function giveUpOnProduct(int $wcId, array $product, int $attempts): array
    {
        $mine = $this->products->findObservedByWcProduct($wcId)
            ?? $this->products->findByWcProduct($wcId);
        if ($mine === null) {
            return [0, 1, $wcId . ':stalled_after_' . $attempts . '_attempts'];
        }
        $gap = $this->importGap($mine->id, $product);
        if ($gap === '') {
            return [1, 0, $wcId . ':arrived_before_the_worker_died'];
        }
        return [0, 1, $wcId . ':' . $gap . '_missing_after_' . $attempts . '_attempts'];
    }

    /**
     * Import one page of past orders, starting strictly after `$afterOrderId`.
     *
     * Nothing is computed. Each row carries the four numbers Dokan recorded —
     * total, the seller's net, the difference it called commission, and whether
     * it was refunded — and no rate from this marketplace touches any of them.
     * No ledger line is written, so settlement, the balance and every report
     * stay blind to these orders: Dokan owned them, and one engine stays
     * responsible per order.
     *
     * @return array{done:int, skipped:int, last:int, more:bool}
     */
    public function importOrderPage(string $runId, int $afterOrderId, int $limit, ?ImportProgressInterface $progress = null): array
    {
        if ($this->history === null) {
            return ['done' => 0, 'recorded' => 0, 'skipped' => 0, 'failed' => 0, 'already_ours' => 0, 'last' => $afterOrderId, 'more' => false, 'lease_lost' => false];
        }
        $stopped = '';
        $progress?->entering('page_read', 0);
        $page = $this->dokan->ordersAfter($afterOrderId, $limit);
        $progress?->left();
        $last = $afterOrderId;
        $done = 0;
        $skipped = 0;
        $failed = 0;
        $ours = 0;
        $recorded = 0;
        $leaseLost = false;
        foreach ($page as $order) {
            $id = (int) $order['wc_order_id'];
            if ($progress !== null && !$progress->keepGoing()) {
                $stopped = $progress->stopReason();
                break;
            }
            // Claimed before it is recorded, for the same reason a product is.
            // An order carries no media and no second write, so there is no
            // half-made order to finish — but a worker that has lost the job
            // must still not write history into it.
            if ($progress !== null) {
                $claim = $progress->claim($id);
                if ($claim === UnitClaim::LeaseLost) {
                    $leaseLost = true;
                    break;
                }
                if ($claim === UnitClaim::GiveUp) {
                    $last = max($last, $id);
                    $failed++;
                    if (!$progress->landed($last, 0, 0, [$id . ':stalled_after_' . $progress->attempts($id) . '_attempts'])) {
                        $leaseLost = true;
                        break;
                    }
                    continue;
                }
            }
            $last = max($last, $id);
            // «already there» is a resumed job re-running its last page, which
            // is normal. «failed» is not, and counting it as the first would
            // report a shop as migrated on the strength of writes that never
            // landed.
            $counted = 0;
            if ($this->orderIsAlreadyOurs((int) $order['wc_order_id'])) {
                $ours++;
            } elseif (($order['amount_not_exact'] ?? false) === true) {
                $skipped++;             // the figure cannot be held exactly
            } else {
                match ($this->history->record($runId, $order)) {
                    OrderHistoryRepositoryInterface::RECORDED => $counted = 1,
                    OrderHistoryRepositoryInterface::ALREADY => $skipped++,
                    default => $failed++,
                };
            }
            $done += $counted;
            // Every order is a unit, including one this run skips: the cursor
            // has to get past it or a resumed page that begins with a skip
            // never moves. A skip carries NO count, so the figure stays the one
            // this phase meant — only the position changes.
            if ($progress !== null) {
                if (!$progress->landed($last, $counted, 0)) {
                    $leaseLost = true;
                    break;
                }
                $recorded += $counted;
            }
        }
        return [
            'done' => max(0, $done - $recorded),
            'recorded' => $recorded,
            'skipped' => $skipped,
            'failed' => $failed,
            'already_ours' => $ours,
            'last' => $last,
            'more' => $leaseLost ? false : ($stopped !== '' || count($page) >= $limit),
            'lease_lost' => $leaseLost,
            'stopped' => $stopped,
        ];
    }

    /**
     * The id of the NEXT unit in a phase, or null when the phase is over.
     *
     * Only one caller: the job, when a position has killed enough workers that
     * trying it again is not a plan. Naming that one row is the difference
     * between «183 of 184 products arrived and this one is named» and «nothing
     * arrived and nobody knows why» — and it reads, it does not write.
     */
    public function unitAfter(string $phase, int $afterId): ?int
    {
        $row = match ($phase) {
            'vendors' => $this->dokan->vendorsAfter($afterId, 1)[0]['user_id'] ?? null,
            'products' => $this->dokan->productsAfter($afterId, 1)[0]['wc_product_id'] ?? null,
            'orders' => $this->dokan->ordersAfter($afterId, 1)[0]['wc_order_id'] ?? null,
            // The three record kinds. Named with a suffix so a cursor can
            // never be read as the product import's phase of the same word:
            // «staff» would collide with nothing today and the collision is
            // the kind that is found by a bug report.
            'staff_records' => $this->dokan->vendorsAfter($afterId, 1)[0]['user_id'] ?? null,
            'balance_records' => $this->dokan->balanceRowsAfter($afterId, 1)[0]['row_id'] ?? null,
            'withdrawal_records' => $this->dokan->withdrawalsAfter($afterId, 1)[0]['withdraw_id'] ?? null,
            default => null,
        };
        return $row === null ? null : (int) $row;
    }

    /**
     * Has this unit already arrived?
     *
     * Asked by the job before it blames a position for killing workers. A unit
     * that landed in a dying attempt — created, and gone before its checkpoint
     * ran — is the one thing that can sit at a stalled cursor and be perfectly
     * fine; counting it as refused would name an innocent row, and the number
     * on the page would then be wrong in the other direction.
     */
    public function unitIsAlreadyOurs(string $phase, int $id): bool
    {
        return match ($phase) {
            'vendors' => $this->vendors->findProfileByUser($id) !== null,
            'products' => $this->products->findByWcProduct($id) !== null
                || $this->products->findObservedByWcProduct($id) !== null,
            'orders' => $this->orderIsAlreadyOurs($id),
            default => false,
        };
    }

    /** What a shop's imported history adds up to, in Dokan's own figures. */
    public function historyFor(int $vendorUserId): array
    {
        if ($this->history === null) {
            return ['orders' => 0, 'total_minor' => 0, 'net_minor' => 0, 'available' => false];
        }
        return $this->history->summaryForVendor($vendorUserId) + ['available' => true];
    }

    /**
     * Record the audit line that closes a run. Separate from the loops because
     * a resumable import finishes in a different request from the one that
     * started it.
     */
    public function finishRun(string $runId, int $vendors, int $products, int $skipped): void
    {
        $this->audit->log(AuditEventCatalog::DOKAN_IMPORTED, $this->actorId(), 'migration', $runId, [
            'vendors' => $vendors,
            'products' => $products,
            'skipped' => $skipped,
            'run_id' => $runId,
            'mode' => 'trial',
        ]);
    }

    /** What a run has created so far, for a progress report mid-import. */
    public function runProgress(string $runId): array
    {
        $run = $this->runs()[$runId] ?? ['vendors' => [], 'products' => []];
        return [
            'vendors' => count($run['vendors'] ?? []),
            'products' => count($run['products'] ?? []),
        ];
    }

    private function actorId(): int
    {
        return $this->capabilities?->currentUserId() ?? 0;
    }
}
