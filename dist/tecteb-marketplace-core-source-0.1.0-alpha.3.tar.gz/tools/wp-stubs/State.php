<?php
declare(strict_types=1);

namespace TmcWpStubs;

final class State
{
    /** @var array<string,mixed> */
    public static array $options = [];
    /** @var array<string,mixed> */
    public static array $transients = [];
    /** @var array<string,array<string,mixed>> */
    public static array $cache = [];
    /** @var array<string,array<int,list<callable>>> */
    public static array $hooks = [];
    /** @var list<array{tag:string,args:array}> */
    public static array $firedActions = [];
    /** @var array<string,array<string,bool>> */
    public static array $roles = ['administrator' => ['manage_options' => true, 'activate_plugins' => true]];
    /** @var list<string> */
    public static array $currentUserCaps = [];
    public static int $currentUserId = 0;
    public static bool $multisite = false;
    /** When true, option writes fail the way a storage error would. */
    public static bool $failOptionWrites = false;
    /**
     * When true, the option functions read and write the REAL options table
     * through $wpdb instead of the in-process array. The database suite turns
     * this on so that options and the guarded single-statement writes share
     * one storage layer, as they do in WordPress.
     */
    public static bool $optionsBackedByWpdb = false;
    public static string $environmentType = 'production';
    public static string $homeUrl = 'https://example.test';
    public static string $wpVersion = 'stub';
    /** @var list<array<string,mixed>> */
    public static array $menus = [];
    /** @var array<string,array<string,mixed>> */
    public static array $registeredSettings = [];
    /** @var list<array{setting:string,code:string,message:string,type:string}> */
    public static array $settingsErrors = [];
    /** @var array<string,array<string,mixed>> */
    public static array $enqueued = ['style' => [], 'script' => []];
    /** @var array<string,array<string,mixed>> */
    public static array $restRoutes = [];
    /** @var list<string> */
    public static array $clearedScheduledHooks = [];
    /** @var list<string> */
    public static array $output = [];
    /** @var list<string> */
    public static array $wpDieCalls = [];

    // Vendor phase: the front-end route, its redirects and its file storage.
    /** @var array<string,string> */
    public static array $rewriteRules = [];
    public static int $rewriteFlushes = 0;
    /** @var array<string,mixed> */
    public static array $queryVars = [];
    /** @var list<array{location:string,status:int}> */
    public static array $redirects = [];
    /** @var array<int,array<string,string>> */
    public static array $users = [];
    public static ?string $uploadBaseDir = null;
    /** @var list<string> */
    public static array $sentHeaders = [];
    public static ?int $statusHeader = null;

    public static function reset(): void
    {
        self::$options = [];
        self::$transients = [];
        self::$cache = [];
        self::$hooks = [];
        self::$firedActions = [];
        self::$roles = ['administrator' => ['manage_options' => true, 'activate_plugins' => true]];
        self::$currentUserCaps = [];
        self::$currentUserId = 0;
        self::$multisite = false;
        self::$failOptionWrites = false;
        self::$optionsBackedByWpdb = false;
        self::$environmentType = 'production';
        self::$homeUrl = 'https://example.test';
        self::$menus = [];
        self::$registeredSettings = [];
        self::$settingsErrors = [];
        self::$enqueued = ['style' => [], 'script' => []];
        self::$restRoutes = [];
        self::$clearedScheduledHooks = [];
        self::$rewriteRules = [];
        self::$rewriteFlushes = 0;
        self::$queryVars = [];
        self::$redirects = [];
        self::$users = [];
        self::$uploadBaseDir = null;
        self::$sentHeaders = [];
        self::$statusHeader = null;
        self::$output = [];
        self::$wpDieCalls = [];
        $_REQUEST = [];
        $_POST = [];
        $_GET = [];
    }

    /**
     * Starts a NEW REQUEST: clears everything WordPress rebuilds per request
     * (hooks, menus, enqueued assets, routes, settings errors) while keeping
     * what actually persists (options, transients, roles, object cache, the
     * logged-in user). Lets one test process model "activate, then the next
     * page load" the way WordPress really sequences it.
     */
    public static function newRequest(): void
    {
        self::$hooks = [];
        self::$firedActions = [];
        self::$menus = [];
        self::$registeredSettings = [];
        self::$settingsErrors = [];
        self::$enqueued = ['style' => [], 'script' => []];
        self::$restRoutes = [];
        self::$output = [];
        self::$wpDieCalls = [];
    }

    /** Log in a synthetic user with the given capabilities. */
    public static function loginAs(int $id, array $caps): void
    {
        self::$currentUserId = $id;
        self::$currentUserCaps = $caps;
    }

    public static function logout(): void
    {
        self::$currentUserId = 0;
        self::$currentUserCaps = [];
    }
}
