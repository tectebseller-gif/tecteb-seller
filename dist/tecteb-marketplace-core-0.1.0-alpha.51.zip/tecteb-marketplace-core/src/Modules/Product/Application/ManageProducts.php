<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Application;

use Tecteb\Marketplace\Contracts\Files\UploadedFile;
use Tecteb\Marketplace\Core\Audit\AuditEventCatalog;
use Tecteb\Marketplace\Core\Audit\AuditLogger;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\ProductCreation;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRevision;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStateMachine;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRowVersion;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;
use Tecteb\Marketplace\Modules\Product\Domain\PurchaseQuantity;
use Tecteb\Marketplace\Modules\Product\Domain\ProductType;
use Tecteb\Marketplace\Modules\Product\Domain\SensitiveChange;
use Tecteb\Marketplace\Modules\Vendor\Application\OperationResult;
use Tecteb\Marketplace\Modules\Vendor\Application\StaffAccess;
use Tecteb\Marketplace\Modules\Vendor\Domain\StaffArea;
use Tecteb\Marketplace\Modules\Vendor\Domain\StaffLevel;

/**
 * Everything a vendor (or their staff) does to their own catalogue.
 *
 * Three rules run through every method here:
 *
 *  - the shop is an ARGUMENT and the row is fetched with it, so a product id
 *    from another shop returns "not found" rather than somebody else's data
 *    (AC-PRIV);
 *  - a live product is never edited in place. A sensitive change becomes a
 *    revision and the published version stays exactly as buyers see it,
 *    while stock and its neighbours apply at once (§4.2, A.1);
 *  - nothing here publishes unless the marketplace granted that shop direct
 *    publishing separately from the right to sell.
 *
 * OperationResult and StaffAccess are the vendor module's: the same result
 * shape reaches the same notice renderer, and there is exactly one authority
 * on "may this user act in this shop" rather than a second, drifting copy.
 */
final class ManageProducts
{
    /** A gallery any larger is a mistake, not a catalogue. */
    public const MAX_IMAGES = 12;

    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly SpecTemplateRepositoryInterface $templates,
        private readonly ProductRevisionRepositoryInterface $revisions,
        private readonly ProductReadiness $readiness,
        private readonly SyncCatalog $catalog,
        private readonly ProductImageLibraryInterface $images,
        private readonly StaffAccess $access,
        private readonly ProductPublishPolicy $publishing,
        private readonly ProductStateMachine $states,
        private readonly AuditLogger $audit,
        /**
         * Append-only. A resubmission is a line in the history too — without
         * it the manager reads «نیازمند اصلاح» and «ارسال شد» as one event
         * and cannot tell which version their own note was about.
         */
        private readonly ?ProductDecisionRepositoryInterface $decisions = null,
        /**
         * The brand registry, appended with a default.
         *
         * Null means «no registry in this build», and the gate then stands
         * down — which is the same thing `NullBrandDirectory` says and for the
         * same reason. Appended rather than inserted so every existing caller
         * and every test of the four previous rounds keeps compiling
         * (`alpha.45`'s convention).
         */
        private readonly ?ManageBrands $brands = null
    ) {
    }

    /**
     * The brand gate, asked by every path that writes a brand.
     *
     * One place, because §4 asks for one rule and three sentences that happen
     * to agree today are three rules tomorrow (`alpha.46`). An unchanged brand
     * is never re-judged, which is what lets a product whose brand is legacy
     * free text go on being saved: the owner asked that old brands not be
     * touched or declared approved, and refusing their every save would be
     * both.
     */
    /**
     * «ساختار سالم نیست» — asked BEFORE anything is written, and named.
     *
     * THE FINDING THIS CLOSES, carried open through three rounds: a column of
     * the right name and the wrong shape makes a migration's `verify()` refuse
     * — correctly — and does nothing at all to the write. Measured on
     * `alpha.45`: with `purchase_step` nullable and defaulting to nought, the
     * schema version stayed at 23 and saving a product still landed, carrying
     * the wrong default into a row that `PurchaseQuantity::of()` then read as
     * 1. Nothing looked wrong anywhere. The protection was an ORDER — confirm
     * the structure, then save — and an order is not a guard.
     *
     * The repository refuses the write as well (`mayWrite()`), because a path
     * that forgot to ask must still not store wrong data. This exists so that
     * the refusal has a SENTENCE: «ذخیره نشد، چون این ستون‌ها…» is something a
     * person can act on, and a bare `storage_failed` is not.
     *
     * The shape is read, not the version — «شمارهٔ ساختار به‌تنهایی کافی نیست»
     * — and a column that is MISSING comes back here too, so «the structure is
     * behind» is covered by the same question. One memoised query per request,
     * so the healthy path is not stopped and barely notices.
     */
    private function structureRefusal(): ?OperationResult
    {
        $unsound = $this->products->unsoundColumns();
        if ($unsound !== []) {
            return OperationResult::failure('schema_unsound', ['columns' => implode(',', $unsound)]);
        }
        // UNKNOWN IS NOT SOUND. `alpha.48` read an empty list as a clean bill
        // of health, so a failed `information_schema` read allowed the write:
        // measured, `reads_as_sound=yes problem=product_table_unreadable
        // wrote=1`. It has its own code because «این ستون‌ها غلط‌اند» must
        // never be said about a question that could not be asked.
        if (!$this->products->structureKnown()) {
            return OperationResult::failure('schema_unknown', []);
        }
        return null;
    }

    private function brandRefusal(ProductDetails $details, string $currentBrand): ?OperationResult
    {
        return $this->brands?->refusalFor($details->brand, $currentBrand);
    }

    /**
     * Store which approved brand this product's brand IS, once it is written.
     *
     * Best effort and said so: the name is already on the row and is what a
     * shopper sees, so a failure here loses only the identity — which is why
     * `brandTermIdOf()` returning null means «not known», never «no brand».
     *
     * **AN EMPTY BRAND CLEARS THE TERM.** Found by reviewing the one-field
     * path: this method used to return early on an empty name, so a product
     * whose brand had just been REMOVED kept a `brand_term_id` pointing at the
     * brand it used to have. The form resolves that id to survive a rename, so
     * a stale one would show the removed brand in the box and the next save
     * would put it back — a field undoing the vendor's own deletion.
     */
    private function rememberBrandTerm(int $productId, ProductDetails $details): void
    {
        if ($this->brands === null) {
            return;
        }
        if ($details->brand === '') {
            $this->products->setBrandTerm($productId, '', null);
            return;
        }
        $termId = $this->brands->approvedTermFor($details->brand);
        if ($termId !== null) {
            $this->products->setBrandTerm($productId, $details->brand, $termId);
        }
    }

    /**
     * Creates a draft or saves an existing one.
     *
     * @param array<string,string> $specs
     * @param list<int> $imageIds
     */
    /**
     * Saving somebody else's newer work is the one failure a form cannot
     * undo, so `$revision` exists to stop it.
     *
     * A shop with staff has two people who can open the same product, and the
     * old behaviour was last-write-wins with no trace: the second save
     * overwrote the first and neither person was told. The form carries the
     * `updated_at` it was rendered from, and a save whose token no longer
     * matches the row is REFUSED — with both values reported, so the editor
     * decides which is right. An empty token skips the check, because a form
     * from an older build has nothing to compare and refusing it would break
     * saving for anybody mid-edit across an upgrade.
     */
    public function save(
        int $actorId,
        int $vendorUserId,
        int $productId,
        ProductDetails $details,
        array $specs = [],
        array $imageIds = [],
        int $mainImageId = 0,
        string $revision = '',
        string $createToken = ''
    ): OperationResult {
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return OperationResult::failure('forbidden');
        }
        $unsound = $this->structureRefusal();
        if ($unsound !== null) {
            return $unsound;
        }
        // BEFORE validation, and that placement is the point. A replay carries
        // the same SKU as the submission that already succeeded, so validating
        // first answers `sku_taken` — a true sentence about the product this
        // very form made, and useless to the vendor whose browser resent the
        // request after a timeout. The submission has already been processed;
        // its answer is the product it produced.
        if ($productId <= 0 && $createToken !== '') {
            $already = $this->products->findByCreateToken($vendorUserId, $createToken);
            if ($already > 0) {
                // NOT `product_created`. Until `alpha.42` a replay answered
                // with the code a first, complete create answers with — so a
                // submission whose gallery or specifications had failed came
                // back as an unqualified success about a product that is half
                // written. It reports the row instead, and writes nothing.
                return $this->replayed($vendorUserId, $already);
            }
        }
        $problem = $this->validate($vendorUserId, $details, $productId);
        if ($problem !== null) {
            return $problem;
        }
        $specProblem = $this->rejectImpossibleSpecs($details->categoryKey, $specs);
        if ($specProblem !== null) {
            return $specProblem;
        }
        [$imageIds, $mainImageId] = $this->cleanImages($imageIds, $mainImageId, $vendorUserId);

        if ($productId <= 0) {
            // A new product has no brand to be unchanged, so anything it names
            // has to come from the manager's list.
            $brandProblem = $this->brandRefusal($details, '');
            if ($brandProblem !== null) {
                return $brandProblem;
            }
            return $this->create($vendorUserId, $details, $specs, $imageIds, $mainImageId, $createToken);
        }

        $product = $this->products->findOwned($productId, $vendorUserId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        // Before any write, and against what the row HOLDS. A brand that has
        // not changed is never judged — the legacy free-text brands on the
        // owner's shop would otherwise make every save of those products fail.
        $brandProblem = $this->brandRefusal($details, $product->details->brand);
        if ($brandProblem !== null) {
            return $brandProblem;
        }
        // The version's VALUE is still not compared here — that belongs in the
        // UPDATE's WHERE clause, because a comparison between a read and a
        // write is a check two concurrent editors both pass.
        //
        // Its SHAPE is checked here, and refused. A form with no stamp, or one
        // carrying an `alpha.13` timestamp, used to be written unguarded: the
        // one submission that could not be checked was the one allowed through
        // without checking. Now it is refused with a code of its own, the
        // vendor's values are kept by the caller, and the form comes back
        // carrying the row's CURRENT counter — so the second submission is
        // guarded and goes through, and nothing they typed was lost.
        if (!ProductRowVersion::isUsable($revision)) {
            return OperationResult::failure('revision_missing', [
                'product_id' => $product->id,
                'current_revision' => $this->products->rowVersion($product->id),
            ]);
        }
        return match (true) {
            $product->status === ProductStatus::Submitted => OperationResult::failure('in_review'),
            $product->status === ProductStatus::Archived => OperationResult::failure('product_archived'),
            $product->status->isEditableByVendor() => $this->saveInPlace($product, $details, $specs, $imageIds, $mainImageId, $revision),
            default => $this->saveAsRevision($product, $details, $specs, $imageIds, $mainImageId, $revision),
        };
    }

    /**
     * SKU and purchase limits at once; stock at once until the product is live.
     *
     * A.1 put the whole of inventory on the immediate side, and the OWNER'S
     * DECISION of 11 October splits it: on a PUBLISHED product a vendor's
     * stock edit becomes a proposal the manager approves, while the SKU and
     * the three purchase limits keep going straight through. The cost is
     * stated rather than hidden — a vendor who has just sold their last unit
     * can no longer take the product down themselves, which is the queue
     * between a sale and its stock A.1 warned about — and the decision is the
     * owner's to make.
     *
     * What does NOT wait is WooCommerce's own cycle. A sale reducing stock and
     * a refund putting it back are not a vendor's proposal: they run through
     * `pullStock()` and `increaseStock()`, neither of which this method
     * touches. Only the vendor saying a number is a proposal.
     *
     * And the limits are written THROUGH to the shop here. Until `alpha.48`
     * they were not written anywhere: the row was updated and the three meta
     * rows on the shop product arrived only with the next `project()`, which
     * on a published product is an approval away.
     */
    public function updateInventory(
        int $actorId,
        int $vendorUserId,
        int $productId,
        int $stock,
        string $sku,
        int $minPurchase,
        ?int $maxPurchase,
        // Appended with a default, so every existing caller — the tests of
        // three previous rounds among them — keeps compiling and keeps
        // meaning «no stepping», which is what those products do today.
        int $purchaseStep = 1
    ): OperationResult {
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Inventory, StaffLevel::Edit)) {
            return OperationResult::failure('forbidden');
        }
        $unsound = $this->structureRefusal();
        if ($unsound !== null) {
            return $unsound;
        }
        $product = $this->products->findOwned($productId, $vendorUserId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        if ($product->status === ProductStatus::Archived) {
            return OperationResult::failure('product_archived');
        }
        if ($stock < 0) {
            return OperationResult::failure('bad_stock');
        }
        $quantities = $this->validateQuantities($minPurchase, $maxPurchase, $purchaseStep);
        if ($quantities !== null) {
            return $quantities;
        }
        if ($sku !== '' && $this->products->skuTaken($vendorUserId, $sku, $productId)) {
            return OperationResult::failure('sku_taken', ['sku' => $sku]);
        }
        // Read BEFORE anything is written, and from the shop when there is
        // one: the number a shopper meets is WooCommerce's, and a proposal
        // measured against our own mirror would be measured against a copy.
        $stockNeedsApproval = $product->status === ProductStatus::Published;
        $effectiveStock = $stockNeedsApproval ? $this->effectiveStock($product) : $product->details->stock;
        $stockProposed = $stockNeedsApproval && $stock !== $effectiveStock;

        if (!$this->products->updateInventory(
            $productId,
            // The row keeps the EFFECTIVE number while a proposal waits. Not
            // the proposed one: every screen, every guard and every report
            // reads this column, and a column holding a number nobody has
            // approved is two versions of one stock.
            $stockProposed ? $effectiveStock : $stock,
            $sku,
            $minPurchase,
            $maxPurchase,
            $purchaseStep
        )) {
            return OperationResult::failure('storage_failed');
        }
        if (!$stockProposed) {
            // Write-through, not a mirror write: this is the one direction
            // stock is allowed to travel outward, because it is the vendor
            // saying so rather than a sync remembering (ADR-008).
            $this->catalog->pushStock($productId, $stock);
        }
        // The selling rule, written through on the SAME save. Reported, not
        // assumed: a row a manager owns is held and named, and a row the shop
        // refused keeps its previous value — so the answer is never «ذخیره
        // شد» about a limit the shop does not have.
        $limits = $this->catalog->pushQuantities($productId);
        $this->audit->log(AuditEventCatalog::PRODUCT_INVENTORY_CHANGED, $actorId, 'product', (string) $productId, [
            'vendor_id' => $vendorUserId,
            'product_id' => $productId,
            'stock' => $stock,
        ]);
        $context = [
            'product_id' => $productId,
            'stock' => $stockProposed ? $effectiveStock : $stock,
            'limits' => $limits->code,
            'limits_held' => (string) ($limits->context['held'] ?? ''),
            'limits_failed' => (string) ($limits->context['failed'] ?? ''),
        ];
        if ($stockProposed) {
            $proposal = $this->proposeStock($product, $stock, $effectiveStock);
            return $proposal->ok
                ? OperationResult::success($proposal->code, [...$context, ...$proposal->context])
                : OperationResult::failure($proposal->code, [...$context, ...$proposal->context]);
        }
        if (!$limits->ok) {
            return OperationResult::failure('inventory_saved_limits_not_written', $context);
        }
        return OperationResult::success('inventory_saved', $context);
    }

    /**
     * The number a shopper meets, read from the shop when there is a shop.
     *
     * Our own column is a mirror (ADR-008) and a mirror can lag, so a baseline
     * taken from it would record «the stock when we last looked» and call it
     * «the stock when the vendor proposed». `pullStock()` is the verb that
     * brings it home, and its side effect — the mirror becoming current — is
     * wanted here rather than tolerated.
     */
    private function effectiveStock(Product $product): int
    {
        $shop = $this->catalog->pullStock($product->id);
        if ($shop !== null) {
            return $shop;
        }
        $fresh = $this->products->find($product->id);
        return $fresh?->details->stock ?? $product->details->stock;
    }

    /**
     * A live product's stock edit, recorded as a proposal — and the pending
     * proposal it joins rather than replaces.
     *
     * «ذخیرهٔ یک زبانه نباید دادهٔ زبانهٔ دیگر یا پیشنهاد موجود را پاک کند.»
     * One pending proposal per product is the invariant every screen rests
     * on, so a stock proposal that simply superseded the pending one would
     * throw away a title or a brand the vendor is still waiting on. It carries
     * the pending payload FORWARD and changes the stock in it.
     *
     * A new row rather than a mutated one, because the unseen badge is keyed
     * on the pending proposal's id (`alpha.36`): editing the payload in place
     * would add a change the manager has already «seen» and no badge would
     * come back. The superseded row stays on record.
     */
    private function proposeStock(Product $product, int $stock, int $baseline): OperationResult
    {
        $existing = $this->revisions->pendingFor($product->id);
        $payload = $existing?->payload ?? [
            'details' => $this->detailsToArray($product->details),
            'specs' => $product->specs,
            'images' => $product->imageIds,
            'main_image_id' => $product->mainImageId,
        ];
        if (!isset($payload['details']) || !is_array($payload['details'])) {
            $payload['details'] = $this->detailsToArray($product->details);
        }
        $payload['details']['stock'] = $stock;
        // The baseline travels WITH the proposal, because the conflict the
        // owner named is between proposing and approving: «اگر موجودی مؤثر بین
        // ثبت پیشنهاد و تأیید تغییر کرد، پیشنهاد کهنه نباید بی‌صدا مقدار تازه
        // را بازنویسی کند.» Without a number recorded at proposal time there
        // is nothing to notice the change against.
        $payload['stock_proposal'] = ['value' => $stock, 'baseline' => $baseline];

        if ($existing !== null && self::samePayload($existing->payload, $payload)) {
            return OperationResult::success('stock_revision_unchanged', [
                'revision_id' => $existing->id,
                'proposed_stock' => $stock,
            ]);
        }
        // ONE UNIT OF WORK, and the reason is `alpha.49`'s first finding:
        // superseding and then inserting was two statements, and a refused
        // insert left the product with no pending proposal at all — the
        // vendor's earlier, unanswered request destroyed by a save that only
        // said «ذخیره نشد».
        $replaced = $this->revisions->replacePending(
            $product->id,
            $product->vendorUserId,
            $payload,
            $existing?->id ?? 0
        );
        if ($replaced['id'] <= 0) {
            return OperationResult::failure(
                $replaced['code'] === 'not_atomic' ? 'revision_not_atomic' : 'storage_failed',
                $this->keptProposal($product->id, $existing, $replaced['code'])
            );
        }
        $revisionId = $replaced['id'];
        $this->audit->log(AuditEventCatalog::PRODUCT_REVISION_REQUESTED, $product->vendorUserId, 'product', (string) $product->id, [
            'vendor_id' => $product->vendorUserId,
            'product_id' => $product->id,
            'revision_id' => $revisionId,
            'fields' => 1,
        ]);
        return OperationResult::success('stock_revision_requested', [
            'revision_id' => $revisionId,
            'proposed_stock' => $stock,
            'baseline_stock' => $baseline,
        ]);
    }

    /**
     * Step 4 of the form: the vendor says it is ready.
     *
     * Everything the marketplace demands is checked HERE rather than at each
     * keystroke, so a half-filled draft is always savable and only a
     * submission has to be complete.
     */
    public const ACTION_SUBMIT = 'submit';
    public const ACTION_ARCHIVE = 'archive';
    public const ACTION_RESTORE = 'restore';

    /** @var list<string> the bulk verbs, each one an existing single-row action */
    public const BULK_ACTIONS = [self::ACTION_SUBMIT, self::ACTION_ARCHIVE, self::ACTION_RESTORE];

    /** Rows one POST may carry. Above it the request is refused, not truncated. */
    public const BULK_LIMIT = 100;

    public function submit(int $actorId, int $vendorUserId, int $productId): OperationResult
    {
        return $this->carryOut($this->plan($actorId, $vendorUserId, $productId, self::ACTION_SUBMIT), $actorId, $vendorUserId);
    }

    /** Off the shelf without deleting anything: history and orders stay. */
    public function archive(int $actorId, int $vendorUserId, int $productId): OperationResult
    {
        return $this->carryOut($this->plan($actorId, $vendorUserId, $productId, self::ACTION_ARCHIVE), $actorId, $vendorUserId);
    }

    public function restore(int $actorId, int $vendorUserId, int $productId): OperationResult
    {
        return $this->carryOut($this->plan($actorId, $vendorUserId, $productId, self::ACTION_RESTORE), $actorId, $vendorUserId);
    }

    /**
     * The same three actions, over a selection, with a verdict per row.
     *
     * **A refused row does not stop the batch, and it does not disappear.**
     * A vendor selecting forty products and pressing «ارسال برای بررسی» has
     * some that are ready and some that are missing a price; stopping at the
     * first incomplete one would make the feature useless on exactly the
     * catalogue that needs it, and skipping it silently would tell them
     * everything went out when four things did not. So every row gets its own
     * line in the answer, with the same code the single-row action would have
     * returned.
     *
     * **It calls the single-row methods.** Not a faster bulk query — every
     * ownership check, every readiness rule and every audit line is the one
     * that already exists. A bulk path with its own rules is a second set of
     * rules, and the looser one always wins the day they differ.
     *
     * **The selection is capped.** A POST carrying ten thousand ids would
     * time out half way, which is the failure the job queue exists for; until
     * bulk work is queued, the honest answer is to refuse the oversized
     * request rather than start one that cannot finish.
     *
     * @param list<int> $productIds
     * @return OperationResult context: rows, ok, failed
     */
    public function bulk(int $actorId, int $vendorUserId, string $action, array $productIds): OperationResult
    {
        $refusal = $this->guardBulkRequest($actorId, $vendorUserId, $action, $productIds);
        if ($refusal !== null) {
            return $refusal;
        }
        $productIds = $this->bulkSelection($productIds);

        $rows = [];
        $ok = 0;
        $failed = 0;
        foreach ($productIds as $productId) {
            // Re-planned per row and NOT taken from any preview the vendor was
            // shown: between looking and pressing, somebody else can have
            // submitted the same product. The forecast is never the authority.
            //
            // `plan()` re-runs every ownership and capability check, so the
            // permissions are tested again HERE, at the moment of the write,
            // and not inherited from the preview the vendor looked at.
            $plan = $this->plan($actorId, $vendorUserId, $productId, $action);
            $from = $plan->product?->status->value ?? '';
            $title = $plan->product?->details->title ?? '';
            $result = $this->carryOut($plan, $actorId, $vendorUserId);
            // The SAME row shape the preview produces, so one view renders
            // both. «۴ مورد انجام نشد» with no row is what the owner was
            // shown, and it is a sentence nobody can act on.
            $rows[] = [
                'product_id' => $productId,
                'ok' => $result->ok,
                'code' => $result->code,
                'title' => $title,
                'from' => $from,
                'to' => $result->ok ? ($plan->target?->value ?? '') : $from,
            ];
            $result->ok ? $ok++ : $failed++;
        }

        // `ok` is true when the batch RAN, not when every row succeeded. The
        // caller reads the rows to find out what happened; a false here would
        // have made «۳۶ از ۴۰ رفت» look like a failure of the whole thing.
        return OperationResult::success('bulk_done', [
            'action' => $action,
            'rows' => $rows,
            'ok' => $ok,
            'failed' => $failed,
        ]);
    }

    /**
     * What `bulk()` would do to this selection — without doing any of it.
     *
     * The reason this exists is that «۴۰ مورد انتخاب شد» hides the one thing
     * the vendor needs to decide: which of the forty are actually going to
     * move. Pressing the button to find out costs an audit line and a status
     * change on thirty-six products, and there is no undo for «ارسال برای
     * بررسی» — the manager now has thirty-six items in their queue.
     *
     * **It writes nothing.** No status, no audit line, no catalogue call. It
     * runs the same `plan()` the action runs and stops before `carryOut()`.
     *
     * **It is a forecast, not a promise,** and the screen says so: another
     * member of the same store can save one of these products in the seconds
     * between the preview and the button. `bulk()` therefore re-plans every
     * row rather than trusting what was shown, and a row whose answer changed
     * in between is reported with its NEW code.
     *
     * @param list<int> $productIds
     * @return OperationResult context: action, rows, ok, failed
     */
    public function previewBulk(int $actorId, int $vendorUserId, string $action, array $productIds): OperationResult
    {
        $refusal = $this->guardBulkRequest($actorId, $vendorUserId, $action, $productIds);
        if ($refusal !== null) {
            return $refusal;
        }
        $productIds = $this->bulkSelection($productIds);

        $rows = [];
        $ok = 0;
        $failed = 0;
        foreach ($productIds as $productId) {
            $plan = $this->plan($actorId, $vendorUserId, $productId, $action);
            $result = $plan->asResult();
            $rows[] = [
                'product_id' => $productId,
                'ok' => $plan->ok(),
                'code' => $result->code,
                // The title is what the vendor recognises; an id is what they
                // would have to go and look up, forty times.
                'title' => $plan->product?->details->title ?? '',
                'from' => $plan->product?->status->value ?? '',
                'to' => $plan->target?->value ?? '',
            ];
            $plan->ok() ? $ok++ : $failed++;
        }

        return OperationResult::success('bulk_previewed', [
            'action' => $action,
            'rows' => $rows,
            'ok' => $ok,
            'failed' => $failed,
        ]);
    }

    /**
     * Whether this product could be submitted right now, and if not, why.
     *
     * Step 4 of the form calls this to show the list before the button is
     * pressed; submit() calls the same object, so the preview and the answer
     * can never disagree.
     */
    public function readiness(Product $product): OperationResult
    {
        return $this->readiness->check($product);
    }

    /**
     * Puts one picture in the media library for this shop and hands back its
     * id; the gallery itself is only ever changed by save(), so an upload on
     * a live product still goes through the revision rule.
     */
    public function uploadImage(int $actorId, int $vendorUserId, UploadedFile $file, string $title = ''): OperationResult
    {
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return OperationResult::failure('forbidden');
        }
        $stored = $this->images->store($file, $vendorUserId, $title);
        if (!$stored['ok']) {
            return OperationResult::failure($stored['code']);
        }
        return OperationResult::success('image_uploaded', ['media_id' => $stored['media_id']]);
    }

    // ------------------------------------------------------------- internals

    /** @param array<string,string> $specs @param list<int> $imageIds */
    /**
     * A new draft — and one per submitted form, not one per request.
     *
     * **§2's reproducible half.** A create had no idempotency at all, so a
     * replayed POST made a second product. That replay is not hypothetical: a
     * browser showing «Request Timeout» has usually already sent the request,
     * and the owner's own retry produced several products with the same name.
     *
     * The guard is the unique key on `(vendor_user_id, create_token)`, and the
     * resolution is a re-read rather than an error: the token's product IS the
     * answer the replay wanted. A deliberate second product of the same name
     * is still allowed, because it comes from a freshly rendered form carrying
     * a fresh token — the token identifies the SUBMISSION, never the content.
     *
     * @param array<string,string> $specs
     * @param list<int> $imageIds
     */
    /**
     * The long description a product currently holds.
     *
     * For the one caller that has to tell «this submission says nothing about
     * the field» from «this submission says the field is null» — two
     * instructions that `ProductDetails` cannot hold apart, because the
     * column is written with whatever is in it. A form rendered by an older
     * build names no base, and without this its save would write `null` over
     * a long description the vendor had written.
     *
     * Reading it here is safe rather than a check-then-write race: the update
     * that follows carries the row's version in its `WHERE`, so a concurrent
     * edit refuses the save rather than being overwritten by it.
     */
    public function storedLongDescription(int $actorId, int $vendorUserId, int $productId): ?string
    {
        if ($productId <= 0) {
            return null;
        }
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::View)) {
            return null;
        }
        return $this->products->findOwned($productId, $vendorUserId)?->details->description;
    }

    /**
     * The product one submitted create form already made, or 0.
     *
     * Exists so a caller can ask BEFORE it does expensive or irreversible
     * work. `ProductArea` takes the uploaded file off the wire and stores it
     * as an attachment before it ever reaches `save()`, so a replayed POST
     * carrying the same file used to create a SECOND attachment that the
     * replay then discarded — an orphan in the media library, charged to the
     * vendor's disk, referenced by nothing.
     *
     * Access-checked like every other read here, so it cannot be used to
     * learn whether some other shop's token exists.
     */
    public function createdAlready(int $actorId, int $vendorUserId, string $createToken): int
    {
        if (trim($createToken) === '') {
            return 0;
        }
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return 0;
        }
        return $this->products->findByCreateToken($vendorUserId, $createToken);
    }

    /**
     * Media this request uploaded and nothing uses, discarded.
     *
     * **§3's other half.** The `alpha.42` guard asks `createdAlready()`
     * BEFORE the file is taken off the wire, which closes the SEQUENTIAL
     * replay — the browser resending a timed-out POST minutes later. It
     * cannot close two requests that arrive together: both ask before either
     * has inserted, both get 0, both upload, and then the unique key on
     * `(vendor_user_id, create_token)` picks one. The loser writes nothing,
     * which is right, and until now left its attachment on the vendor's disk
     * referenced by nothing.
     *
     * Three conditions, and every one of them is required:
     *
     *  - the id was MINTED BY THIS REQUEST. The caller passes only what its
     *    own upload created, never the gallery the form carried — those are
     *    somebody's pictures.
     *  - `mediaInUse()` says nothing points at it. Not an argument that
     *    nothing can: a query.
     *  - `discard()` checks the attachment is this shop's before deleting.
     *
     * «پاک‌سازی عمومی ممنوع»: there is no sweep here, no age cutoff, and no
     * way to reach this with an id the same request did not create.
     *
     * @param list<int> $mediaIds
     * @return int how many were deleted
     */
    public function discardUnusedUploads(int $actorId, int $vendorUserId, array $mediaIds): int
    {
        if ($mediaIds === []) {
            return 0;
        }
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return 0;
        }
        $discarded = 0;
        foreach (array_unique(array_map('intval', $mediaIds)) as $mediaId) {
            if ($mediaId <= 0 || $this->products->mediaInUse($mediaId)) {
                continue;
            }
            if ($this->images->discard($mediaId, $vendorUserId)) {
                $discarded++;
            }
        }
        return $discarded;
    }

    /**
     * One submitted create form, asked about twice: the row, and nothing else.
     *
     * Reached from the replay check in `save()` and from the losing half of
     * two simultaneous submissions. Both mean the same thing — this form has
     * already produced its product — and both are answered WITHOUT A SINGLE
     * WRITE. That is the point: a replay arrives after a timeout, which can be
     * minutes, and in those minutes the vendor may have edited the draft. A
     * second `persistSpecsAndImages()` would put the stale submission's
     * gallery and specifications over whatever is there now.
     *
     * The code is its own (`product_created_replayed`), never
     * `product_created`, so no caller can report an unqualified success about
     * a product it did not make and whose completeness it does not know.
     *
     * What it CAN say is what the row holds, so the context carries the
     * counts and the message names them. **It does not claim to know why.** A
     * draft with no pictures is what a create whose gallery write failed
     * leaves behind, and it is also what a vendor who deliberately emptied the
     * gallery afterwards leaves behind; nothing on the row distinguishes them,
     * and inventing a sentence that did would be worse than the counts.
     */
    private function replayed(int $vendorUserId, int $productId): OperationResult
    {
        $product = $this->products->findOwned($productId, $vendorUserId);
        return OperationResult::success('product_created_replayed', [
            'product_id' => $productId,
            'replayed' => 1,
            'images' => $product === null ? 0 : count($product->imageIds),
            'specs' => $product === null ? 0 : count(array_filter(
                $product->specs,
                static fn (string $value): bool => trim($value) !== ''
            )),
        ]);
    }

    private function create(
        int $vendorUserId,
        ProductDetails $details,
        array $specs,
        array $imageIds,
        int $mainImageId,
        string $createToken = ''
    ): OperationResult {
        // The replay is answered in `save()`, before validation, because a
        // replay's SKU is the SKU of the product it already made. What is left
        // here is the SIMULTANEOUS case: two requests that both got past that
        // check because neither had committed yet. The unique key decides, and
        // the loser's insert resolves to the winner's row rather than to an
        // error about a product that exists.
        $creation = $createToken === ''
            ? ProductCreation::made($this->products->create($vendorUserId, $details, ProductStatus::Draft))
            : $this->products->createForForm($vendorUserId, $details, ProductStatus::Draft, $createToken);
        if (!$creation->ok()) {
            return OperationResult::failure('storage_failed');
        }
        if (!$creation->created) {
            // The losing half of two simultaneous submissions of one form.
            // The row is the WINNER'S, so nothing of this request's is written
            // to it: carrying on from here is how a second POST used to put
            // its gallery and its specifications over a row it had not made.
            return $this->replayed($vendorUserId, $creation->productId);
        }
        $productId = $creation->productId;
        $this->rememberBrandTerm($productId, $details);
        $missed = $this->persistSpecsAndImages($productId, $details->categoryKey, $specs, $imageIds, $mainImageId);
        $this->audit->log(AuditEventCatalog::PRODUCT_SAVED, $vendorUserId, 'product', (string) $productId, [
            'vendor_id' => $vendorUserId,
            'product_id' => $productId,
            'status' => ProductStatus::Draft->value,
            'created' => true,
            'incomplete' => implode(',', $missed),
        ]);
        // The row exists, so the id travels either way — the draft is where
        // the vendor continues from, and sending them back to an empty form
        // would lose the work that DID save. What changes is the sentence.
        return $missed === []
            ? OperationResult::success('product_created', ['product_id' => $productId])
            : OperationResult::failure('product_created_incomplete', [
                'product_id' => $productId,
                'missing' => implode(',', $missed),
            ]);
    }

    /** @param array<string,string> $specs @param list<int> $imageIds */
    private function saveInPlace(
        Product $product,
        ProductDetails $details,
        array $specs,
        array $imageIds,
        int $mainImageId,
        string $expectedVersion = ''
    ): OperationResult {
        if (!$this->products->updateDetails($product->id, $details, $expectedVersion)) {
            return $this->refusedOrFailed($product, $expectedVersion);
        }
        $this->rememberBrandTerm($product->id, $details);
        // A draft can already have a storefront row — `SyncCatalog::prepare()`
        // makes one so the manager can use WooCommerce's own editor — and a
        // row that exists is a row whose limits must agree with the save.
        // `pushQuantities()` answers `nothing_to_push` when there is none.
        $this->catalog->pushQuantities($product->id);
        $missed = $this->persistSpecsAndImages($product->id, $details->categoryKey, $specs, $imageIds, $mainImageId);
        $this->audit->log(AuditEventCatalog::PRODUCT_SAVED, $product->vendorUserId, 'product', (string) $product->id, [
            'vendor_id' => $product->vendorUserId,
            'product_id' => $product->id,
            'status' => $product->status->value,
            'created' => false,
            'incomplete' => implode(',', $missed),
        ]);
        return $missed === []
            ? OperationResult::success('product_saved', ['product_id' => $product->id])
            : OperationResult::failure('product_saved_incomplete', [
                'product_id' => $product->id,
                'missing' => implode(',', $missed),
            ]);
    }

    /**
     * A guarded write that hit nothing: was it a conflict, or a broken table?
     *
     * The distinction matters to the person reading the message. «Somebody else
     * saved this» sends them to look at the product; «the save failed» sends
     * them to support. Asking the row which version it carries now separates
     * them, and costs one read on a path that has already failed.
     */
    private function refusedOrFailed(Product $product, string $expectedVersion): OperationResult
    {
        if ($expectedVersion === '') {
            return OperationResult::failure('storage_failed');
        }
        $current = $this->products->rowVersion($product->id);
        if ($current !== '' && $current !== $expectedVersion) {
            return OperationResult::failure('stale_revision', [
                'product_id' => $product->id,
                'submitted_revision' => $expectedVersion,
                'current_revision' => $current,
            ]);
        }
        return OperationResult::failure('storage_failed');
    }

    /**
     * A live product's sensitive edit becomes a proposal.
     *
     * The immediate fields are still written straight through: refusing to
     * update stock because the title also changed would be the queue between
     * a sale and its inventory that A.1 forbids.
     *
     * @param array<string,string> $specs
     * @param list<int> $imageIds
     */
    private function saveAsRevision(
        Product $product,
        ProductDetails $details,
        array $specs,
        array $imageIds,
        int $mainImageId,
        string $expectedVersion = ''
    ): OperationResult {
        $changed = SensitiveChange::between($product->details, $details);
        $specsDiffer = SensitiveChange::specsChanged($product->specs, $specs);
        $imagesDiffer = $product->imageIds !== $imageIds || $product->mainImageId !== $mainImageId;

        // Read before anything is written — see `effectiveStock()`.
        $stockNeedsApproval = $product->status === ProductStatus::Published;
        $effectiveStock = $stockNeedsApproval ? $this->effectiveStock($product) : $product->details->stock;
        $stockProposed = $stockNeedsApproval && $details->stock !== $effectiveStock;

        $inventoryWritten = $this->products->updateInventory(
            $product->id,
            $stockProposed ? $effectiveStock : $details->stock,
            $details->sku,
            $details->minPurchase,
            $details->maxPurchase,
            $details->purchaseStep
        );
        if (!$inventoryWritten) {
            return OperationResult::failure('storage_failed');
        }
        if (!$stockProposed) {
            $this->catalog->pushStock($product->id, $details->stock);
        }
        // The selling rule goes out with this save, on a published product
        // too — it is an immediate field and nothing carried it before.
        $limits = $this->catalog->pushQuantities($product->id);

        // Inventory is deliberately NOT version-guarded, and that is not an
        // oversight. A.1 puts stock on the immediate side: a vendor who has
        // just sold their last unit must be able to say so, and refusing that
        // because a colleague renamed the product two minutes ago is exactly
        // the queue between a sale and its inventory that A.1 forbids. Last
        // write wins on a number whose latest value is the true one.
        $inventoryContext = [
            'product_id' => $product->id,
            'limits' => $limits->code,
            'limits_held' => (string) ($limits->context['held'] ?? ''),
            'limits_failed' => (string) ($limits->context['failed'] ?? ''),
        ];
        if ($changed === [] && !$specsDiffer && !$imagesDiffer && !$stockProposed) {
            return $limits->ok
                ? OperationResult::success('inventory_saved', $inventoryContext)
                : OperationResult::failure('inventory_saved_limits_not_written', $inventoryContext);
        }

        $payload = [
            'details' => $this->detailsToArray($details),
            'specs' => $specs,
            'images' => $imageIds,
            'main_image_id' => $mainImageId,
        ];
        if ($stockProposed) {
            // The proposal carries the stock AND the number it was measured
            // against, so the approval can tell «the vendor wants 5» from «the
            // vendor wanted 5 when there were 9, and there are 2 now».
            $payload['stock_proposal'] = ['value' => $details->stock, 'baseline' => $effectiveStock];
        } else {
            // The payload's own `details.stock` is read only through
            // `stock_proposal`, but leaving the proposed number in a payload
            // that is NOT proposing it invites the next reader to apply it.
            $payload['details']['stock'] = $effectiveStock;
        }

        // READ BEFORE THE VERSION IS BUMPED, because a proposal that asks for
        // exactly what the pending one already asks for is not a change and
        // must not touch the row at all.
        //
        // This became reachable the moment the form started rendering the
        // pending proposal. Before that, coming back to a published product
        // re-posted the PUBLISHED values, so `$changed` was empty and the
        // early return above caught it. Now the form re-posts the PROPOSAL's
        // values, which differ from the published row by construction — so
        // every visit-and-save would have superseded the proposal and written
        // a new one, and the manager would have found a fresh «پیشنهاد تازه»
        // in the queue for a product nobody had touched. «بازدید یا ذخیرهٔ
        // بدون تغییر نباید نسخهٔ پیشنهادی یا اعلان تکراری بسازد.»
        //
        // Two requests that race here can both answer «unchanged» and both
        // write nothing, which is the right answer twice. Two that genuinely
        // differ both reach `bumpVersion()` and one loses, as before.
        $existing = $this->revisions->pendingFor($product->id);
        if ($existing !== null && self::samePayload($existing->payload, $payload)) {
            return OperationResult::success('revision_unchanged', [
                'product_id' => $product->id,
                'revision_id' => $existing->id,
            ]);
        }

        // The PROPOSAL is guarded. Proposing an edit built on a view somebody
        // else has already replaced would queue a change that silently undoes
        // theirs the moment a manager approves it.
        if (!$this->products->bumpVersion($product->id, $expectedVersion)) {
            return $this->refusedOrFailed($product, $expectedVersion);
        }

        // One pending proposal per product. A newer one replaces the older
        // rather than queueing behind it, so the manager reviews what the
        // vendor actually wants — and the older proposal stays on record as
        // superseded instead of vanishing.
        // ONE UNIT OF WORK — the same replacement, the same finding. The row
        // version has already moved by this point, which only makes another
        // open form re-read; what must not happen is a closed proposal with
        // nothing in its place.
        $replaced = $this->revisions->replacePending(
            $product->id,
            $product->vendorUserId,
            $payload,
            $existing?->id ?? 0
        );
        if ($replaced['id'] <= 0) {
            return OperationResult::failure(
                $replaced['code'] === 'not_atomic' ? 'revision_not_atomic' : 'storage_failed',
                $this->keptProposal($product->id, $existing, $replaced['code'])
            );
        }
        $revisionId = $replaced['id'];
        $this->audit->log(AuditEventCatalog::PRODUCT_REVISION_REQUESTED, $product->vendorUserId, 'product', (string) $product->id, [
            'vendor_id' => $product->vendorUserId,
            'product_id' => $product->id,
            'revision_id' => $revisionId,
            'fields' => count($changed) + ($specsDiffer ? 1 : 0) + ($imagesDiffer ? 1 : 0),
        ]);
        return OperationResult::success('revision_requested', [
            'product_id' => $product->id,
            'revision_id' => $revisionId,
        ]);
    }

    /**
     * What is still pending after a replacement was refused — READ, not claimed.
     *
     * The rollback is the guarantee, and a guarantee is exactly the kind of
     * sentence this repository has learned not to print without asking
     * (`alpha.44`: `update_post_meta()` answers the same for «failed» and «it
     * already said that»). So the row is read back and the answer names the
     * proposal that survived, or says `lost` — and if it ever says `lost`,
     * that is a defect with a number attached rather than a silence.
     *
     * @return array<string,string>
     */
    private function keptProposal(int $productId, ?ProductRevision $existing, string $code): array
    {
        $now = $this->revisions->pendingFor($productId);
        return [
            'product_id' => (string) $productId,
            'reason' => $code,
            'proposal_kept' => match (true) {
                $existing === null => 'none',
                $now !== null && $now->id === $existing->id => (string) $existing->id,
                default => 'lost',
            },
        ];
    }

    /**
     * Whether a proposal asks for exactly what the pending one already asks.
     *
     * The stored side has been through `json_encode`/`json_decode`, so it
     * cannot be compared with `===` against a freshly built array: that round
     * trip is where this would silently answer «different» for ever and the
     * guard above would do nothing.
     *
     *  - Keys are sorted on both sides. JSON preserves object order, but the
     *    order a payload was written in is not a fact about the payload, and a
     *    future change to `detailsToArray()`'s order must not make every
     *    pending proposal look stale.
     *  - Scalars are compared as STRINGS. `450000` and `"450000"` are the
     *    same price; `null` is compared as `null` and never as `''`, because
     *    the long description's three states are the one place where that
     *    distinction is the whole meaning (`alpha.41`).
     *  - `images` is a LIST and its order is compared, because gallery order
     *    is a value a vendor sets on purpose (`alpha.27`).
     *
     * @param array<string,mixed> $stored
     * @param array<string,mixed> $proposed
     */
    private static function samePayload(array $stored, array $proposed): bool
    {
        return self::canonicalPayload($stored) === self::canonicalPayload($proposed);
    }

    /** @param array<array-key,mixed> $value */
    private static function canonicalPayload(array $value): string
    {
        return (string) json_encode(self::canonicalise($value), JSON_UNESCAPED_UNICODE);
    }

    private static function canonicalise(mixed $value): mixed
    {
        if (is_array($value)) {
            // A list keeps its order; a map is sorted by key. `array_is_list`
            // is the only honest test here: `images` arrives as a list and
            // `details` as a map, and sorting the first would call two
            // different galleries equal.
            if (array_is_list($value)) {
                return array_map([self::class, 'canonicalise'], $value);
            }
            ksort($value);
            return array_map([self::class, 'canonicalise'], $value);
        }
        if ($value === null) {
            return null;
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        return (string) $value;
    }

    /**
     * The refusals that belong to the REQUEST rather than to any one row —
     * shared so a selection the preview accepted cannot be one the action
     * rejects, and the other way round.
     *
     * @param list<int> $productIds
     * @return OperationResult|null null when the request itself is fine
     */
    private function guardBulkRequest(int $actorId, int $vendorUserId, string $action, array $productIds): ?OperationResult
    {
        if (!in_array($action, self::BULK_ACTIONS, true)) {
            return OperationResult::failure('unknown_bulk_action');
        }
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return OperationResult::failure('forbidden');
        }
        $selection = $this->bulkSelection($productIds);
        if ($selection === []) {
            return OperationResult::failure('nothing_selected');
        }
        if (count($selection) > self::BULK_LIMIT) {
            return OperationResult::failure('bulk_too_large', [
                'selected' => count($selection),
                'limit' => self::BULK_LIMIT,
            ]);
        }
        return null;
    }

    /**
     * @param list<int> $productIds
     * @return list<int>
     */
    private function bulkSelection(array $productIds): array
    {
        return array_values(array_unique(array_filter($productIds, static fn (int $id): bool => $id > 0)));
    }

    /**
     * Everything one of the three verbs checks, and nothing it changes.
     *
     * This is the only place those rules are written. `submit()`, `archive()`,
     * `restore()` and the preview all come through here, so «what the preview
     * said» and «what the button did» are the same sentence produced by the
     * same code — not two implementations that agree until the day somebody
     * edits one of them.
     */
    private function plan(int $actorId, int $vendorUserId, int $productId, string $action): ProductActionPlan
    {
        if (!in_array($action, self::BULK_ACTIONS, true)) {
            return ProductActionPlan::refused(OperationResult::failure('unknown_bulk_action'));
        }
        if (!$this->access->can($actorId, $vendorUserId, StaffArea::Product, StaffLevel::Edit)) {
            return ProductActionPlan::refused(OperationResult::failure('forbidden'));
        }
        $product = $this->products->findOwned($productId, $vendorUserId);
        if ($product === null) {
            return ProductActionPlan::refused(OperationResult::failure('not_found'));
        }
        $direct = $this->publishing->mayPublishDirectly($vendorUserId);

        if ($action === self::ACTION_SUBMIT) {
            if (!$product->status->isEditableByVendor()) {
                return ProductActionPlan::refused(OperationResult::failure('not_submittable'));
            }
            $verdict = $this->readiness->check($product);
            if (!$verdict->ok) {
                return ProductActionPlan::refused($verdict);
            }
            $target = $direct ? ProductStatus::Published : ProductStatus::Submitted;
            $code = $direct ? 'product_published' : 'product_submitted';
            // A fresh submission clears the review note: «قیمت را اصلاح کنید»
            // was about the version being replaced.
            $note = '';
            $event = AuditEventCatalog::PRODUCT_SUBMITTED;
        } else {
            $target = $action === self::ACTION_ARCHIVE ? ProductStatus::Archived : ProductStatus::Draft;
            $code = $action === self::ACTION_ARCHIVE ? 'product_archived_ok' : 'product_restored';
            $note = $product->reviewNote;
            $event = AuditEventCatalog::PRODUCT_STATUS_CHANGED;
        }

        if (!$this->states->vendorMayMove($product->status, $target, $direct)) {
            return ProductActionPlan::refused(OperationResult::failure('invalid_transition', [
                'from' => $product->status->value,
                'to' => $target->value,
            ]));
        }
        return ProductActionPlan::allowed($product, $target, $code, $note, $event);
    }

    /** The write half, which runs only for a plan that was allowed. */
    private function carryOut(ProductActionPlan $plan, int $actorId, int $vendorUserId): OperationResult
    {
        if (!$plan->ok() || $plan->product === null || $plan->target === null) {
            return $plan->refusal ?? OperationResult::failure('storage_failed');
        }
        $product = $plan->product;
        $target = $plan->target;
        if (!$this->products->updateStatus($product->id, $target, $plan->note)) {
            return OperationResult::failure('storage_failed');
        }
        if ($target === ProductStatus::Published) {
            $this->catalog->publish($product->id);
        } elseif ($product->status === ProductStatus::Published) {
            $this->catalog->withdraw($product->id);
        }
        $this->audit->log($plan->auditEvent, $actorId, 'product', (string) $product->id, [
            'vendor_id' => $vendorUserId,
            'product_id' => $product->id,
            'from' => $product->status->value,
            'to' => $target->value,
        ]);
        // The vendor's own move, in the same trail as the manager's. Note
        // deliberately empty: this row records WHAT happened and when, and
        // inventing a sentence for it would put words in the vendor's mouth.
        $this->decisions?->record($product->id, $vendorUserId, $actorId, $target->value, '');
        return OperationResult::success($plan->code, ['product_id' => $product->id]);
    }

    /** @param array<string,string> $specs @param list<int> $imageIds */
    /**
     * The specs and the gallery, and WHICH of them did not land.
     *
     * **It returned `void` until `alpha.41`, and that is §2's provable half.**
     * `alpha.31` made both writes transactional and made them report — and
     * then checked the answer in `approveRevision()` only. The vendor's own
     * save path, the one every draft goes through, threw both results away:
     * a product could be created with its specs or its pictures missing and
     * the vendor was told «ذخیره شد». The owner's timeout is not explained by
     * this (see the delivery note), but «ذخیرهٔ ناقص را موفقیت کامل اعلام
     * نکن» is, and a half-written draft is exactly what they were left with.
     *
     * @param array<string,string> $specs
     * @param list<int> $imageIds
     * @return list<string> the parts that did NOT save; empty when all did
     */
    private function persistSpecsAndImages(int $productId, string $categoryKey, array $specs, array $imageIds, int $mainImageId): array
    {
        $template = $this->templates->findByCategory($categoryKey);
        $missed = [];
        // The version a product was filled against, recorded with the answers
        // (MED-01): tightening a rule later must not silently re-judge it.
        if (!$this->products->saveSpecs($productId, $specs, $template?->schemaVersion ?? 0)) {
            $missed[] = 'specs';
        }
        // Attempted even when the specs failed, and deliberately: the two are
        // separate transactions, one failing says nothing about the other, and
        // a vendor whose pictures DID land should not be told to upload them
        // again.
        if (!$this->products->saveImages($productId, $imageIds, $mainImageId)) {
            $missed[] = 'images';
        }
        return $missed;
    }

    private function validate(int $vendorUserId, ProductDetails $details, int $productId): ?OperationResult
    {
        if (!ProductType::isValid($details->type)) {
            return OperationResult::failure('bad_type');
        }
        if ($details->priceMinor < 0) {
            return OperationResult::failure('bad_price');
        }
        if ($details->salePriceMinor !== null) {
            if ($details->salePriceMinor < 0 || $details->salePriceMinor > $details->priceMinor) {
                return OperationResult::failure('bad_sale_price');
            }
            if ($details->saleFrom !== null && $details->saleTo !== null && $details->saleFrom > $details->saleTo) {
                return OperationResult::failure('bad_sale_window');
            }
        }
        if ($details->stock < 0) {
            return OperationResult::failure('bad_stock');
        }
        $quantities = $this->validateQuantities($details->minPurchase, $details->maxPurchase, $details->purchaseStep);
        if ($quantities !== null) {
            return $quantities;
        }
        if ($details->sku !== '' && $this->products->skuTaken($vendorUserId, $details->sku, $productId)) {
            return OperationResult::failure('sku_taken', ['sku' => $details->sku]);
        }
        return null;
    }

    private function validateQuantities(int $minPurchase, ?int $maxPurchase, int $purchaseStep = 1): ?OperationResult
    {
        // ONE RULE, FOUR DOORS. The comparison lives in the domain
        // (`PurchaseQuantity::validate()`) and the vendor form, this service
        // (which the approval path also goes through), the CSV importer and
        // the admin panel all ask it. Before `alpha.46` three of them had
        // their own copy and the fourth — the panel — had none: it coerced
        // instead of refusing, so «min 5, max 2» became «min 6, no maximum».
        //
        // The refusal happens BEFORE any write, so neither these three fields
        // nor anything else on the product is damaged by it, and the context
        // names the numbers: «مقدار خرید نامعتبر است» with nothing else sends
        // a vendor to check four boxes.
        return self::quantityRefusal($minPurchase, $maxPurchase, $purchaseStep);
    }

    /**
     * The domain's refusal, as an `OperationResult` with the numbers in it.
     *
     * Static and public so the CSV importer reports the same code with the
     * same context rather than building its own.
     */
    public static function quantityRefusal(int $min, ?int $max, int $step): ?OperationResult
    {
        $reason = PurchaseQuantity::validate($min, $max, $step);
        if ($reason === null) {
            return null;
        }
        $context = ['min' => $min, 'max' => $max, 'step' => $step];
        if ($reason === PurchaseQuantity::NO_MULTIPLE && $max !== null) {
            // Two ways out, each the smallest change to ONE field — and the
            // second may not exist, so it is only put in the context when it
            // does. A message that names a value which is itself refused is
            // worse than one that names nothing.
            [$workableMax, $workableMin] = PurchaseQuantity::workableWindow($min, $max, $step);
            $context['workable_max'] = $workableMax;
            if ($workableMin !== null) {
                $context['workable_min'] = $workableMin;
            }
        }
        return OperationResult::failure($reason, $context);
    }

    /**
     * Values a field could never accept are refused on the way in; values a
     * REQUIRED field is missing are not, because a draft is allowed to be
     * unfinished. Only submit() demands completeness.
     *
     * @param array<string,string> $specs
     */
    private function rejectImpossibleSpecs(string $categoryKey, array $specs): ?OperationResult
    {
        $template = $this->templates->findByCategory($categoryKey);
        if ($template === null) {
            return null;
        }
        $invalid = [];
        foreach ($template->askedFields() as $field) {
            $value = trim($specs[$field->key] ?? '');
            if ($value !== '' && !$field->type->accepts($value, $field->options)) {
                $invalid[] = $field->label;
            }
        }
        return $invalid === []
            ? null
            : OperationResult::failure('invalid_specs', ['fields' => implode('، ', $invalid)]);
    }

    /**
     * Drops duplicates, anything the shop does not own, and anything past the
     * limit.
     *
     * The ownership test is the important one: image ids arrive in a form
     * field, so without it a vendor could post the id of somebody else's
     * attachment and publish it on their own product page (AC-PRIV).
     *
     * @param list<int> $imageIds
     * @return array{0:list<int>,1:int}
     */
    private function cleanImages(array $imageIds, int $mainImageId, int $vendorUserId): array
    {
        $ids = [];
        foreach ($imageIds as $id) {
            $id = (int) $id;
            if ($id > 0 && !in_array($id, $ids, true) && $this->images->ownedBy($id, $vendorUserId)) {
                $ids[] = $id;
            }
        }
        $ids = array_slice($ids, 0, self::MAX_IMAGES);
        if ($ids === []) {
            return [[], 0];
        }
        // The main image must be one of the gallery's, or the product card
        // would show a picture the gallery does not contain.
        return [$ids, in_array($mainImageId, $ids, true) ? $mainImageId : $ids[0]];
    }

    /** @return array<string,mixed> */
    private function detailsToArray(ProductDetails $d): array
    {
        return [
            'title' => $d->title,
            'type' => $d->type,
            'categoryKey' => $d->categoryKey,
            'brand' => $d->brand,
            'shortDescription' => $d->shortDescription,
            'priceMinor' => $d->priceMinor,
            'salePriceMinor' => $d->salePriceMinor,
            'saleFrom' => $d->saleFrom,
            'saleTo' => $d->saleTo,
            'sku' => $d->sku,
            'stock' => $d->stock,
            'minPurchase' => $d->minPurchase,
            'maxPurchase' => $d->maxPurchase,
            'purchaseStep' => $d->purchaseStep,
            'weightGrams' => $d->weightGrams,
            'dimensions' => $d->dimensions,
            'taxClass' => $d->taxClass,
            // The revision payload is a SNAPSHOT, so a field missing from it
            // is a field the approval silently drops. `ProductDetails::with()`
            // was written with a `$pick` helper for exactly this reason, and a
            // hand-written array beside it is the place a field goes missing:
            // without this line, approving a proposal set the long description
            // back to `null`. Measured, by a test that walked the lifecycle.
            'description' => $d->description,
        ];
    }
}
