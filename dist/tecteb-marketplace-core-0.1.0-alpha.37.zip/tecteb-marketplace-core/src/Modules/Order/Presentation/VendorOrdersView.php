<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Order\Presentation;

use Tecteb\Marketplace\Core\Support\PersianDigits;
use Tecteb\Marketplace\Modules\Order\Domain\OrderCustomerView;
use Tecteb\Marketplace\Modules\Order\Domain\OrderItemStateMachine;
use Tecteb\Marketplace\Modules\Order\Domain\OrderItemStatus;
use Tecteb\Marketplace\Modules\Order\Domain\ReturnRequest;
use Tecteb\Marketplace\Modules\Order\Domain\Shipment;
use Tecteb\Marketplace\Modules\Order\Domain\VendorOrderItem;
use Tecteb\Marketplace\Modules\Vendor\Presentation\VendorMessages;
use Tecteb\Marketplace\Modules\Vendor\Presentation\VendorNotice;
use Tecteb\Marketplace\Modules\Vendor\Presentation\VendorUi;

/**
 * The vendor's own orders (UX §7).
 *
 * Every row is one line of one order — this shop's line. There is no order
 * total, no other shop's goods, and no customer e-mail or mobile anywhere on
 * the page, because the object this view is handed does not contain them
 * (PRIV-01). The «سهم» column is the snapshot taken when the sale happened,
 * not today's rate.
 */
final class VendorOrdersView
{
    public const PER_PAGE = 20;

    /**
     * @param list<VendorOrderItem> $items
     * @param array<string,int> $counts
     * @param array<int,OrderCustomerView> $customers order id => what may be shown
     * @param array<int,array{number:string,status:string,created:string}> $orders
     * @param array<string,string> $carriers
     * @param array<int,array{
     *   shipped:int, remaining:int, returnable:int,
     *   parcels:list<Shipment>, returns:list<ReturnRequest>
     * }> $movement item id => what has actually left and come back
     */
    public static function render(
        array $items,
        array $counts,
        string $currentStatus,
        int $page,
        int $total,
        array $customers,
        array $orders,
        array $carriers,
        string $ordersUrl,
        string $nonceField,
        ?VendorNotice $notice = null,
        bool $mayAct = true,
        bool $trialMode = false,
        string $environment = '',
        array $movement = []
    ): string {
        $fa = static fn (string|int $v): string => PersianDigits::toPersian((string) $v);
        $states = new OrderItemStateMachine();
        $html = '';

        if ($notice !== null) {
            $html .= VendorUi::notice(
                OrderMessages::isErrorNotice($notice->code) ? 'warning' : 'success',
                OrderMessages::notice($notice->code, $notice->context)
                    ?? VendorMessages::notice($notice->code, $notice->context)
            );
        }
        if ($trialMode) {
            $html .= VendorUi::notice('warning', (string) OrderMessages::notice('order_trial_mode', ['environment' => $environment]));
        }

        $html .= '<section class="tv-card"><h2 class="tv-card__title">' . esc_html__('سفارش‌های فروشگاه', 'tecteb-marketplace-core') . '</h2>'
            . '<p class="tv-hint">' . esc_html__('فقط اقلام همین فروشگاه نمایش داده می‌شوند. شماره تماس و ایمیل مشتری در اختیار فروشنده قرار نمی‌گیرد.', 'tecteb-marketplace-core') . '</p>'
            . self::tabs($counts, $currentStatus, $ordersUrl, $fa);

        if ($items === []) {
            // «هیچ سفارشی نیست» on the first day and on a filtered tab are two
            // different facts, and only one of them needs an explanation of
            // where orders come from.
            $state = $currentStatus === ''
                ? VendorUi::state(
                    'empty',
                    __('هنوز سفارشی برای این فروشگاه ثبت نشده است', 'tecteb-marketplace-core'),
                    __('سفارش وقتی اینجا می‌آید که مشتری یکی از محصولات منتشرشدهٔ شما را بخرد. تا وقتی محصولی منتشر نشده باشد، این فهرست خالی می‌ماند.', 'tecteb-marketplace-core')
                )
                : VendorUi::state(
                    'empty',
                    __('در این وضعیت قلمی ندارید', 'tecteb-marketplace-core'),
                    __('اقلام شما در وضعیت دیگری هستند. از زبانه‌های بالا وضعیت دیگری را ببینید.', 'tecteb-marketplace-core'),
                    [['href' => $ordersUrl, 'label' => __('دیدن همهٔ اقلام', 'tecteb-marketplace-core')]]
                );
            return $html . $state . '</section>';
        }

        $html .= '<ul class="tv-orders">';
        foreach ($items as $item) {
            $html .= self::row(
                $item,
                $customers[$item->orderId] ?? new OrderCustomerView(),
                $orders[$item->orderId] ?? [],
                $carriers,
                $ordersUrl,
                $nonceField,
                $fa,
                $states,
                $mayAct,
                $movement[$item->id] ?? self::noMovement($item)
            );
        }
        $html .= '</ul>';
        return $html . self::pager($page, $total, $currentStatus, $ordersUrl, $fa) . '</section>';
    }

    /** @param array<string,int> $counts @param callable(string|int):string $fa */
    private static function tabs(array $counts, string $current, string $ordersUrl, callable $fa): string
    {
        $tabs = ['' => __('همه', 'tecteb-marketplace-core')];
        foreach (OrderItemStatus::all() as $status) {
            $tabs[$status->value] = OrderMessages::status($status);
        }
        $all = array_sum($counts);
        $html = '<nav class="tv-tabs" aria-label="' . esc_attr__('وضعیت سفارش', 'tecteb-marketplace-core') . '"><ul>';
        foreach ($tabs as $value => $label) {
            $n = $value === '' ? $all : ($counts[$value] ?? 0);
            $isCurrent = (string) $value === $current;
            $url = $value === '' ? $ordersUrl : add_query_arg('status', (string) $value, $ordersUrl);
            $html .= '<li><a class="tv-tab' . ($isCurrent ? ' is-current' : '') . '"'
                . ($isCurrent ? ' aria-current="page"' : '')
                . ' href="' . esc_url($url) . '">' . esc_html($label)
                . ' <span class="tv-tab__count">' . esc_html($fa($n)) . '</span></a></li>';
        }
        return $html . '</ul></nav>';
    }

    /**
     * @param array{number?:string,status?:string,created?:string} $order
     * @param array<string,string> $carriers
     * @param callable(string|int):string $fa
     */
    private static function row(
        VendorOrderItem $item,
        OrderCustomerView $customer,
        array $order,
        array $carriers,
        string $ordersUrl,
        string $nonce,
        callable $fa,
        OrderItemStateMachine $states,
        bool $mayAct,
        array $movement
    ): string {
        $money = static fn (?int $minor): string => $minor === null
            ? __('تعیین‌نشده', 'tecteb-marketplace-core')
            : sprintf(__('%s تومان', 'tecteb-marketplace-core'), $fa(number_format($minor)));

        $created = (string) ($order['created'] ?? '');
        $html = '<li class="tv-order"><div class="tv-order__head">'
            . '<strong>' . esc_html(sprintf(
                __('سفارش %s', 'tecteb-marketplace-core'),
                $fa((string) ($order['number'] ?? $item->orderId))
            )) . '</strong> '
            . VendorUi::chip(OrderMessages::statusTone($item->status), OrderMessages::status($item->status))
            . ($created !== '' ? ' <span class="tv-order__date">' . esc_html($fa($created)) . '</span>' : '');
        $html .= '</div>'
            . '<p class="tv-order__title">' . esc_html($item->title)
            . ($item->sku !== '' ? ' — <bdi class="tv-code">' . esc_html($item->sku) . '</bdi>' : '') . '</p>'
            . '<dl class="tv-product__facts">'
            . '<div><dt>' . esc_html__('تعداد', 'tecteb-marketplace-core') . '</dt><dd>' . esc_html($fa($item->quantity)) . '</dd></div>'
            . '<div><dt>' . esc_html__('ارسال‌شده', 'tecteb-marketplace-core') . '</dt><dd>'
            . esc_html(sprintf(
                /* translators: 1: shipped so far, 2: line quantity */
                __('%1$s از %2$s', 'tecteb-marketplace-core'),
                $fa((int) $movement['shipped']),
                $fa($item->quantity)
            )) . '</dd></div>'
            . '<div><dt>' . esc_html__('مرجوعی', 'tecteb-marketplace-core') . '</dt><dd>'
            . esc_html($fa($item->quantity - (int) $movement['returnable'])) . '</dd></div>'
            . '<div><dt>' . esc_html__('مبلغ قلم (پس از تخفیف)', 'tecteb-marketplace-core') . '</dt><dd>' . esc_html($money($item->baseMinor)) . '</dd></div>'
            . '<div><dt>' . esc_html__('کمیسیون بازارگاه', 'tecteb-marketplace-core') . '</dt><dd>' . esc_html($money($item->commissionMinor)) . '</dd></div>'
            . '<div><dt>' . esc_html__('سهم شما', 'tecteb-marketplace-core') . '</dt><dd>' . esc_html($money($item->vendorShareMinor)) . '</dd></div>'
            . '</dl>';

        if (!$item->isRecorded()) {
            $html .= VendorUi::notice('warning', __('سهم مالی این قلم ثبت نشده است؛ تا تعیین نرخ کمیسیون، قابل تسویه نیست.', 'tecteb-marketplace-core'));
        }

        if (!$customer->isEmpty()) {
            $html .= '<div class="tv-order__ship"><h3 class="tv-review__title">' . esc_html__('نشانی ارسال', 'tecteb-marketplace-core') . '</h3>'
                . '<p>' . esc_html($customer->name) . '</p>'
                . '<p>' . esc_html(trim($customer->city . ' ' . $customer->address)) . '</p>'
                . ($customer->postcode !== '' ? '<p><bdi class="tv-code">' . esc_html($customer->postcode) . '</bdi></p>' : '')
                . '<p class="tv-hint">' . esc_html__('شماره تماس و ایمیل مشتری در این نسخه به فروشنده داده نمی‌شود.', 'tecteb-marketplace-core') . '</p>'
                . '</div>';
        }

        if ($item->carrier !== '') {
            $html .= '<p class="tv-hint">' . esc_html(sprintf(
                __('ارسال با %1$s — کد رهگیری: %2$s', 'tecteb-marketplace-core'),
                $carriers[$item->carrier] ?? $item->carrier,
                $item->trackingCode !== '' ? $item->trackingCode : __('ثبت‌نشده', 'tecteb-marketplace-core')
            )) . '</p>';
        }

        $html .= self::parcels($movement['parcels'], $carriers, $fa)
            . self::returns($movement['returns'], $fa);

        if ($mayAct) {
            $html .= self::actions($item, $states, $carriers, $ordersUrl, $nonce, $fa, $movement);
        }
        return $html . '</li>';
    }

    /**
     * A line with nothing recorded yet — the honest default when the caller
     * did not look the movement up, rather than a zero that pretends to know.
     *
     * @return array{shipped:int, remaining:int, returnable:int, parcels:list<Shipment>, returns:list<ReturnRequest>}
     */
    private static function noMovement(VendorOrderItem $item): array
    {
        return [
            'shipped' => 0,
            'remaining' => $item->quantity,
            'returnable' => $item->quantity,
            'parcels' => [],
            'returns' => [],
        ];
    }

    /**
     * Every parcel, with its own carrier and code.
     *
     * @param list<Shipment> $parcels
     * @param array<string,string> $carriers
     * @param callable(string|int):string $fa
     */
    private static function parcels(array $parcels, array $carriers, callable $fa): string
    {
        if ($parcels === []) {
            return '';
        }
        $html = '<div class="tv-order__parcels"><h3 class="tv-review__title">'
            . esc_html__('بسته‌های ارسالی', 'tecteb-marketplace-core') . '</h3><ul class="tv-list">';
        foreach ($parcels as $parcel) {
            $html .= '<li>' . esc_html(sprintf(
                /* translators: 1: units, 2: carrier, 3: date */
                __('%1$s عدد — %2$s — %3$s', 'tecteb-marketplace-core'),
                $fa($parcel->quantity),
                $carriers[$parcel->carrier] ?? $parcel->carrier,
                $fa($parcel->shippedAt)
            ));
            if ($parcel->isTracked()) {
                $html .= ' <bdi class="tv-code">' . esc_html($parcel->trackingCode) . '</bdi>';
                if ($parcel->trackingUrl !== '') {
                    $html .= ' <a href="' . esc_url($parcel->trackingUrl) . '" rel="nofollow noopener">'
                        . esc_html__('رهگیری', 'tecteb-marketplace-core') . '</a>';
                }
            } else {
                $html .= ' <span class="tv-hint">' . esc_html__('بدون کد رهگیری', 'tecteb-marketplace-core') . '</span>';
            }
            $html .= '</li>';
        }
        return $html . '</ul></div>';
    }

    /**
     * @param list<ReturnRequest> $returns
     * @param callable(string|int):string $fa
     */
    private static function returns(array $returns, callable $fa): string
    {
        if ($returns === []) {
            return '';
        }
        $html = '<div class="tv-order__returns"><h3 class="tv-review__title">'
            . esc_html__('مرجوعی‌ها', 'tecteb-marketplace-core') . '</h3><ul class="tv-list">';
        foreach ($returns as $request) {
            $html .= '<li>' . VendorUi::chip(
                ReturnMessages::statusTone($request->status),
                ReturnMessages::status($request->status)
            ) . ' ' . esc_html(sprintf(
                /* translators: %s: quantity */
                __('%s عدد', 'tecteb-marketplace-core'),
                $fa($request->quantity)
            ));
            if ($request->reason !== '') {
                $html .= ' — ' . esc_html($request->reason);
            }
            if ($request->refundMinor !== null) {
                $html .= ' — ' . esc_html(sprintf(
                    /* translators: %s: refunded amount */
                    __('بازگشت مالی: %s تومان', 'tecteb-marketplace-core'),
                    $fa(number_format($request->refundMinor))
                ));
            }
            if ($request->restockedQuantity > 0) {
                $html .= ' — ' . esc_html(sprintf(
                    /* translators: %s: units returned to stock */
                    __('%s عدد به موجودی برگشت', 'tecteb-marketplace-core'),
                    $fa($request->restockedQuantity)
                ));
            }
            $html .= '</li>';
        }
        return $html . '</ul></div>';
    }

    /**
     * @param array<string,string> $carriers
     * @param callable(string|int):string $fa
     * @param array{shipped:int, remaining:int, returnable:int, parcels:list<Shipment>, returns:list<ReturnRequest>} $movement
     */
    private static function actions(
        VendorOrderItem $item,
        OrderItemStateMachine $states,
        array $carriers,
        string $ordersUrl,
        string $nonce,
        callable $fa,
        array $movement
    ): string {
        $html = '<div class="tv-order__actions">';

        // Shipping is its own form, because it is about a QUANTITY. The status
        // is not chosen here: ShipItems works out whether this parcel finishes
        // the line, and the line says «بخشی ارسال‌شده» until one does.
        if ((int) $movement['remaining'] > 0 && $item->status !== OrderItemStatus::Cancelled) {
            $options = ['' => __('— شرکت حمل —', 'tecteb-marketplace-core')] + $carriers;
            $html .= '<form method="post" action="' . esc_url($ordersUrl) . '" class="tv-inline tv-ship">'
                . $nonce
                . '<input type="hidden" name="tmc_vendor_action" value="ship_order_item">'
                . '<input type="hidden" name="item_id" value="' . esc_attr((string) $item->id) . '">'
                . VendorUi::input(
                    'ship_qty_' . $item->id,
                    __('تعداد این بسته', 'tecteb-marketplace-core'),
                    (string) $movement['remaining'],
                    true,
                    'number',
                    'ltr',
                    sprintf(
                        /* translators: %s: units still to send */
                        __('حداکثر %s عدد باقی مانده است. می‌توانید کمتر بفرستید و بقیه را بعداً.', 'tecteb-marketplace-core'),
                        $fa((int) $movement['remaining'])
                    )
                )
                . VendorUi::select('carrier_' . $item->id, __('شرکت حمل', 'tecteb-marketplace-core'), $options, $item->carrier)
                . VendorUi::input('tracking_' . $item->id, __('کد رهگیری', 'tecteb-marketplace-core'), '', true, 'text', 'ltr')
                . VendorUi::submit(__('ثبت ارسال این بسته', 'tecteb-marketplace-core'))
                . '</form>';
        }

        // …and a return, which is about a quantity too. Opening one decides
        // nothing: the manager does that, because the terms are not set.
        if ((int) $movement['returnable'] > 0 && $item->status->hasShipped()) {
            $html .= '<form method="post" action="' . esc_url($ordersUrl) . '" class="tv-inline tv-return">'
                . $nonce
                . '<input type="hidden" name="tmc_vendor_action" value="open_return">'
                . '<input type="hidden" name="item_id" value="' . esc_attr((string) $item->id) . '">'
                . VendorUi::input(
                    'return_qty_' . $item->id,
                    __('تعداد مرجوعی', 'tecteb-marketplace-core'),
                    '1',
                    true,
                    'number',
                    'ltr',
                    sprintf(
                        /* translators: %s: how many may still be returned */
                        __('حداکثر %s عدد. مهلت و شرایط تجاری مرجوعی هنوز تعیین نشده؛ تصمیم با مدیر است.', 'tecteb-marketplace-core'),
                        $fa((int) $movement['returnable'])
                    )
                )
                . VendorUi::input('return_reason_' . $item->id, __('علت', 'tecteb-marketplace-core'), '')
                . VendorUi::submit(__('ثبت درخواست مرجوعی', 'tecteb-marketplace-core'), 'secondary')
                . '</form>';
        }

        // The plain status moves a person actually chooses.
        foreach ($states->manualMovesFrom($item->status) as $status) {
            $html .= '<form method="post" action="' . esc_url($ordersUrl) . '" class="tv-inline">'
                . $nonce
                . '<input type="hidden" name="tmc_vendor_action" value="move_order_item">'
                . '<input type="hidden" name="item_id" value="' . esc_attr((string) $item->id) . '">'
                . '<input type="hidden" name="to" value="' . esc_attr($status->value) . '">'
                . VendorUi::submit(OrderMessages::action($status), $status === OrderItemStatus::Cancelled ? 'secondary' : 'primary')
                . '</form>';
        }
        if ($html === '<div class="tv-order__actions">') {
            return '<p class="tv-hint">' . esc_html__('کار باز دیگری روی این قلم نیست.', 'tecteb-marketplace-core') . '</p>';
        }
        return $html . '</div>';
    }

    /** @param callable(string|int):string $fa */
    private static function pager(int $page, int $total, string $status, string $ordersUrl, callable $fa): string
    {
        $pages = (int) ceil($total / self::PER_PAGE);
        if ($pages <= 1) {
            return '<p class="tv-hint">' . esc_html(sprintf(__('%s قلم', 'tecteb-marketplace-core'), $fa($total))) . '</p>';
        }
        $base = $status === '' ? $ordersUrl : add_query_arg('status', $status, $ordersUrl);
        $html = '<nav class="tv-pager" aria-label="' . esc_attr__('صفحه‌بندی سفارش‌ها', 'tecteb-marketplace-core') . '">';
        if ($page > 1) {
            $html .= '<a class="tv-btn tv-btn--secondary" href="' . esc_url(add_query_arg('paged', $page - 1, $base)) . '">'
                . esc_html__('صفحه قبل', 'tecteb-marketplace-core') . '</a>';
        }
        $html .= '<span class="tv-pager__status">' . esc_html(sprintf(
            __('صفحه %1$s از %2$s — %3$s قلم', 'tecteb-marketplace-core'),
            $fa($page),
            $fa($pages),
            $fa($total)
        )) . '</span>';
        if ($page < $pages) {
            $html .= '<a class="tv-btn tv-btn--secondary" href="' . esc_url(add_query_arg('paged', $page + 1, $base)) . '">'
                . esc_html__('صفحه بعد', 'tecteb-marketplace-core') . '</a>';
        }
        return $html . '</nav>';
    }
}
