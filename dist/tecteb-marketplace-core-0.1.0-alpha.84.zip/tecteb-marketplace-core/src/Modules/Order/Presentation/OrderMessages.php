<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Order\Presentation;

use Tecteb\Marketplace\Core\Support\PersianDigits;
use Tecteb\Marketplace\Modules\Finance\Presentation\MoneyText;
use Tecteb\Marketplace\Modules\Order\Domain\OrderItemStatus;

/** Every Persian sentence the order screens say. Null for a code it does not own. */
final class OrderMessages
{
    public static function status(OrderItemStatus $status): string
    {
        return match ($status) {
            OrderItemStatus::Placed => __('ثبت‌شده', 'tecteb-marketplace-core'),
            OrderItemStatus::Preparing => __('در حال آماده‌سازی', 'tecteb-marketplace-core'),
            OrderItemStatus::PartiallyShipped => __('بخشی ارسال‌شده', 'tecteb-marketplace-core'),
            OrderItemStatus::Shipped => __('ارسال‌شده', 'tecteb-marketplace-core'),
            OrderItemStatus::Delivered => __('تحویل‌شده', 'tecteb-marketplace-core'),
            OrderItemStatus::Cancelled => __('لغوشده', 'tecteb-marketplace-core'),
        };
    }

    /** success | warning | error | neutral */
    public static function statusTone(OrderItemStatus $status): string
    {
        return match ($status) {
            OrderItemStatus::Delivered => 'success',
            OrderItemStatus::Placed, OrderItemStatus::Preparing,
            OrderItemStatus::PartiallyShipped => 'warning',
            OrderItemStatus::Cancelled => 'error',
            OrderItemStatus::Shipped => 'neutral',
        };
    }

    /** The button that moves an item into this status. */
    public static function action(OrderItemStatus $status): string
    {
        return match ($status) {
            OrderItemStatus::Preparing => __('شروع آماده‌سازی', 'tecteb-marketplace-core'),
            OrderItemStatus::PartiallyShipped,
            OrderItemStatus::Shipped => __('ثبت ارسال', 'tecteb-marketplace-core'),
            OrderItemStatus::Delivered => __('تحویل شد', 'tecteb-marketplace-core'),
            OrderItemStatus::Cancelled => __('لغو این قلم', 'tecteb-marketplace-core'),
            OrderItemStatus::Placed => __('بازگشت به ثبت‌شده', 'tecteb-marketplace-core'),
        };
    }

    /**
     * @param array<string,scalar|null> $context
     * @return string|null null when this code belongs to another module
     */
    public static function notice(string $code, array $context = []): ?string
    {
        $fa = static fn (mixed $v): string => PersianDigits::toPersian((string) $v);
        return match ($code) {
            'order_item_preparing' => __('این قلم «در حال آماده‌سازی» شد.', 'tecteb-marketplace-core'),
            'order_item_shipped' => ((int) ($context['remaining'] ?? 0)) > 0
                ? sprintf(
                    /* translators: 1: units in this parcel, 2: units still to send */
                    __('ارسال %1$s عدد ثبت شد. %2$s عدد از این قلم هنوز ارسال نشده و می‌توانید بعداً با کد رهگیری دیگری بفرستید.', 'tecteb-marketplace-core'),
                    $fa($context['quantity'] ?? 0),
                    $fa($context['remaining'] ?? 0)
                )
                : __('ارسال ثبت شد و کل این قلم فرستاده شد. کد رهگیری برای مشتری نمایش داده می‌شود.', 'tecteb-marketplace-core'),
            'quantity_required' => __('تعداد را وارد کنید؛ دست‌کم یک عدد.', 'tecteb-marketplace-core'),
            'quantity_exceeds_remaining' => sprintf(
                /* translators: 1: requested, 2: what is left */
                __('%1$s عدد خواسته شده، ولی فقط %2$s عدد از این قلم باقی مانده است.', 'tecteb-marketplace-core'),
                $fa($context['requested'] ?? 0),
                $fa($context['remaining'] ?? 0)
            ),
            'quantity_exceeds_returnable' => sprintf(
                /* translators: 1: requested, 2: what may still be returned */
                __('%1$s عدد خواسته شده، ولی حداکثر %2$s عدد از این قلم قابل مرجوعی است.', 'tecteb-marketplace-core'),
                $fa($context['requested'] ?? 0),
                $fa($context['returnable'] ?? 0)
            ),
            'return_opened' => sprintf(
                /* translators: %s: quantity */
                __('درخواست مرجوعی برای %s عدد ثبت شد. تصمیم با مدیر بازارگاه است؛ مهلت و شرایط تجاری مرجوعی هنوز تعیین نشده و این درخواست خودکار رد یا تأیید نمی‌شود.', 'tecteb-marketplace-core'),
                $fa($context['quantity'] ?? 0)
            ),
            'return_approved' => __('مرجوعی تأیید شد. هنوز هیچ پولی برنگشته است.', 'tecteb-marketplace-core'),
            'return_rejected' => __('مرجوعی رد شد.', 'tecteb-marketplace-core'),
            'return_received' => ((int) ($context['restocked'] ?? 0)) > 0
                ? sprintf(
                    /* translators: %s: units returned to stock */
                    __('کالا تحویل گرفته شد و %s عدد به موجودی ووکامرس برگشت.', 'tecteb-marketplace-core'),
                    $fa($context['restocked'] ?? 0)
                )
                : __('کالا تحویل گرفته شد. موجودی تغییر نکرد.', 'tecteb-marketplace-core'),
            'return_cancelled' => __('درخواست مرجوعی لغو شد.', 'tecteb-marketplace-core'),
            // Four parts, named. «بازپرداخت» on its own has been read as «the
            // customer has their money», and two of the four are still a
            // person's job — one of them being the money itself.
            'return_refunded' => sprintf(
                /* translators: 1: amount, 2: what was done, 3: what was not */
                __('در دفترکل بازگشت %1$s ثبت شد. انجام‌شده: %2$s. انجام‌نشده و با شماست: %3$s. کرایهٔ ارسال و کسورات احتمالی تعیین‌نشده‌اند و در این مبلغ نیستند.', 'tecteb-marketplace-core'),
                // At the scale `refund()` carries back, not at a guessed one.
                // `array_key_exists` rather than `??`: a context with no
                // `exponent` at all is an older message, and 0 is what it
                // meant (`alpha.60`).
                MoneyText::format(
                    (int) ($context['refund_minor'] ?? 0),
                    array_key_exists('exponent', $context) ? (int) $context['exponent'] : 0
                ) ?? $fa((string) ($context['refund_minor'] ?? 0)),
                self::refundDid($context),
                self::refundDidNot($context)
            ),
            'reconciliation_required' => __('این مرجوعی نیمه‌کاره ماند: ردیف مرجوعی ثبت شد ولی دفترکل خطوط معکوس را نپذیرفت. هیچ تلاش خودکاری دوباره انجام نمی‌شود؛ یک نفر باید تصمیم بگیرد کدام درست است.', 'tecteb-marketplace-core'),
            'already_refunded' => __('این مرجوعی قبلاً بازپرداخت شده است. بازپرداخت دوم ثبت نمی‌شود.', 'tecteb-marketplace-core'),
            'use_refund' => __('برای ثبت بازگشت مالی از دکمهٔ بازپرداخت استفاده کنید؛ این مسیر پول جابه‌جا نمی‌کند.', 'tecteb-marketplace-core'),
            // The parenthesis used to name the cause — «نرخ کمیسیون
            // تعیین‌نشده» — which was the only cause when it was written and
            // is no longer one of them: a line can have no recorded share
            // because its unit was unreadable, because the ledger refused it,
            // or because a fixed commission exceeded it. A named cause that is
            // sometimes wrong is worse than none, and the screen that lists
            // incomplete lines gives the real reason per line.
            'nothing_recorded' => __('برای این قلم هیچ سهم مالی ثبت نشده بود، پس چیزی برای معکوس‌کردن وجود ندارد.', 'tecteb-marketplace-core'),
            'ledger_already_recorded' => __('ردیف مرجوعی ثبت شد ولی دفترکل این رویداد را از قبل داشت. مرجوعی به وضعیت «نیازمند تطبیق» رفت و خودکار تکرار نمی‌شود؛ یک نفر باید این دو را بررسی کند.', 'tecteb-marketplace-core'),
            'unbalanced_reversal' => __('خطوط معکوس متوازن نشدند؛ چیزی در دفترکل ثبت نشد.', 'tecteb-marketplace-core'),
            // The two unit refusals. Both are read BEFORE anything is written,
            // so «چیزی ثبت نشد» is a statement of fact in each.
            'refund_unit_unknown' => sprintf(
                /* translators: 1: order item id */
                __('واحد پولِ این قلم ثبت نشده است (قلم #%1$s هیچ رویداد مالی ندارد)، پس بازگشت با واحد حدسی ثبت نمی‌شود. چیزی ثبت نشد. برای رفعش سفارش باید دوباره ثبت شود، یا مبلغ در ووکامرس دستی وارد شود.', 'tecteb-marketplace-core'),
                $fa((int) ($context['item_id'] ?? $context['order_item_id'] ?? 0))
            ),
            'refund_unit_inconsistent' => sprintf(
                /* translators: 1: order item id, 2: ledger event key */
                __('خطوط رویداد مالی این قلم (#%1$s، رویداد %2$s) واحد پول یکسانی ندارند، پس واحدِ بازگشت قابل تعیین نیست. چیزی ثبت نشد و هیچ تبدیلی انجام نمی‌شود؛ این ردیف‌ها باید دستی تطبیق شوند.', 'tecteb-marketplace-core'),
                $fa((int) ($context['item_id'] ?? $context['order_item_id'] ?? 0)),
                (string) ($context['event_key'] ?? '')
            ),
            // ⛔ NOT «the split is inexact» — that is allocated now, by the
            // owner's decision. This is the one case the arithmetic still
            // refuses: a figure outside the integer range, which cannot be
            // answered without a float. The sentence says so plainly and
            // does not offer a workaround it cannot promise, because a
            // refusal a manager cannot act on is half a refusal
            // (`alpha.65`) — and inventing one would be worse.
            'return_share_out_of_range' => sprintf(
                /* translators: 1: return id, 2: requested quantity, 3: line quantity, 4: line total */
                __('سهم این مرجوعی قابل محاسبه با عدد صحیح نیست: %2$s عدد از %3$s عددِ قلمی به مبلغ کل %4$s. مبلغ یا تعداد از ظرفیت عددِ این سیستم بیرون است و این افزونه برای پول از عدد اعشاری ماشینی استفاده نمی‌کند، پس چیزی ثبت نشد و مرجوعی #%1$s سر جایش است. این مورد را به پشتیبانی گزارش کنید.', 'tecteb-marketplace-core'),
                $fa((int) ($context['return_id'] ?? 0)),
                $fa((int) ($context['quantity'] ?? 0)),
                $fa((int) ($context['line_quantity'] ?? 0)),
                self::money((int) ($context['base_minor'] ?? 0), $context['exponent'] ?? null)
            ),
            // The THIRD unit answer, and it is not one of the two above:
            // «نمی‌دانم» درباره واحد با «واحدها با هم نمی‌خوانند» یکی نیست.
            'reversed_unit_unreadable' => sprintf(
                /* translators: 1: order item id */
                __('ساختار جدول مرجوعی خوانده نشد، پس واحد پولِ مرجوعی‌های قبلی این قلم (#%1$s) معلوم نیست و از آن کم نمی‌شود. چیزی ثبت نشد. این یک خطای خواندن است نه تعارض داده؛ پس از رفع آن دوباره تلاش کنید.', 'tecteb-marketplace-core'),
                $fa((int) ($context['item_id'] ?? $context['order_item_id'] ?? 0))
            ),
            'reversed_unit_inconsistent' => sprintf(
                /* translators: 1: order item id */
                __('مرجوعی‌های قبلی این قلم (#%1$s) در واحدی غیر از واحد فروش ثبت شده‌اند، پس کم‌کردنشان از مبلغ این قلم درست نیست. چیزی ثبت نشد و هیچ تبدیلی انجام نمی‌شود.', 'tecteb-marketplace-core'),
                $fa((int) ($context['item_id'] ?? $context['order_item_id'] ?? 0))
            ),
            'order_item_cancelled_return' => __('روی قلمی که لغو شده، ارسال ثبت نمی‌شود.', 'tecteb-marketplace-core'),
            'order_item_delivered' => __('تحویل ثبت شد.', 'tecteb-marketplace-core'),
            'order_item_cancelled' => __('این قلم لغو شد. سهم مالی ثبت‌شده در دفترکل پاک نمی‌شود و تسویه‌اش جداگانه تعیین تکلیف می‌شود.', 'tecteb-marketplace-core'),
            'carrier_required' => __('برای ثبت ارسال، انتخاب شرکت حمل لازم است.', 'tecteb-marketplace-core'),
            'invalid_transition' => __('این تغییر وضعیت از وضعیت فعلی ممکن نیست.', 'tecteb-marketplace-core'),
            // The commission rate is NOT in this sentence any more. It was
            // until `alpha.57`, and it was true then: an unset rate closed the
            // order gate. The owner has decided otherwise — a product with no
            // commission sells — so naming it here would send a manager to
            // set a number that changes nothing. What still closes the gate is
            // the owner's own open decisions, and the sentence says that and
            // only that.
            'orders_blocked' => __('ماژول سفارش بازارگاه هنوز عملیاتی نیست. تا بسته‌شدن تصمیم‌های مالی مالک، محصولات بازارگاه فروخته نمی‌شوند.', 'tecteb-marketplace-core'),
            'order_trial_mode' => sprintf(
                __('حالت آزمایشی سفارش روشن است (محیط: %s). قواعد مالی نمونه‌اند و این حالت روی سایت اصلی پذیرفته نمی‌شود.', 'tecteb-marketplace-core'),
                (string) ($context['environment'] ?? '')
            ),
            'unrecorded_share' => sprintf(
                __('%s قلم بدون ثبت سهم مالی مانده است؛ تا تعیین نرخ، تسویه‌شان ممکن نیست.', 'tecteb-marketplace-core'),
                $fa($context['count'] ?? 0)
            ),
            default => null,
        };
    }

    /**
     * The parts of a refund this plugin actually performed, in words.
     *
     * @param array<string,scalar|null> $context
     */
    private static function refundDid(array $context): string
    {
        $done = [__('معکوس‌کردن خطوط دفترکل (بدون پاک‌کردن هیچ خط قبلی)', 'tecteb-marketplace-core')];
        if (!empty($context['did_stock'])) {
            $done[] = __('بازگرداندن کالا به موجودی ووکامرس', 'tecteb-marketplace-core');
        }
        if (!empty($context['did_wc_refund'])) {
            $done[] = __('پیوند به refund ووکامرسی که خودتان ساخته‌اید', 'tecteb-marketplace-core');
        }
        return implode('، ', $done);
    }

    /**
     * …and the parts it did not, which is the half people assume.
     *
     * @param array<string,scalar|null> $context
     */
    private static function refundDidNot(array $context): string
    {
        $missing = [];
        if (empty($context['did_wc_refund'])) {
            $missing[] = __('ساختن رکورد refund در ووکامرس', 'tecteb-marketplace-core');
        }
        if (empty($context['did_money'])) {
            $missing[] = __('انتقال واقعی وجه به مشتری — در این نسخه هیچ درگاه پرداختی وصل نیست و این کار از افزونه برنمی‌آید', 'tecteb-marketplace-core');
        }
        if (empty($context['did_stock'])) {
            $missing[] = __('بازگرداندن کالا به موجودی', 'tecteb-marketplace-core');
        }
        return $missing === [] ? __('چیزی', 'tecteb-marketplace-core') : implode('، ', $missing);
    }

    /** @return list<string> codes this module considers a success */
    public static function successCodes(): array
    {
        return [
            'order_item_preparing', 'order_item_shipped', 'order_item_delivered',
            'return_opened', 'return_approved', 'return_received',
            'return_refunded', 'return_cancelled',
        ];
    }

    public static function isErrorNotice(string $code): bool
    {
        return !in_array($code, self::successCodes(), true);
    }

    /**
     * An amount at the scale it was recorded at, for a sentence.
     *
     * `MoneyText` is the one place an integer plus an exponent becomes text
     * (`alpha.67`). A `null` exponent means the row did not say, and then
     * the bare digits are printed rather than a figure at a guessed scale.
     */
    private static function money(int $minor, mixed $exponent): string
    {
        $scale = is_int($exponent) ? $exponent : (is_numeric($exponent) ? (int) $exponent : null);
        if ($scale === null) {
            return PersianDigits::toPersian((string) $minor);
        }
        return MoneyText::format($minor, $scale) ?? PersianDigits::toPersian((string) $minor);
    }
}
