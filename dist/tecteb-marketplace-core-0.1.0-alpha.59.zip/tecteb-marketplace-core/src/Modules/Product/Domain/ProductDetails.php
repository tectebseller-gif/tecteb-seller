<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Domain;

/**
 * The four-step product form of §6, as one value object.
 *
 * Prices are integer minor units for the same reason the ledger's are: a
 * price that arrives as a float is a price that can be off by a rial, and it
 * is the number every commission is computed from.
 */
final class ProductDetails
{
    public function __construct(
        // 1. introduction
        public readonly string $title = '',
        public readonly string $type = ProductType::SIMPLE,
        public readonly string $categoryKey = '',
        public readonly string $brand = '',
        public readonly string $shortDescription = '',
        // 2. price and inventory
        public readonly int $priceMinor = 0,
        public readonly ?int $salePriceMinor = null,
        public readonly ?string $saleFrom = null,
        public readonly ?string $saleTo = null,
        public readonly string $sku = '',
        public readonly int $stock = 0,
        public readonly int $minPurchase = 1,
        public readonly ?int $maxPurchase = null,
        // 3. technical
        public readonly int $weightGrams = 0,
        public readonly string $dimensions = '',
        public readonly string $taxClass = '',
        /**
         * The vendor's long description — step 1's second tab, and WooCommerce's
         * own `description`.
         *
         * **Why it is `?string` and not `string`.** `null` means this product
         * predates the field: nobody has asked for anything, so the projector
         * leaves WooCommerce's long description ALONE. `''` means the vendor
         * cleared it on purpose, and that is written. A plain `string` would
         * collapse those two into «empty», and the first one would then empty
         * the long description of every product that already exists — a
         * manager's text and their SEO with it.
         *
         * Last in the list rather than beside `shortDescription`, where it
         * belongs by meaning: sixteen promoted parameters are addressed
         * positionally in places, and inserting one in the middle would
         * silently shift every argument after it. Appending cannot.
         */
        public readonly ?string $description = null,
        /**
         * The purchase step — new in `alpha.45`, and LAST for the same reason
         * `description` is: seventeen promoted parameters are addressed
         * positionally in places, and inserting one beside `maxPurchase`
         * where it belongs by meaning would silently shift every argument
         * after it. Appending cannot.
         *
         * `1` means no stepping and is the column default, so every row that
         * existed before this field reads as «any quantity». The full
         * semantics — and why the step counts from the MINIMUM rather than
         * from zero — are written in `PurchaseQuantity`.
         */
        public readonly int $purchaseStep = 1
    ) {
    }

    /** The purchase-quantity rule these details express. */
    public function purchaseQuantity(): PurchaseQuantity
    {
        return PurchaseQuantity::of($this->minPurchase, $this->maxPurchase, $this->purchaseStep);
    }

    /**
     * The same details with a few fields replaced.
     *
     * Sixteen readonly promoted properties make a hand-written copy a place
     * for a field to go missing — and the manager's correction is exactly the
     * write where losing one would be silent. Unknown keys are ignored rather
     * than guessed at.
     *
     * @param array<string,mixed> $changes
     */
    public function with(array $changes): self
    {
        $pick = fn (string $key, mixed $current): mixed => array_key_exists($key, $changes) ? $changes[$key] : $current;
        return new self(
            (string) $pick('title', $this->title),
            (string) $pick('type', $this->type),
            (string) $pick('categoryKey', $this->categoryKey),
            (string) $pick('brand', $this->brand),
            (string) $pick('shortDescription', $this->shortDescription),
            (int) $pick('priceMinor', $this->priceMinor),
            ($v = $pick('salePriceMinor', $this->salePriceMinor)) === null ? null : (int) $v,
            ($v = $pick('saleFrom', $this->saleFrom)) === null ? null : (string) $v,
            ($v = $pick('saleTo', $this->saleTo)) === null ? null : (string) $v,
            (string) $pick('sku', $this->sku),
            (int) $pick('stock', $this->stock),
            (int) $pick('minPurchase', $this->minPurchase),
            ($v = $pick('maxPurchase', $this->maxPurchase)) === null ? null : (int) $v,
            (int) $pick('weightGrams', $this->weightGrams),
            (string) $pick('dimensions', $this->dimensions),
            (string) $pick('taxClass', $this->taxClass),
            // `null` is a VALUE here, not «unset»: a caller that asks for
            // `description => null` is saying «this product has never had
            // one», and `$pick` distinguishes that from not naming the key at
            // all. The three nullable price fields above read the same way.
            ($v = $pick('description', $this->description)) === null ? null : (string) $v,
            (int) $pick('purchaseStep', $this->purchaseStep)
        );
    }

    /**
     * Fields that must be filled before the product can be submitted. Stock
     * is NOT here: a product may legitimately be submitted out of stock, and
     * zero stock stops the sale rather than the paperwork (A.1).
     *
     * @return list<string>
     */
    public function missingFields(): array
    {
        $missing = [];
        if (trim($this->title) === '') {
            $missing[] = 'title';
        }
        if (trim($this->categoryKey) === '') {
            $missing[] = 'category';
        }
        if ($this->priceMinor <= 0) {
            $missing[] = 'price';
        }
        return $missing;
    }

    public function isComplete(): bool
    {
        return $this->missingFields() === [];
    }

    /**
     * The price a buyer would pay right now — the base every commission is
     * calculated from (FIN-01: after discount, before tax).
     */
    public function effectivePriceMinor(string $today): int
    {
        if ($this->salePriceMinor === null || $this->salePriceMinor < 0) {
            return $this->priceMinor;
        }
        if ($this->saleFrom !== null && $today < $this->saleFrom) {
            return $this->priceMinor;
        }
        if ($this->saleTo !== null && $today > $this->saleTo) {
            return $this->priceMinor;
        }
        return $this->salePriceMinor;
    }

    /**
     * Zero stock stops the purchase. Backorder and pre-order are not
     * "disabled by default" — they do not exist (A.1), so there is no setting
     * that could turn them on.
     */
    public function isPurchasable(string $today): bool
    {
        return $this->stock > 0 && $this->effectivePriceMinor($today) > 0;
    }
}
