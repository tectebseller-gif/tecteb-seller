<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Migration\Application;

use Tecteb\Marketplace\Contracts\CapabilityCheckerInterface;
use Tecteb\Marketplace\Core\Audit\AuditEventCatalog;
use Tecteb\Marketplace\Core\Audit\AuditLogger;
use Tecteb\Marketplace\Core\Lifecycle\Capabilities;
use Tecteb\Marketplace\Modules\Product\Application\CatalogProjectorInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductRepositoryInterface;
use Tecteb\Marketplace\Modules\Product\Application\PurchasePolicy;
use Tecteb\Marketplace\Modules\Product\Domain\LinkOwnership;
use Tecteb\Marketplace\Modules\Vendor\Application\OperationResult;

/**
 * The moment this marketplace starts deciding about somebody else's product —
 * and the only way it can happen.
 *
 * An imported row is `observed`: it knows which WooCommerce product it
 * corresponds to, and nothing follows from that. Transferring makes it
 * `marketplace`, and everything follows at once: the purchase guard starts
 * answering about that product, the storefront stop will draft it, the
 * projector will write to it. On a live site that means a product a Dokan
 * vendor is selling today becomes a product this plugin can take off sale.
 *
 * So it is a separate service with a separate button and a separate audit
 * line, it needs the manager's capability, and it is reversible by the same
 * explicit act in the other direction. Nothing infers it, nothing does it in
 * passing, and no import has ever performed it.
 *
 * It writes exactly two things to the WooCommerce post, and nothing else: the
 * link meta that says which marketplace row owns it, and the vendor meta. That
 * write is unavoidable and it is the point — without it the projector keeps
 * refusing the post (`owns()` asks for exactly that meta), so a "transfer"
 * would be a label that changed nothing and a later stop would report itself
 * incomplete forever. Measured: before this write, taking ownership and then
 * stopping left the product published and the stop failing.
 *
 * The product's title, price, stock, status and author are NOT touched. Giving
 * ownership back deletes the same two keys, so the post returns to exactly the
 * state it was in.
 */
final class TransferOwnership
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly CatalogProjectorInterface $catalog,
        private readonly AuditLogger $audit,
        private readonly ?CapabilityCheckerInterface $capabilities = null,
        // Optional, so every existing construction site keeps working. Its
        // absence means a long-lived process may keep a stale «is this ours»
        // answer after a transfer — see `PurchasePolicy::forget()`.
        private readonly ?PurchasePolicy $purchases = null,
        /**
         * What a projection would overwrite or cannot express for this
         * product — asked at the moment somebody accepts management, because
         * that is the moment it starts to matter.
         *
         * Optional so a build without the catalogue reader keeps working. Its
         * absence means no risks are named and the transfer behaves exactly as
         * it did before `alpha.55` — the old behaviour rather than a wrong
         * new one — and the page says the check did not run.
         */
        private readonly ?CatalogueReaderInterface $catalogue = null,
        /**
         * Asked two questions about an intaken row and nothing else: «does it
         * still agree with the shop?» and «make it agree again». The
         * translation from a WooCommerce product to this marketplace's fields
         * lives there and must live in ONE place — two of them would agree
         * until the day they did not (`alpha.14`).
         *
         * Optional: without it no drift is reported and the transfer behaves
         * as it did in `alpha.55`, and the page says the check did not run
         * rather than implying it passed.
         */
        private readonly ?ImportExistingProducts $intake = null
    ) {
    }

    /**
     * Observed → marketplace: this plugin now decides about the product.
     *
     * **And from `alpha.55` it refuses first, when the product is in a state
     * this marketplace cannot preserve.** An intake copies every field the
     * four-step form can express, so the first projection writes the same
     * values back — but a WooCommerce product can be in states that form has
     * no field for at all: a catalogue visibility other than `visible`, stock
     * management switched off, backorders allowed, a grouped or external
     * type. The projector writes status and visibility unconditionally and
     * forces `manage_stock` on, so accepting such a product means losing
     * those settings at the next save.
     *
     * «حذف یا تبدیل ضمنی نکن» — so they are named and the transfer stops
     * until the manager acknowledges each one BY KEY. `$acknowledged` is the
     * list of risk keys the screen printed, and a tick that does not carry
     * them is refused rather than trusted: the `alpha.49` rule, that an
     * override must carry what was shown.
     *
     * **And from `alpha.56` it also refuses a SNAPSHOT THAT HAS GONE STALE.**
     * An intake records WooCommerce's values; acceptance is a step a manager
     * sleeps on; and `alpha.55` never asked whether the shop had moved in
     * between. Measured on its own bytes: a price changed from 450000 to
     * 480000 after the intake was back at 450000 after the first projection,
     * and no screen said a word. The risk list could not have caught it — it
     * is about fields this marketplace has no shape for, not about a value
     * that moved.
     *
     * `$seenShop` is `field => the FINGERPRINT of the shop value this page
     * printed` — `storefrontDrift()` hands the screen the exact string to put
     * in the hidden field, so the two halves cannot compute it differently
     * (`alpha.55`'s own mistake, one object out). A drift is
     * refused unless the tick carries those values, which is the `alpha.49`
     * rule once more: an override is permission about the numbers that were
     * shown, never about whatever is there when the form arrives. The other
     * way out is `refreshFromStorefront()`, one click, after which there is
     * no drift to acknowledge.
     *
     * @param list<string> $acknowledged risk keys the manager has read
     * @param array<string,string> $seenShop field => fingerprint of the shop
     *        value the page showed, from `storefrontDrift()`
     */
    public function take(int $productId, array $acknowledged = [], array $seenShop = []): OperationResult
    {
        $risks = $this->risksFor($productId);
        $unacknowledged = array_values(array_diff(array_keys($risks), $acknowledged));
        if ($unacknowledged !== []) {
            return OperationResult::failure('ownership_risks_unacknowledged', [
                'product_id' => $productId,
                'risks' => $unacknowledged,
                'sentences' => array_values(array_intersect_key($risks, array_flip($unacknowledged))),
            ]);
        }
        if ($this->intake !== null && $this->products->linkOwnership($productId) === LinkOwnership::Observed) {
            if (!$this->intake->driftReadable($productId)) {
                // «نمی‌دانم» is an answer and it is not «they agree»
                // (`alpha.49`): a read that failed must not become a licence.
                return OperationResult::failure('storefront_unreadable', ['product_id' => $productId]);
            }
            $drift = $this->intake->driftOf($productId);
            foreach ($drift as $field => $pair) {
                if (!array_key_exists($field, $seenShop)) {
                    return OperationResult::failure('storefront_moved', [
                        'product_id' => $productId,
                        'fields' => implode('، ', array_column($drift, 'label')),
                        'drift' => $drift,
                    ]);
                }
                if (!hash_equals((string) $pair['fingerprint'], trim((string) $seenShop[$field]))) {
                    // The page showed one number and the shop now holds
                    // another: the change arrived between the render and the
                    // click, so the tick is about a value nobody read.
                    return OperationResult::failure('storefront_moved_again', [
                        'product_id' => $productId,
                        'field' => (string) $pair['label'],
                        // The value is reported, not the fingerprint the form
                        // carried: a hex string tells a manager nothing, and
                        // what they need to know is what the shop holds now.
                        'now' => (string) $pair['shop'],
                    ]);
                }
            }
        }
        return $this->move($productId, LinkOwnership::Observed, LinkOwnership::Marketplace, 'ownership_taken');
    }

    /**
     * Where this row and the shop now disagree — for the screen and for the
     * guard, from ONE answer.
     *
     * A page that listed different differences from the ones `take()` checks
     * would let a manager acknowledge the wrong thing, which is the mistake
     * `risksFor()` exists to avoid and the same one twice over.
     *
     * @return array<string,array{row:string, shop:string, label:string, fingerprint:string}>
     */
    public function storefrontDrift(int $productId): array
    {
        return $this->intake?->driftOf($productId) ?? [];
    }

    public function storefrontReadable(int $productId): bool
    {
        return $this->intake?->driftReadable($productId) ?? false;
    }

    /**
     * Risks, drift and readability from ONE read of the WooCommerce product.
     *
     * ⛔ **Why it exists.** A screen that wants all three used to ask three
     * times: `risksFor()` reads the product, `storefrontReadable()` reads it
     * again, and `storefrontDrift()` a third time — and `detail()` is not
     * memoised on purpose, because `refreshFromStorefront()` writes and then
     * re-reads and a cache would hand it back the value it just replaced.
     * The hand-over screen lists every observed row, so 184 rows cost 552
     * product loads in one admin request before a single button was drawn.
     *
     * The three methods are kept and still answer the same way, so the guard
     * and any existing caller cannot drift apart from this one (`alpha.78`).
     *
     * @return array{readable:bool, risks:array<string,string>, drift:array<string,array{row:string, shop:string, label:string, fingerprint:string}>}
     */
    public function acceptanceState(int $productId): array
    {
        $none = ['readable' => false, 'risks' => [], 'drift' => []];
        if ($this->catalogue === null || $this->intake === null) {
            return $none;
        }
        $product = $this->products->find($productId);
        $wcProductId = (int) ($product?->wcProductId ?? 0);
        if ($product === null || $wcProductId <= 0) {
            return $none;
        }
        $detail = $this->catalogue->detail($wcProductId);
        if ($detail === []) {
            // A read that failed is not «they agree» (`alpha.49`), and
            // `readable: false` is what the screen prints and what `take()`
            // refuses on.
            return $none;
        }
        return [
            'readable' => true,
            'risks' => $this->catalogue->preservationRisksFrom($detail),
            'drift' => $this->intake->driftFrom($product, $detail),
        ];
    }

    /** Take the snapshot again, so there is no drift left to acknowledge. */
    public function refreshFromStorefront(int $productId): OperationResult
    {
        if ($this->intake === null) {
            return OperationResult::failure('storefront_refresh_unavailable', ['product_id' => $productId]);
        }
        return $this->intake->refreshFrom($productId);
    }

    /**
     * The fields accepting this product would put at risk, each named.
     *
     * Read-only, and offered to the screen so the warning and the refusal are
     * built from ONE answer: a page that listed different risks from the ones
     * the guard checks would let a manager acknowledge the wrong thing.
     *
     * @return array<string,string>
     */
    public function risksFor(int $productId): array
    {
        if ($this->catalogue === null) {
            return [];
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return [];
        }
        $wcProductId = (int) ($product->wcProductId ?? 0);
        if ($wcProductId <= 0) {
            return [];
        }
        return $this->catalogue->preservationRisks($wcProductId);
    }

    /** Marketplace → observed: it goes back to being a note in a ledger. */
    public function giveBack(int $productId): OperationResult
    {
        return $this->move($productId, LinkOwnership::Marketplace, LinkOwnership::Observed, 'ownership_given_back');
    }

    public function currentOwnership(int $productId): LinkOwnership
    {
        return $this->products->linkOwnership($productId);
    }

    private function move(int $productId, LinkOwnership $from, LinkOwnership $to, string $code): OperationResult
    {
        if ($this->capabilities === null || !$this->capabilities->can(Capabilities::REVIEW_VENDOR)) {
            return OperationResult::failure('forbidden');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        $current = $this->products->linkOwnership($productId);
        if ($current !== $from) {
            // Said plainly rather than as a generic failure: the person is
            // asking about who controls a product, and "it is already the
            // other way round" is the answer they need.
            return OperationResult::failure('ownership_already', [
                'product_id' => $productId,
                'ownership' => $current->value,
            ]);
        }
        $wcProductId = (int) ($product->wcProductId ?? 0);
        $postMoved = false;
        if ($wcProductId > 0) {
            // The post first: if this fails the row must NOT change, or the
            // marketplace would claim a product it cannot actually act on.
            $claimed = $to === LinkOwnership::Marketplace
                ? $this->catalog->claimStorefrontPost($product, $wcProductId)
                : $this->catalog->releaseStorefrontPost($product, $wcProductId);
            if (!$claimed) {
                return OperationResult::failure('storefront_refused', [
                    'product_id' => $productId,
                    'wc_product_id' => $wcProductId,
                ]);
            }
            $postMoved = true;
        }
        if (!$this->products->setLinkOwnership($productId, $to)) {
            // ⛔ TWO WRITES, ONE UNIT OF WORK — and until `alpha.90` only the
            // FIRST direction of failure was handled.
            //
            // The comment above says «if this fails the row must NOT change»,
            // which covers the post refusing. It says nothing about the row
            // refusing AFTER the post has already moved, and that half is the
            // dangerous one. Measured from source on `alpha.89`:
            //
            //  - TAKING: the post keeps the stamp while the row still says
            //    `observed`. The projector will not write (it asks the ROW,
            //    `SyncCatalog::mayWriteToStorefront()`), so nothing is sold
            //    wrongly — but no OTHER row can claim that post any more
            //    (`claimStorefrontPost()` refuses a post owned by somebody
            //    else) and a re-intake of it is refused too.
            //  - GIVING BACK: the stamp is gone while the row still says
            //    `marketplace`, and that combination CREATES A DUPLICATE. The
            //    projector is allowed by the row, `owns()` answers false,
            //    `linkedProduct()` returns null, and `project()` takes the
            //    `$isNew` branch and saves a SECOND WooCommerce product
            //    beside the first. Worse, the retry cannot help:
            //    `releaseStorefrontPost()` refuses outright when the post is
            //    not ours, so `giveBack()` would answer `storefront_refused`
            //    for ever while every save widened the damage.
            //
            // So the first write is put back, and the answer says whether it
            // actually went back: a restoration is a WRITE too and claiming
            // one that failed is the `alpha.31` mistake. `storage_failed`
            // now means «nothing changed, press the button again»;
            // `ownership_stamp_unrestored` means the two halves disagree and
            // names which way round, because those send the manager to two
            // different places.
            //
            // Not a transaction, on purpose: `releaseStorefrontPost()` calls
            // `wp_update_post()`, whose hooks and `clean_post_cache()` are
            // not covered by a rollback, so a rolled-back transaction would
            // leave a persistent object cache holding values no row carries.
            // Compensation is the honest shape here.
            $restored = !$postMoved || (
                $to === LinkOwnership::Marketplace
                    ? $this->catalog->releaseStorefrontPost($product, $wcProductId)
                    : $this->catalog->claimStorefrontPost($product, $wcProductId)
            );
            if (!$restored) {
                // Recorded, not just flashed: a manager who closes this page
                // would otherwise have nowhere to learn that this one post and
                // its row disagree.
                $this->audit->log(
                    AuditEventCatalog::DOKAN_OWNERSHIP_HALF_WRITTEN,
                    $this->capabilities->currentUserId() ?? 0,
                    'product',
                    (string) $productId,
                    [
                        'product_id' => $productId,
                        'wc_product_id' => $wcProductId,
                        'from' => $from->value,
                        'to' => $to->value,
                    ]
                );
            }
            return OperationResult::failure(
                $restored ? 'storage_failed' : 'ownership_stamp_unrestored',
                [
                    'product_id' => $productId,
                    'wc_product_id' => $wcProductId,
                    'from' => $from->value,
                    'to' => $to->value,
                ]
            );
        }
        $actorId = $this->capabilities->currentUserId() ?? 0;
        $this->audit->log(AuditEventCatalog::DOKAN_OWNERSHIP_CHANGED, $actorId, 'product', (string) $productId, [
            'product_id' => $productId,
            'wc_product_id' => (int) ($product->wcProductId ?? 0),
            'from' => $from->value,
            'to' => $to->value,
        ]);
        // Whatever the direction, the answer to «is this storefront product
        // ours» has just changed. Anything that remembered the old one is now
        // wrong about a product somebody is about to try to buy.
        $this->purchases?->forget($wcProductId);

        return OperationResult::success($code, [
            'product_id' => $productId,
            'wc_product_id' => (int) ($product->wcProductId ?? 0),
        ]);
    }
}
