<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Infrastructure\WooCommerce;

use Tecteb\Marketplace\Modules\Product\Application\StorefrontFieldsInterface;
use Tecteb\Marketplace\Modules\Product\Domain\FieldMerge;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\StorefrontField;
use Tecteb\Marketplace\Modules\Product\Domain\StorefrontImages;

/**
 * Reading the other side of the projection, and closing a disagreement.
 *
 * Every write here is preceded by the same ownership check the projector
 * makes — `owns()` — so a shop product or a Dokan product is never touched,
 * however the review screen was reached.
 *
 * **Nothing in here creates a second copy.** `keepStorefront()` ends with the
 * marketplace and WooCommerce holding the same value for a field that can
 * round-trip, and with the split NAMED for the one field that cannot. The
 * caller writes the marketplace side; this class returns the value so it can.
 */
final class WooCommerceStorefrontFields implements StorefrontFieldsInterface
{
    public const STATE_COMPARED = 'compared';
    public const STATE_NOT_PROJECTED = 'not_projected';
    public const STATE_WOOCOMMERCE_MISSING = 'woocommerce_missing';
    public const STATE_NOT_OURS = 'not_ours';
    public const STATE_UNREADABLE = 'unreadable';

    public function __construct(private readonly WooCommerceProjector $projector)
    {
    }

    /**
     * WHY the comparison came back empty — or that it did not.
     *
     * `compare()` answers `[]` for four situations that are not the same
     * thing, and the review card read all four as «the two sides are
     * identical»: there is no storefront product at all, WooCommerce is not
     * loaded so the read cannot be done, the post belongs to somebody else,
     * and the post is gone or unreadable. The owner saw the third sentence of
     * the set — «اطلاعات بازارگاه و ووکامرس برای این محصول یکی است» — about a
     * product whose WooCommerce copy still held the OLD short description.
     *
     * A screen cannot tell those apart from an empty list, so it asks.
     */
    public function comparisonState(Product $product): string
    {
        if (!$product->isProjected()) {
            return self::STATE_NOT_PROJECTED;
        }
        if (!function_exists('wc_get_product')) {
            return self::STATE_WOOCOMMERCE_MISSING;
        }
        if (!$this->projector->owns((int) $product->wcProductId, $product->id)) {
            return self::STATE_NOT_OURS;
        }
        return wc_get_product((int) $product->wcProductId) instanceof \WC_Product
            ? self::STATE_COMPARED
            : self::STATE_UNREADABLE;
    }

    public function compare(Product $product): array
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null) {
            return [];
        }
        $id = (int) $wcProduct->get_id();
        $rows = [];
        foreach (ProjectedFieldOwnership::FIELDS as $field) {
            $storefront = self::readField($wcProduct, $field);
            $stamp = (string) get_post_meta($id, ProjectedFieldOwnership::STAMP_PREFIX . $field, true);
            $managerOwns = (string) get_post_meta($id, ProjectedFieldOwnership::MANAGER_PREFIX . $field, true) === '1';
            // Asked of the meta table, not of the value. A vendor who cleared
            // a field proposed an empty string, and a screen that reads
            // absence off emptiness never shows that proposal at all — the
            // manager is never asked the question, so it can never be
            // answered.
            $pendingKey = ProjectedFieldOwnership::PENDING_PREFIX . $field;
            $hasPending = metadata_exists('post', $id, $pendingKey);
            $marketplace = $this->marketplaceValue($product, $field, array_map('intval', $wcProduct->get_category_ids()));
            $rows[] = new StorefrontField(
                $field,
                $marketplace,
                $storefront,
                $hasPending ? (string) get_post_meta($id, $pendingKey, true) : '',
                // `$createdByUs` is false and cannot be anything else here:
                // this reads a post that already existed. An unstamped field
                // therefore comes back `unknown`, which is what the review
                // screen needs in order to ask.
                ProjectedFieldOwnership::owner($stamp, $storefront, $managerOwns),
                in_array($field, ProjectedFieldOwnership::ROUND_TRIP, true),
                $managerOwns,
                $hasPending,
                // The SAME rule the projector writes by. Two implementations
                // of «is this a conflict?» are two answers on the day they
                // drift, and the screen would be the one that lies.
                FieldMerge::decide(
                    $product->baseline !== null && $product->baseline->has($field),
                    $product->baseline?->get($field) ?? '',
                    $marketplace,
                    $storefront,
                    $stamp,
                    $managerOwns,
                    false,
                    !in_array($field, ProjectedFieldOwnership::ROUND_TRIP, true)
                )
            );
        }
        return $rows;
    }

    public function keepStorefront(Product $product, string $field): ?string
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null || !in_array($field, ProjectedFieldOwnership::FIELDS, true)) {
            return null;
        }
        $id = (int) $wcProduct->get_id();
        update_post_meta($id, ProjectedFieldOwnership::MANAGER_PREFIX . $field, '1');
        delete_post_meta($id, ProjectedFieldOwnership::PENDING_PREFIX . $field);
        // The stamp is REMOVED, not refreshed. Leaving a stamp that matches
        // would say the marketplace wrote this, and a later projection would
        // then overwrite it — the flag and a matching stamp are two different
        // stories about the same field.
        delete_post_meta($id, ProjectedFieldOwnership::STAMP_PREFIX . $field);
        return self::readField($wcProduct, $field);
    }

    /**
     * The vendor's value wins — including when the vendor's value is nothing.
     *
     * Presence and content are two questions and `get_post_meta()` answers
     * them with the same empty string. The version this replaces asked only
     * the second: `$pending !== ''` meant «there is a proposal», so a vendor
     * who cleared their short description had that proposal treated as
     * absent. Pressing «خواستهٔ فروشنده اعمال شود» then deleted the proposal,
     * left the old text on the shop, stamped that text as the marketplace's
     * own — and said it had worked. Three lies in one click, and the next
     * projection kept all of them.
     *
     * So presence is `metadata_exists()` and the value is whatever is in
     * there, empty or not.
     */
    public function acceptProposal(Product $product, string $field): ?string
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null || !in_array($field, ProjectedFieldOwnership::FIELDS, true)) {
            return 'storage_failed';
        }
        $id = (int) $wcProduct->get_id();
        $pendingKey = ProjectedFieldOwnership::PENDING_PREFIX . $field;
        $before = self::readField($wcProduct, $field);

        if (metadata_exists('post', $id, $pendingKey)) {
            $value = (string) get_post_meta($id, $pendingKey, true);
        } else {
            // No proposal recorded. On a product older than the stamps that
            // is the normal case rather than an edge one: the field was
            // frozen the moment it was read, and no projection has run since
            // to write a proposal down. «خواستهٔ فروشنده اعمال شود» still has
            // to mean the marketplace's value, so it is taken from the
            // product record here instead of being read back off the shop —
            // reading it off the shop would make the button a no-op that
            // looked like it had done something. Empty counts here too: the
            // unsettled path and the proposal path are the same button and
            // have to be the same promise.
            $value = $this->marketplaceValue(
                $product,
                $field,
                array_map('intval', $wcProduct->get_category_ids())
            );
        }

        if ($value === '' && !StorefrontField::mayBeEmpty($field)) {
            // Refused before anything is written, and the proposal stays
            // where it is. A product with no name is a row nobody can find
            // again; quietly keeping the old title instead would leave the
            // record and the shop saying different things, which is the one
            // outcome this whole mechanism exists to prevent.
            return $field . '_required';
        }

        $changes = ProjectedFieldOwnership::fingerprint($value)
            !== ProjectedFieldOwnership::fingerprint($before);
        if ($changes && !self::writeField($wcProduct, $field, $value)) {
            return 'storage_failed';
        }
        // Re-read, for the reason the projector does: the value WooCommerce
        // keeps is not always the one it was handed. And `WC_Product::save()`
        // swallows its own exceptions and still hands back the product id
        // (`WC_Order::save()` does the same — `alpha.11`), so reading is the
        // only thing here that can tell a write from a failure.
        $fresh = wc_get_product($id);
        if (!$fresh instanceof \WC_Product) {
            return 'storage_failed';
        }
        $after = self::readField($fresh, $field);
        if ($changes && ProjectedFieldOwnership::fingerprint($after)
            === ProjectedFieldOwnership::fingerprint($before)) {
            // Asked for something different and got back exactly what was
            // there. Nothing moved, so nothing is cleared and nothing is
            // stamped, and the proposal is still on the review screen to try
            // again. A stamp written here would say the marketplace owns a
            // value it never managed to write.
            return 'storage_failed';
        }
        // Only now, and in this order: the proposal is gone BECAUSE it has
        // been applied, and the stamp records what the shop actually holds.
        delete_post_meta($id, $pendingKey);
        delete_post_meta($id, ProjectedFieldOwnership::MANAGER_PREFIX . $field);
        update_post_meta(
            $id,
            ProjectedFieldOwnership::STAMP_PREFIX . $field,
            ProjectedFieldOwnership::fingerprint($after)
        );
        return null;
    }

    /**
     * What the shop holds right now, field by field, as fingerprints.
     *
     * The review screen carries these into its own form. Between the page
     * being drawn and the button being pressed a manager can fix a typo in
     * WooCommerce, and an approval that wrote over it would undo an edit
     * nobody was shown. This is the same optimistic lock `row_version` is on
     * the record side — the other side of the product.
     *
     * @return array<string,string>
     */
    public function fingerprints(Product $product): array
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null) {
            return [];
        }
        $out = [];
        foreach (ProjectedFieldOwnership::FIELDS as $field) {
            $out[$field] = ProjectedFieldOwnership::fingerprint(self::readField($wcProduct, $field));
        }
        return $out;
    }

    /**
     * Which of the fields the reviewer was shown have moved since.
     *
     * Refused, not merged — the rule this codebase settled on for every
     * other lock: a merge would have to guess which title is the right one.
     *
     * @param array<string,string> $seen as `fingerprints()` returned them
     * @return list<string>
     */
    public function changedSince(Product $product, array $seen): array
    {
        if ($seen === []) {
            return [];          // nothing was claimed, so nothing is checked
        }
        $now = $this->fingerprints($product);
        $moved = [];
        foreach ($seen as $field => $fingerprint) {
            if (!is_string($field) || !isset($now[$field])) {
                continue;
            }
            if (!hash_equals((string) $fingerprint, $now[$field])) {
                $moved[] = $field;
            }
        }
        return $moved;
    }

    /**
     * What the shop actually holds, in the shape the marketplace row keeps.
     *
     * Called once, at approval, AFTER the projection. From that moment the
     * record and the shop say the same thing — which is what makes «ووکامرس
     * مرجع اطلاعات نهایی تأییدشده» true rather than aspirational, and what
     * lets the vendor's form show the approved values instead of a stale copy
     * of their own last draft.
     *
     * `description` is absent on purpose: the projector BUILDS it, so copying
     * it home would paste a rendered table into the raw text and the next
     * projection would render it again.
     *
     * @return array<string,string> field => value, for the fields that round-trip
     */
    public function reconcile(Product $product): array
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null) {
            return [];
        }
        $out = [];
        foreach (ProjectedFieldOwnership::ROUND_TRIP as $field) {
            $out[$field] = self::readField($wcProduct, $field);
        }
        return $out;
    }

    /**
     * Every field as the shop holds it — including the derived one.
     *
     * This is what a baseline is made of, and it deliberately includes
     * `description`: the baseline is «what both sides agreed», and the
     * generated text was part of that agreement even though it cannot be
     * copied back into the record.
     *
     * @return array<string,string>
     */
    public function storefrontValues(Product $product): array
    {
        $wcProduct = $this->storefrontProduct($product);
        if ($wcProduct === null) {
            return [];
        }
        $out = [];
        foreach (ProjectedFieldOwnership::FIELDS as $field) {
            $out[$field] = self::readField($wcProduct, $field);
        }
        return $out;
    }

    public function editorUrl(int $wcProductId): string
    {
        return $wcProductId > 0 ? (string) get_edit_post_link($wcProductId, 'url') : '';
    }

    /**
     * The shop page, or WordPress's preview of it, or nothing and a reason.
     *
     * **`get_post_status()` is asked first, and false is not ''.** A product row
     * can carry a WooCommerce id whose post has been deleted — the review list
     * already shows that state in words — and in that case there is nothing to
     * open. Offering a link to it would be a 404 with our name on it.
     *
     * **A non-published product is a preview, and a preview is gated here.** The
     * link WordPress builds is `?p=<id>&preview=true`, which carries no nonce, so
     * whether it may be opened is decided by core's own status rules for the
     * person who opens it. This method does not rely on that alone: it hands the
     * link out only to somebody who may edit the post, so the screen never puts
     * a non-public address in front of a viewer who has no business with it.
     * `edit_post` rather than a capability of ours, because the thing being
     * previewed is a WordPress post and WordPress is what decides who may see an
     * unpublished one.
     *
     * **Nothing is created and nothing is written.** Looking at a product that
     * has no WooCommerce post does not make one; that is «آماده‌سازی», a separate
     * button with its own nonce.
     *
     * @return array{url:string, public:bool, reason:string}
     */
    public function viewLink(int $wcProductId): array
    {
        if ($wcProductId <= 0) {
            return ['url' => '', 'public' => false, 'reason' => 'missing'];
        }
        $status = get_post_status($wcProductId);
        if ($status === false || $status === '') {
            return ['url' => '', 'public' => false, 'reason' => 'missing'];
        }
        if ($status === 'publish') {
            $url = (string) get_permalink($wcProductId);
            return $url !== ''
                ? ['url' => $url, 'public' => true, 'reason' => '']
                : ['url' => '', 'public' => false, 'reason' => 'missing'];
        }
        if (!current_user_can('edit_post', $wcProductId)) {
            return ['url' => '', 'public' => false, 'reason' => 'not_permitted'];
        }
        $url = (string) get_preview_post_link($wcProductId);
        return $url !== ''
            ? ['url' => $url, 'public' => false, 'reason' => '']
            : ['url' => '', 'public' => false, 'reason' => 'missing'];
    }

    public function seoPluginName(): string
    {
        if (defined('RANK_MATH_VERSION') || class_exists('RankMath')) {
            return 'Rank Math';
        }
        if (defined('WPSEO_VERSION')) {
            return 'Yoast SEO';
        }
        return '';
    }

    // -------------------------------------------------------------- internals

    private function storefrontProduct(Product $product): ?\WC_Product
    {
        if (!$product->isProjected() || !function_exists('wc_get_product')) {
            return null;
        }
        $id = (int) $product->wcProductId;
        if (!$this->projector->owns($id, $product->id)) {
            return null;        // not ours; never read it as if it were
        }
        $wcProduct = wc_get_product($id);
        return $wcProduct instanceof \WC_Product ? $wcProduct : null;
    }

    private static function readField(\WC_Product $wcProduct, string $field): string
    {
        return match ($field) {
            'title' => (string) $wcProduct->get_name(),
            'short_description' => (string) $wcProduct->get_short_description(),
            'description' => (string) $wcProduct->get_description(),
            'images' => ProjectedFieldOwnership::imagesToValue(
                (int) $wcProduct->get_image_id(),
                $wcProduct->get_gallery_image_ids()
            ),
            'category' => ProjectedFieldOwnership::idsToValue(
                array_map('intval', $wcProduct->get_category_ids())
            ),
            default => '',
        };
    }

    private static function writeField(\WC_Product $wcProduct, string $field, string $value): bool
    {
        $ids = static fn (string $v): array => array_values(array_filter(
            array_map('intval', explode(',', $v)),
            static fn (int $id): bool => $id > 0
        ));
        try {
            switch ($field) {
                case 'title':
                    $wcProduct->set_name($value);
                    break;
                case 'short_description':
                    $wcProduct->set_short_description($value);
                    break;
                case 'description':
                    $wcProduct->set_description($value);
                    break;
                case 'category':
                    $wcProduct->set_category_ids($ids($value));
                    break;
                case 'images':
                    // Decoded, not split on commas: the value names which
                    // picture is the featured one and what order the gallery
                    // is in, and accepting a proposal has to reproduce both.
                    $images = StorefrontImages::decode($value);
                    $wcProduct->set_image_id($images->main);
                    $wcProduct->set_gallery_image_ids($images->gallery);
                    break;
                default:
                    return false;
            }
            return (int) $wcProduct->save() > 0;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @param list<int> $currentCategoryIds what the storefront has right now */
    private function marketplaceValue(Product $product, string $field, array $currentCategoryIds = []): string
    {
        return match ($field) {
            'title' => $product->details->title,
            'short_description' => $product->details->shortDescription,
            // The vendor's own long description since `alpha.41`. It used to
            // be «what the projector WOULD generate», which was right while
            // the projector generated it — it does not any more.
            //
            // `null` (a row from before migration 23) becomes the STOREFRONT's
            // own text, so the two sides read as equal and nothing is reported
            // as a difference. That is the honest answer: the marketplace has
            // no long description for this product and is not going to write
            // one, so there is nothing to decide.
            'description' => $product->details->description
                ?? (string) ($this->storefrontProduct($product)?->get_description() ?? ''),
            'category' => $this->projector->storefrontCategoryFor($product, $currentCategoryIds),
            'images' => ProjectedFieldOwnership::imagesToValue($product->mainImageId, $product->imageIds),
            default => '',
        };
    }
}
