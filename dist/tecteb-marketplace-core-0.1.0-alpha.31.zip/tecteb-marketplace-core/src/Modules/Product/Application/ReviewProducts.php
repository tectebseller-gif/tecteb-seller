<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Application;

use Tecteb\Marketplace\Contracts\CapabilityCheckerInterface;
use Tecteb\Marketplace\Core\Audit\AuditEventCatalog;
use Tecteb\Marketplace\Core\Audit\AuditLogger;
use Tecteb\Marketplace\Core\Lifecycle\Capabilities;
use Tecteb\Marketplace\Modules\Product\Domain\ApprovedBaseline;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDecision;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\ProductSeo;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRevision;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStateMachine;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRowVersion;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;
use Tecteb\Marketplace\Modules\Product\Domain\StorefrontField;
use Tecteb\Marketplace\Modules\Product\Domain\StorefrontImages;
use Tecteb\Marketplace\Modules\Vendor\Application\OperationResult;

/**
 * The manager's side of §14.2.
 *
 * The rule that shapes this class: rejecting a proposed CHANGE must not take
 * the live product down («رد تغییر، نسخه منتشرشده فعلی را حذف نمی‌کند»). So a
 * revision decision only ever touches the revision row, except on approval,
 * where the payload is copied onto the product.
 *
 * Every decision carries a reason and lands in the audit log, and a decision
 * that would skip a state is refused by the state machine rather than written.
 */
final class ReviewProducts
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly ProductRevisionRepositoryInterface $revisions,
        private readonly SpecTemplateRepositoryInterface $templates,
        private readonly ProductReadiness $readiness,
        private readonly SyncCatalog $catalog,
        private readonly ProductPublishPolicy $publishing,
        private readonly ProductStateMachine $states,
        private readonly AuditLogger $audit,
        private readonly CapabilityCheckerInterface $capabilities,
        /**
         * Null when WooCommerce is not installed. Every method that uses it
         * says so rather than pretending the storefront agreed.
         */
        private readonly ?StorefrontFieldsInterface $storefront = null,
        /**
         * Append-only. Null only in the tests that predate it, and every
         * caller here treats a missing trail as «record nothing», never as
         * «there is nothing to record».
         */
        private readonly ?ProductDecisionRepositoryInterface $decisions = null
    ) {
    }

    /**
     * @param array<string,string> $seenFingerprints what the review screen
     *        showed for each storefront field. A manager can fix a typo in
     *        WooCommerce while this page is open, and an approval that wrote
     *        over it would undo an edit nobody was shown.
     */
    public function approve(int $productId, array $seenFingerprints = []): OperationResult
    {
        return $this->decide($productId, ProductStatus::Published, '', $seenFingerprints);
    }

    public function requestChanges(int $productId, string $note): OperationResult
    {
        if (trim($note) === '') {
            return OperationResult::failure('note_required');
        }
        return $this->decide($productId, ProductStatus::ChangesRequested, $note);
    }

    /**
     * Rejection archives rather than deletes: the vendor keeps the draft, the
     * marketplace keeps the record, and nothing a buyer ever saw disappears.
     */
    public function reject(int $productId, string $note): OperationResult
    {
        if (trim($note) === '') {
            return OperationResult::failure('note_required');
        }
        return $this->decide($productId, ProductStatus::Archived, $note);
    }

    /** Takes a live product out of the shop without touching its history. */
    public function suspend(int $productId, string $note): OperationResult
    {
        if (trim($note) === '') {
            return OperationResult::failure('note_required');
        }
        return $this->decide($productId, ProductStatus::Suspended, $note);
    }

    /** @param array<string,string> $seenFingerprints see `approve()` */
    public function republish(int $productId, array $seenFingerprints = []): OperationResult
    {
        return $this->decide($productId, ProductStatus::Published, '', $seenFingerprints);
    }

    /**
     * Approving a revision is the ONLY path that rewrites a live product.
     * The payload was captured when the vendor proposed it, so what the
     * manager saw in the diff is what gets written.
     *
     * It now carries the three guards the queue's approval carries, and until
     * `alpha.30` it carried none of them: no lock on the shop side, no look at
     * what the sync answered, and no new baseline. The last of those is the
     * one that compounds. A published product revised to B and then revised
     * back to A ends with the record saying A and — because the baseline was
     * never moved — «the vendor changed nothing», so nothing is written and
     * WooCommerce goes on holding B. Two versions of one product, and neither
     * screen able to say so.
     *
     * @param array<string,string> $seenFingerprints see `approve()`
     */
    public function approveRevision(int $revisionId, array $seenFingerprints = []): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        $revision = $this->revisions->find($revisionId);
        if ($revision === null) {
            return OperationResult::failure('not_found');
        }
        if (!$revision->isPending()) {
            return OperationResult::failure('already_decided');
        }
        $product = $this->products->find($revision->productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        // The same lock the queue's approval carries, on the same side. A
        // manager can fix a typo in WooCommerce while the revision page is
        // open, and this is the path that writes over the shop without ever
        // having shown the manager what is there now.
        if ($product->status === ProductStatus::Published && $this->storefront !== null) {
            $moved = $this->storefront->changedSince($product, $seenFingerprints);
            if ($moved !== []) {
                return OperationResult::failure('storefront_moved', [
                    'product_id' => $product->id,
                    'revision_id' => $revisionId,
                    'fields' => implode(',', $moved),
                ]);
            }
        }
        $details = $this->detailsFromPayload($revision->payload, $product->details);
        // UNGUARDED, and said so. The manager is applying a revision they
        // have already approved: one actor, no competing form, and no stamp to
        // carry. Every other write in this codebase names its version.
        if (!$this->products->updateDetails($product->id, $details, ProductRowVersion::UNGUARDED)) {
            return OperationResult::failure('storage_failed');
        }
        // Both of these answer, and until `alpha.31` neither was asked. A
        // failed spec write is the quiet one: the product keeps its OLD medical
        // answers, readiness still passes because they are all still there, the
        // projection goes out, a baseline is recorded about them and the
        // revision is marked approved. The vendor's edit simply never happened
        // and every screen says it did.
        $specs = $revision->payload['specs'] ?? [];
        if (is_array($specs)) {
            $template = $this->templates->findByCategory($details->categoryKey);
            if (!$this->products->saveSpecs($product->id, array_map('strval', $specs), $template?->schemaVersion ?? 0)) {
                return $this->revisionWriteFailed($product, $revisionId, 'specs');
            }
        }
        $images = $revision->payload['images'] ?? null;
        if (is_array($images)) {
            if (!$this->products->saveImages(
                $product->id,
                array_values(array_map('intval', $images)),
                (int) ($revision->payload['main_image_id'] ?? 0)
            )) {
                return $this->revisionWriteFailed($product, $revisionId, 'images');
            }
        }
        // The product is live, and the proposal has just been written onto it.
        // If that made it unpublishable — a required field emptied, the last
        // picture removed — say so rather than leaving a broken product on the
        // site; the revision stays pending so the manager can refuse it.
        $updated = $this->products->find($product->id);
        if ($updated !== null) {
            $verdict = $this->readiness->check($updated);
            if (!$verdict->ok) {
                $failed = $this->restoreProduct($product);
                if ($failed !== []) {
                    // «نسخه قبول نشد» is true and no longer the whole truth:
                    // part of the proposal is still on the product.
                    return OperationResult::failure('revision_not_restored', [
                        'product_id' => $product->id,
                        'revision_id' => $revisionId,
                        'reason' => $verdict->code,
                        'restore_failed' => implode(',', $failed),
                    ]);
                }
                return $verdict;
            }
        }
        // The proposal is now the product, so the storefront copy has to be
        // the proposal too — and whether it got there is READ, not assumed.
        if ($product->status === ProductStatus::Published) {
            $sync = $this->catalog->publish($product->id);
            if (!self::synced($sync)) {
                // Everything this method wrote goes back. The revision stays
                // pending, which is the only state from which the manager can
                // try again, and the product on the site is the one the
                // shopper was already looking at.
                //
                // And whether it went back is REPORTED. A restore is three
                // writes on a database that has just refused one of them, so
                // «به حالت قبل برگشت» is a claim, not a certainty — and a
                // message that makes it when it is false sends the manager away
                // from the one product they need to look at.
                $failed = $this->restoreProduct($product);
                return OperationResult::failure('sync_failed', [
                    'product_id' => $product->id,
                    'revision_id' => $revisionId,
                    'reason' => $sync->code,
                    'restored' => $failed === [] ? 'yes' : 'no',
                    'restore_failed' => implode(',', $failed),
                ]);
            }
            // The agreement moves with the product. Without this the NEXT
            // revision is measured against the values of two agreements ago,
            // and a change back to an earlier value reads as no change at all.
            if ($sync->ok && !$this->settleBaseline($product->id)) {
                return OperationResult::failure('baseline_not_recorded', [
                    'product_id' => $product->id,
                    'revision_id' => $revisionId,
                    'applied' => 'yes',
                ]);
            }
        }
        $reviewer = $this->capabilities->currentUserId();
        // Reported, like every other write a decision hangs on: a revision
        // that stays pending while the product already carries it would be
        // approved again, and «تأیید شد» would be the only thing that was not
        // true.
        if (!$this->revisions->decide($revisionId, ProductRevision::APPROVED, $reviewer, '')) {
            return OperationResult::failure('storage_failed', [
                'product_id' => $product->id,
                'revision_id' => $revisionId,
                'applied' => 'yes',
            ]);
        }
        $this->audit->log(AuditEventCatalog::PRODUCT_REVISION_REVIEWED, $reviewer, 'product', (string) $product->id, [
            'vendor_id' => $product->vendorUserId,
            'product_id' => $product->id,
            'revision_id' => $revisionId,
            'decision' => ProductRevision::APPROVED,
            'has_note' => false,
        ]);
        return OperationResult::success('revision_approved', ['product_id' => $product->id]);
    }

    /** Refusing a change leaves the published product exactly as it is. */
    public function rejectRevision(int $revisionId, string $note): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        if (trim($note) === '') {
            return OperationResult::failure('note_required');
        }
        $revision = $this->revisions->find($revisionId);
        if ($revision === null) {
            return OperationResult::failure('not_found');
        }
        if (!$revision->isPending()) {
            return OperationResult::failure('already_decided');
        }
        $reviewer = $this->capabilities->currentUserId();
        if (!$this->revisions->decide($revisionId, ProductRevision::REJECTED, $reviewer, $note)) {
            return OperationResult::failure('storage_failed');
        }
        $this->audit->log(AuditEventCatalog::PRODUCT_REVISION_REVIEWED, $reviewer, 'product', (string) $revision->productId, [
            'vendor_id' => $revision->vendorUserId,
            'product_id' => $revision->productId,
            'revision_id' => $revisionId,
            'decision' => ProductRevision::REJECTED,
            'has_note' => true,
        ]);
        return OperationResult::success('revision_rejected', ['product_id' => $revision->productId]);
    }

    /**
     * The product's SEO — the manager's alone (Master Spec §6: «SEO فقط مدیر»).
     *
     * The vendor's form never renders these fields and the vendor's save path
     * never carries them, so this is the only way they can change. Saving
     * re-projects immediately, because a slug that is not on the storefront
     * is not a slug.
     */
    public function setSeo(int $productId, string $slug, string $title, string $description): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        $seo = new ProductSeo(
            ProductSeo::normaliseSlug($slug),
            trim($title),
            trim($description)
        );
        if (!$this->products->updateSeo($productId, $seo)) {
            return OperationResult::failure('storage_failed');
        }
        if ($product->status === ProductStatus::Published) {
            $sync = $this->catalog->publish($productId);
            if (!self::synced($sync)) {
                // The values are saved — that part is real, and the message
                // says so. What did not happen is the shop showing them, and
                // «ذخیره شد» on its own would have left the owner looking for
                // a title that is in the database and nowhere else.
                return OperationResult::failure('sync_failed', [
                    'product_id' => $productId,
                    'reason' => $sync->code,
                    'applied' => 'yes',
                ]);
            }
        }
        // AFTER the projection, and as its own call: projecting will not move
        // an address somebody else chose, which is right for a vendor's save
        // and wrong for the manager typing one here. Their decision is
        // applied explicitly, once.
        if ($seo->slug !== '' && !$this->catalog->applySlug($productId, $seo->slug)) {
            // A product with no storefront post has no address to move yet,
            // and the next projection will write the one just saved. So a
            // refusal is only a failure when there was something to write to.
            if ($this->products->find($productId)?->isProjected() ?? false) {
                return OperationResult::failure('sync_failed', [
                    'product_id' => $productId,
                    'reason' => 'slug_not_applied',
                    'applied' => 'yes',
                ]);
            }
        }
        $this->audit->log(
            AuditEventCatalog::PRODUCT_SEO_CHANGED,
            $this->capabilities->currentUserId(),
            'product',
            (string) $productId,
            ['product_id' => $productId, 'has_slug' => $seo->slug !== '', 'has_title' => $seo->title !== '']
        );
        return OperationResult::success('seo_saved', ['product_id' => $productId]);
    }

    /**
     * The manager's own correction of a product — the record AND the shop.
     *
     * The owner's constraint is the whole design here: «راه‌حل نباید به دو
     * نسخهٔ ناسازگار از اطلاعات محصول منجر شود». So this writes the
     * marketplace row first and then re-projects, which re-stamps the fields
     * as ours. One value, in two places that agree, rather than a correction
     * that lives only in WooCommerce until the next save erases it.
     *
     * Price and stock are deliberately NOT here. They are the vendor's
     * commercial terms and WooCommerce's live inventory (ADR-008); a manager
     * editing either from a review screen would be changing what somebody
     * else is accountable for, silently.
     *
     * @param array<string,string> $fields title, short_description, category
     */
    public function correct(int $productId, array $fields): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        $changes = [];
        foreach (['title' => 'title', 'short_description' => 'shortDescription', 'category' => 'categoryKey'] as $key => $property) {
            if (!array_key_exists($key, $fields)) {
                continue;
            }
            $value = trim($fields[$key]);
            if ($value !== (string) $product->details->{$property}) {
                $changes[$property] = $value;
            }
        }
        if ($changes === []) {
            return OperationResult::success('nothing_changed', ['product_id' => $productId]);
        }
        if (($changes['title'] ?? $product->details->title) === '') {
            return OperationResult::failure('title_required');
        }
        if (!$this->products->updateDetails($productId, $product->details->with($changes), $product->rowVersion)) {
            // The vendor saved while this form was open. Refused, not merged:
            // merging would mean guessing which title is the right one.
            return OperationResult::failure('stale_revision');
        }
        // Re-projected so the shop carries the correction and the stamps say
        // the marketplace wrote it — otherwise the manager's own edit would
        // look, on the next run, like somebody else's.
        if ($product->isProjected()) {
            $this->catalog->publish($productId);
        }
        $this->decisions?->record(
            $productId,
            $product->vendorUserId,
            (int) $this->capabilities->currentUserId(),
            ProductDecision::CORRECTED,
            implode(', ', array_keys($changes))
        );
        $this->audit->log(
            AuditEventCatalog::PRODUCT_CORRECTED,
            $this->capabilities->currentUserId(),
            'product',
            (string) $productId,
            [
                'vendor_id' => $product->vendorUserId,
                'product_id' => $productId,
                'fields' => implode(',', array_keys($changes)),
            ]
        );
        return OperationResult::success('product_corrected', ['product_id' => $productId]);
    }

    /**
     * Give a product waiting for review a storefront row, as a draft.
     *
     * This is what makes «ویرایش در ووکامرس» and the SEO box reachable before
     * approval. It cannot publish anything: `SyncCatalog::prepare()` checks
     * the resulting status and undoes itself if it is ever `publish`.
     */
    public function prepareStorefront(int $productId): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        return $this->catalog->prepare($productId);
    }

    /**
     * End a disagreement about one field, one way or the other.
     *
     * `$decision` is `keep` (the manager's WooCommerce text stays) or
     * `accept` (the vendor's held value is written). Both end with one value
     * rather than two: `keep` copies the storefront value back into the
     * marketplace row for every field that can round-trip, and says so for
     * the one that cannot.
     */
    public function resolveField(int $productId, string $field, string $decision): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        if ($this->storefront === null) {
            return OperationResult::failure('woocommerce_missing');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        if ($decision === 'accept') {
            // The code is passed through rather than flattened to
            // «ذخیره نشد». «عنوان نمی‌تواند خالی بماند» tells the manager what
            // to do next; a generic failure tells them to press the button
            // again, which will refuse again.
            $failure = $this->storefront->acceptProposal($product, $field);
            if ($failure !== null) {
                return OperationResult::failure($failure, ['product_id' => $productId, 'field' => $field]);
            }
            if (!$this->settleField($productId, $field)) {
                return OperationResult::failure('baseline_not_recorded', [
                    'product_id' => $productId,
                    'field' => $field,
                    'applied' => 'yes',
                ]);
            }
            $this->decisions?->record(
                $productId,
                $product->vendorUserId,
                (int) $this->capabilities->currentUserId(),
                ProductDecision::FIELD_ACCEPTED,
                $field
            );
            $this->logOwnership($product->vendorUserId, $productId, $field, 'accept');
            return OperationResult::success('proposal_accepted', ['product_id' => $productId]);
        }
        if ($decision !== 'keep') {
            return OperationResult::failure('unknown_decision');
        }
        $value = $this->storefront->keepStorefront($product, $field);
        if ($value === null) {
            return OperationResult::failure('storage_failed');
        }
        // Copy it home, so the vendor's record and the shop say the same
        // thing. `description` is the exception the constant names: the
        // projector builds it, so there is nothing to copy it into.
        $property = match ($field) {
            'title' => 'title',
            'short_description' => 'shortDescription',
            'category' => 'categoryKey',
            default => '',
        };
        if ($property !== '') {
            // Reported, not ignored. The whole promise of «نسخهٔ ووکامرس
            // بماند» is that the record ends up agreeing with the shop, and a
            // write that lost a version race leaves them disagreeing — with a
            // success message on screen saying they do not.
            if (!$this->products->updateDetails(
                $productId,
                $product->details->with([$property => self::firstId($field, $value)]),
                $product->rowVersion
            )) {
                return OperationResult::failure('stale_revision', ['product_id' => $productId]);
            }
        }
        if ($field === 'images') {
            // Decoded rather than split on commas: which picture is featured
            // and what order the gallery is in are both carried in the value,
            // and both are exactly what the manager pressed this button to
            // keep. `ids()` puts the featured one first because WooCommerce
            // does not record where in the vendor's list it sat — the only
            // place that information could come from.
            $images = StorefrontImages::decode($value);
            $this->products->saveImages($productId, $images->ids(), $images->main);
        }
        if (!$this->settleField($productId, $field)) {
            return OperationResult::failure('baseline_not_recorded', [
                'product_id' => $productId,
                'field' => $field,
                'applied' => 'yes',
            ]);
        }
        $this->decisions?->record(
            $productId,
            $product->vendorUserId,
            (int) $this->capabilities->currentUserId(),
            ProductDecision::FIELD_KEPT,
            $field
        );
        $this->logOwnership($product->vendorUserId, $productId, $field, 'keep');
        return OperationResult::success('storefront_kept', ['product_id' => $productId]);
    }

    /**
     * Settle every field of one product at once, the same way.
     *
     * The per-field buttons are the careful path and stay the default. This
     * is the one a manager needs when a shop carries products from an older
     * version: five fields × however many products is not a decision, it is a
     * chore, and a chore is what gets clicked through without reading.
     *
     * It resolves only fields that are actually waiting — a field the
     * marketplace already owns is left exactly as it is, so pressing this
     * cannot take a working product away from the vendor.
     *
     * @return OperationResult context carries how many fields were settled
     */
    public function resolveProduct(int $productId, string $decision): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        if ($this->storefront === null) {
            return OperationResult::failure('woocommerce_missing');
        }
        if (!in_array($decision, ['keep', 'accept'], true)) {
            return OperationResult::failure('unknown_decision');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        $settled = 0;
        $failed = 0;
        foreach ($this->storefront->compare($product) as $field) {
            if (!$field->needsDecision()) {
                continue;
            }
            // Re-read between fields: `keep` writes the product record, so
            // the row version the next field would carry is already stale.
            $this->resolveField($productId, $field->key, $decision)->ok ? $settled++ : $failed++;
        }
        if ($settled === 0 && $failed === 0) {
            return OperationResult::success('nothing_unsettled', ['product_id' => $productId]);
        }
        if ($failed > 0) {
            return OperationResult::failure('storage_failed', ['settled' => $settled, 'failed' => $failed]);
        }
        return OperationResult::success(
            $decision === 'keep' ? 'storefront_kept_all' : 'proposal_accepted_all',
            ['product_id' => $productId, 'settled' => $settled]
        );
    }

    /**
     * Bring the record into line with the shop, and record that as the base.
     *
     * Three steps, in this order, and each one is the reason for the next:
     *
     *  1. read what WooCommerce ACTUALLY kept (it filters values on the way
     *     in, and the projector may legitimately have written nothing for a
     *     field whose owner is the manager);
     *  2. copy the round-trip fields home, so there are not two versions of
     *     one product — this is what makes «ووکامرس مرجع اطلاعات نهایی
     *     تأییدشده» a fact rather than an intention;
     *  3. record the whole set as the baseline, so the vendor's NEXT edit can
     *     be told apart from the manager's.
     *
     * `description` is copied into the baseline but never into the record:
     * the projector builds it, so writing it home would paste the rendered
     * text into the raw field and the next projection would render it again.
     *
     * **Returns false when any part of that failed, and the order matters.**
     * The baseline is the shop's values; if copying them home did not stick,
     * recording them as agreed would say «the vendor asked for the old value»
     * on the next save and write it back over the shop. So a failed copy stops
     * the baseline from being written at all — and no baseline is a state the
     * code already knows how to be safe in (`alpha.28`'s rule, one question
     * per field), while a wrong baseline is not.
     *
     * @return bool false when the record or the baseline was not written
     */
    private function settleBaseline(int $productId): bool
    {
        if ($this->storefront === null) {
            // No WooCommerce at all: there is no second side to agree with,
            // and `publish()` has already said so in its own words.
            return true;
        }
        $product = $this->products->find($productId);
        if ($product === null || !$product->isProjected()) {
            // The sync reported success, so a missing link here is a fault
            // rather than a normal state.
            return false;
        }
        $values = $this->storefront->storefrontValues($product);
        if ($values === []) {
            return false;   // projected, and yet no storefront row to read
        }
        $roundTrip = $this->storefront->reconcile($product);
        // A field whose proposal is still waiting is not part of the
        // agreement, and it is not copied home either. Measured, not reasoned:
        // `alpha.30`'s own evidence run found what happens without this. The
        // projection HELD the vendor's title because the manager had edited it,
        // the reconciliation then wrote the manager's title into the record —
        // and from that moment the record and the baseline agreed, so the
        // verdict became `skip`, the review screen asked nothing, and the
        // vendor's proposal sat in the meta table where nobody would ever see
        // it again. Recording the shop's value as the agreed one is worse
        // still: it erases the evidence that the manager moved the field, and
        // the NEXT projection writes the vendor's value straight over it.
        //
        // So for a disputed field the record keeps what the vendor asked for,
        // the agreement keeps whatever it already said, and the question stays
        // on the screen until somebody answers it.
        foreach ($this->storefront->compare($product) as $row) {
            if (!$row->hasPending) {
                continue;
            }
            unset($roundTrip[$row->key]);
            if ($product->baseline !== null && $product->baseline->has($row->key)) {
                $values[$row->key] = $product->baseline->get($row->key);
            } else {
                unset($values[$row->key]);
            }
        }
        $changes = [];
        foreach (['title' => 'title', 'short_description' => 'shortDescription', 'category' => 'categoryKey'] as $key => $property) {
            if (!array_key_exists($key, $roundTrip)) {
                continue;
            }
            $value = self::firstId($key, $roundTrip[$key]);
            // The title is the one field that cannot legitimately come back
            // empty, and a shop row with no name would blank the record.
            if ($value === '' && !StorefrontField::mayBeEmpty($key)) {
                continue;
            }
            if ($value !== (string) $product->details->{$property}) {
                $changes[$property] = $value;
            }
        }
        if ($changes !== []
            && !$this->products->updateDetails($productId, $product->details->with($changes), ProductRowVersion::UNGUARDED)) {
            return false;
        }
        if (array_key_exists('images', $roundTrip)) {
            $images = StorefrontImages::decode($roundTrip['images']);
            if (!$this->products->saveImages($productId, $images->ids(), $images->main)) {
                return false;
            }
        }
        return $this->products->saveBaseline($productId, ApprovedBaseline::of($values));
    }

    /**
     * Did the storefront actually take it?
     *
     * `woocommerce_missing` is the one refusal that leaves nothing out of
     * step: there is no shop, the product already answers `isProjected()` with
     * false, and the marketplace decision stands on its own — which is a rule
     * this codebase has had since the catalog existed. Every other code means
     * the shop was there and the write did not happen.
     */
    private static function synced(OperationResult $result): bool
    {
        return $result->ok || $result->code === 'woocommerce_missing';
    }

    /**
     * Put back everything an approved revision wrote — and say what would not
     * go back.
     *
     * Three writes, on a database that is being asked to undo something
     * precisely because a write has just failed. Returning `void` made the
     * caller's «محصول به حالت قبل برگشت» a sentence nobody had checked.
     *
     * @return list<string> the parts still holding the proposal's values
     */
    private function restoreProduct(Product $product): array
    {
        $failed = [];
        if (!$this->products->updateDetails($product->id, $product->details, ProductRowVersion::UNGUARDED)) {
            $failed[] = 'details';
        }
        if (!$this->products->saveSpecs($product->id, $product->specs, $product->specSchemaVersion)) {
            $failed[] = 'specs';
        }
        if (!$this->products->saveImages($product->id, $product->imageIds, $product->mainImageId)) {
            $failed[] = 'images';
        }
        return $failed;
    }

    /**
     * One of the revision's own writes did not happen.
     *
     * Before the projection and before the decision row, both deliberately:
     * a product that is only half the proposal must not reach the shop, and a
     * revision nobody applied must not read as approved.
     */
    private function revisionWriteFailed(Product $product, int $revisionId, string $part): OperationResult
    {
        $failed = $this->restoreProduct($product);
        return OperationResult::failure('revision_write_failed', [
            'product_id' => $product->id,
            'revision_id' => $revisionId,
            'part' => $part,
            'restored' => $failed === [] ? 'yes' : 'no',
            'restore_failed' => implode(',', $failed),
        ]);
    }

    /**
     * One field settled, so the baseline for that field settles with it.
     *
     * Without this, a manager who answers a question would be asked it again
     * on the next save: the decision changes the shop and the stamp, but the
     * baseline would still hold the value from before the argument.
     *
     * @return bool false when the baseline was not written, so the caller can
     *         say that the decision took effect and the question will return
     */
    private function settleField(int $productId, string $field): bool
    {
        if ($this->storefront === null) {
            return true;
        }
        $product = $this->products->find($productId);
        if ($product === null || !$product->isProjected()) {
            return false;
        }
        $values = $this->storefront->storefrontValues($product);
        if (!array_key_exists($field, $values)) {
            return false;
        }
        $baseline = $product->baseline ?? ApprovedBaseline::of([]);
        return $this->products->saveBaseline($productId, $baseline->with($field, $values[$field]));
    }

    /** The category round-trips as ONE term id, not as the id list WooCommerce keeps. */
    private static function firstId(string $field, string $value): string
    {
        if ($field !== 'category') {
            return $value;
        }
        $parts = array_values(array_filter(array_map('trim', explode(',', $value)), static fn (string $v): bool => $v !== '' && $v !== '0'));
        return $parts[0] ?? '';
    }

    private function logOwnership(int $vendorUserId, int $productId, string $field, string $decision): void
    {
        $this->audit->log(
            AuditEventCatalog::PRODUCT_FIELD_OWNERSHIP,
            $this->capabilities->currentUserId(),
            'product',
            (string) $productId,
            [
                'vendor_id' => $vendorUserId,
                'product_id' => $productId,
                'field' => $field,
                'decision' => $decision,
            ]
        );
    }

    /** The second permission of §4.1, granted and revoked on its own. */
    public function setDirectPublishing(int $vendorUserId, bool $granted): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        $ok = $granted ? $this->publishing->grant($vendorUserId) : $this->publishing->revoke($vendorUserId);
        if (!$ok) {
            return OperationResult::failure('storage_failed');
        }
        $this->audit->log(
            AuditEventCatalog::PRODUCT_PUBLISH_PERMISSION_CHANGED,
            $this->capabilities->currentUserId(),
            'vendor',
            (string) $vendorUserId,
            ['vendor_id' => $vendorUserId, 'granted' => $granted]
        );
        return OperationResult::success($granted ? 'direct_publish_granted' : 'direct_publish_revoked');
    }

    /** @param array<string,string> $seenFingerprints */
    private function decide(int $productId, ProductStatus $to, string $note, array $seenFingerprints = []): OperationResult
    {
        if (!$this->capabilities->can(Capabilities::REVIEW_PRODUCTS)) {
            return OperationResult::failure('forbidden');
        }
        $product = $this->products->find($productId);
        if ($product === null) {
            return OperationResult::failure('not_found');
        }
        // Refused, not merged. The manager pressing again sees the new values
        // first — which is the whole point of naming the fields that moved.
        if ($to === ProductStatus::Published && $this->storefront !== null) {
            $moved = $this->storefront->changedSince($product, $seenFingerprints);
            if ($moved !== []) {
                return OperationResult::failure('storefront_moved', [
                    'product_id' => $productId,
                    'fields' => implode(',', $moved),
                ]);
            }
        }
        if (!$this->states->canTransition($product->status, $to)) {
            return OperationResult::failure('invalid_transition', [
                'from' => $product->status->value,
                'to' => $to->value,
            ]);
        }
        if ($to === ProductStatus::Published) {
            // The manager's approval is not a way around the marketplace's own
            // rules: a product with no picture or an empty required medical
            // field is refused here exactly as the vendor's submit refuses it.
            $verdict = $this->readiness->check($product);
            if (!$verdict->ok) {
                return $verdict;
            }
        }
        if (!$this->products->updateStatus($productId, $to, $note)) {
            return OperationResult::failure('storage_failed');
        }
        // The storefront follows the decision immediately: a product the
        // manager just approved has to be buyable, and one they suspended has
        // to stop being buyable in the same request (ADR-008).
        //
        // And its answer is read. `alpha.29` made this call and dropped the
        // result: a projection that refused left the record saying «منتشر شد»
        // with nothing of the kind on the shop, the manager was told the
        // review had gone through, and the baseline recorded an agreement
        // about values nobody had agreed to.
        $sync = $to === ProductStatus::Published
            ? $this->catalog->publish($productId)
            : $this->catalog->withdraw($productId, $note);
        if (!self::synced($sync)) {
            // The status goes back where it was. Two reasons, and either alone
            // would be enough: a record that says published while the shop
            // holds nothing is the lie this whole round is about, and
            // `published → published` is not a transition — so a product left
            // Published here could never be approved again.
            $restored = $this->products->updateStatus($productId, $product->status, $product->reviewNote);
            return OperationResult::failure('sync_failed', [
                'product_id' => $productId,
                'to' => $to->value,
                'reason' => $sync->code,
                'restored' => $restored ? 'yes' : 'no',
                'restore_failed' => $restored ? '' : 'status',
            ]);
        }
        $reviewer = $this->capabilities->currentUserId();
        // Logged here, before the two writes below: the decision itself has
        // happened and the shop has followed it, and that is true whatever the
        // agreement record does next.
        $this->audit->log(AuditEventCatalog::PRODUCT_REVIEWED, $reviewer, 'product', (string) $productId, [
            'vendor_id' => $product->vendorUserId,
            'product_id' => $productId,
            'decision' => $to->value,
            'has_note' => trim($note) !== '',
        ]);
        // One action, one reconciliation: what the shop actually kept is
        // written home and recorded as the baseline. From here the record and
        // the shop say the same thing, so the vendor's form shows the approved
        // values rather than a stale copy of their own draft — and the NEXT
        // edit can be measured against something.
        // `$sync->ok`, not `synced()`: with no WooCommerce at all nothing was
        // written, so there is no second side to have agreed with — and
        // recording an agreement about a shop that does not exist is the
        // invented baseline this whole column was designed to avoid.
        if ($to === ProductStatus::Published && $sync->ok && !$this->settleBaseline($productId)) {
            return OperationResult::failure('baseline_not_recorded', [
                'product_id' => $productId,
                'to' => $to->value,
                'applied' => 'yes',
            ]);
        }
        if ($this->decisions !== null
            && !$this->decisions->record($productId, $product->vendorUserId, (int) $reviewer, $to->value, $note)) {
            // The whole point of the trail is that the vendor reads the
            // sentence the manager wrote. A status chip with no message is
            // exactly the complaint this table was built for, so a row that
            // did not get written is said out loud rather than counted as a
            // clean review.
            return OperationResult::failure('decision_not_recorded', [
                'product_id' => $productId,
                'to' => $to->value,
                'applied' => 'yes',
            ]);
        }
        return OperationResult::success('product_reviewed', ['product_id' => $productId, 'to' => $to->value]);
    }

    /**
     * A payload field that is absent keeps the product's current value, so an
     * older revision written by an older build can still be approved without
     * blanking a column that did not exist when it was proposed.
     *
     * @param array<string,mixed> $payload
     */
    private function detailsFromPayload(array $payload, ProductDetails $current): ProductDetails
    {
        $d = $payload['details'] ?? [];
        if (!is_array($d)) {
            return $current;
        }
        $str = static fn (string $key, string $fallback): string => isset($d[$key]) ? (string) $d[$key] : $fallback;
        $int = static fn (string $key, int $fallback): int => isset($d[$key]) ? (int) $d[$key] : $fallback;
        $nullableInt = static fn (string $key, ?int $fallback): ?int => array_key_exists($key, $d)
            ? ($d[$key] === null ? null : (int) $d[$key])
            : $fallback;
        $nullableStr = static fn (string $key, ?string $fallback): ?string => array_key_exists($key, $d)
            ? ($d[$key] === null || $d[$key] === '' ? null : (string) $d[$key])
            : $fallback;

        return new ProductDetails(
            $str('title', $current->title),
            $str('type', $current->type),
            $str('categoryKey', $current->categoryKey),
            $str('brand', $current->brand),
            $str('shortDescription', $current->shortDescription),
            $int('priceMinor', $current->priceMinor),
            $nullableInt('salePriceMinor', $current->salePriceMinor),
            $nullableStr('saleFrom', $current->saleFrom),
            $nullableStr('saleTo', $current->saleTo),
            // The immediate fields are taken from the LIVE product, never from
            // the proposal: stock moves with every sale, and writing back the
            // number that was true when the revision was written would undo
            // days of selling the moment a manager clicks approve.
            $current->sku,
            $current->stock,
            $current->minPurchase,
            $current->maxPurchase,
            $int('weightGrams', $current->weightGrams),
            $str('dimensions', $current->dimensions),
            $str('taxClass', $current->taxClass)
        );
    }
}
