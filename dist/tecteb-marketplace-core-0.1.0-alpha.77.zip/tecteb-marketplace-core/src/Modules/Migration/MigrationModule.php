<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Migration;

use Tecteb\Marketplace\Contracts\CapabilityCheckerInterface;
use Tecteb\Marketplace\Contracts\ClockInterface;
use Tecteb\Marketplace\Contracts\ContainerInterface;
use Tecteb\Marketplace\Contracts\DatabaseInterface;
use Tecteb\Marketplace\Contracts\JobRepositoryInterface;
use Tecteb\Marketplace\Contracts\TransactionInterface;
use Tecteb\Marketplace\Contracts\ModuleInterface;
use Tecteb\Marketplace\Contracts\ModuleKind;
use Tecteb\Marketplace\Contracts\ModuleManifest;
use Tecteb\Marketplace\Contracts\OptionStoreInterface;
use Tecteb\Marketplace\Core\Audit\AuditLogger;
use Tecteb\Marketplace\Core\Jobs\JobRunner;
use Tecteb\Marketplace\Modules\Admin\Presentation\AdminExtensions;
use Tecteb\Marketplace\Modules\Migration\Application\CatalogueInventory;
use Tecteb\Marketplace\Modules\Migration\Application\CatalogueReaderInterface;
use Tecteb\Marketplace\Modules\Migration\Application\DokanImportJob;
use Tecteb\Marketplace\Modules\Migration\Application\DokanRecordImportJob;
use Tecteb\Marketplace\Modules\Migration\Application\ImportExistingProducts;
use Tecteb\Marketplace\Modules\Migration\Application\CategoryMap;
use Tecteb\Marketplace\Modules\Migration\Application\DokanReaderInterface;
use Tecteb\Marketplace\Modules\Migration\Application\GrantImportedStaff;
use Tecteb\Marketplace\Modules\Migration\Application\ImportFromDokan;
use Tecteb\Marketplace\Modules\Migration\Application\MigrateMinMax;
use Tecteb\Marketplace\Modules\Migration\Application\MigrationCompleteness;
use Tecteb\Marketplace\Modules\Migration\Application\MigrationCountReport;
use Tecteb\Marketplace\Modules\Migration\Application\MinMaxHandoverRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Application\MinMaxReaderInterface;
use Tecteb\Marketplace\Modules\Migration\Application\ShopQuantityPortInterface;
use Tecteb\Marketplace\Modules\Migration\Application\ReconcileDokanFinance;
use Tecteb\Marketplace\Modules\Migration\Application\StaffRoleMap;
use Tecteb\Marketplace\Modules\Finance\Application\LedgerRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Application\OrderHistoryRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Application\FinanceHandoverRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Application\ShopRecordPreview;
use Tecteb\Marketplace\Modules\Migration\Application\ShopRecordRepositoryInterface;
use Tecteb\Marketplace\Modules\Migration\Application\TransferOwnership;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\DbOrderHistoryRepository;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\DbFinanceHandoverRepository;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\DbMinMaxHandoverRepository;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\DbShopRecordRepository;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\WordPress\WpCatalogueReader;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\WordPress\WpDokanReader;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\WordPress\WpMinMaxReader;
use Tecteb\Marketplace\Modules\Migration\Infrastructure\WordPress\WpShopQuantityPort;
use Tecteb\Marketplace\Modules\Migration\Presentation\Admin\HandoverPage;
use Tecteb\Marketplace\Modules\Migration\Presentation\Admin\MigrationPage;
use Tecteb\Marketplace\Modules\Migration\Presentation\Admin\MinMaxExitPage;
use Tecteb\Marketplace\Modules\Migration\Presentation\Admin\ProductIntakePage;
use Tecteb\Marketplace\Modules\Product\Application\CatalogProjectorInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductRepositoryInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductRevisionRepositoryInterface;
use Tecteb\Marketplace\Modules\Finance\Application\WithdrawalRepositoryInterface;
use Tecteb\Marketplace\Modules\Vendor\Application\StaffRepositoryInterface;
use Tecteb\Marketplace\Modules\Vendor\Application\StaffUserDirectoryInterface;
use Tecteb\Marketplace\Modules\Vendor\Application\VendorRepositoryInterface;

/**
 * Migration from Dokan — read-only until a person presses a button, and
 * undoable after they do.
 *
 * It adds no tables of its own: what a trial import creates is ordinary
 * marketplace rows, and the manifest of each run lives in one option so a
 * rollback knows exactly what to remove. A migration with its own schema
 * would be a second place for the truth to live.
 */
final class MigrationModule implements ModuleInterface
{
    public function manifest(): ModuleManifest
    {
        return new ModuleManifest(
            'migration',
            $this->version(),
            'مهاجرت از دکان',
            ModuleKind::Operational,
            ['core', 'vendor', 'product'],
            false,
            'اجرای آزمایشی و تطبیق سطربه‌سطر داده‌های دکان، ورود برگشت‌پذیر، و هیچ نوشتنی روی دادهٔ دکان'
        );
    }

    public function register(ContainerInterface $c): void
    {
        $c->bind(DokanReaderInterface::class, static fn (ContainerInterface $c) => new WpDokanReader(
            $c->get(DatabaseInterface::class)
        ));
        $c->bind(TransferOwnership::class, static fn (ContainerInterface $c) => new TransferOwnership(
            $c->get(ProductRepositoryInterface::class),
            $c->get(CatalogProjectorInterface::class),
            $c->get(AuditLogger::class),
            $c->get(CapabilityCheckerInterface::class),
            // So a transfer drops the remembered «is this ours» answer. The
            // product module owns the policy; if it is not loaded there is no
            // answer to forget either.
            $c->has(\Tecteb\Marketplace\Modules\Product\Application\PurchasePolicy::class)
                ? $c->get(\Tecteb\Marketplace\Modules\Product\Application\PurchasePolicy::class)
                : null,
            // What accepting this product would overwrite or cannot express.
            // Bound below, so this closure resolves it lazily — and if it is
            // absent the transfer behaves as it did before `alpha.55` and the
            // page says the check did not run.
            $c->has(CatalogueReaderInterface::class) ? $c->get(CatalogueReaderInterface::class) : null,
            // «Does this row still agree with the shop?» and «make it agree».
            // Bound below, resolved lazily here; absent means no drift is
            // reported and the page says the check did not run.
            $c->has(CatalogueReaderInterface::class) ? $c->get(ImportExistingProducts::class) : null
        ));
        $c->bind(OrderHistoryRepositoryInterface::class, static fn (ContainerInterface $c) => new DbOrderHistoryRepository(
            $c->get(DatabaseInterface::class),
            $c->get(ClockInterface::class)
        ));
        $c->bind(ShopRecordRepositoryInterface::class, static fn (ContainerInterface $c) => new DbShopRecordRepository(
            $c->get(DatabaseInterface::class),
            $c->get(ClockInterface::class)
        ));
        $c->bind(ImportFromDokan::class, static fn (ContainerInterface $c) => new ImportFromDokan(
            $c->get(DokanReaderInterface::class),
            $c->get(VendorRepositoryInterface::class),
            $c->get(ProductRepositoryInterface::class),
            $c->get(OptionStoreInterface::class),
            $c->get(AuditLogger::class),
            $c->get(ClockInterface::class),
            $c->get(CapabilityCheckerInterface::class),
            $c->get(OrderHistoryRepositoryInterface::class),
            $c->get(ShopRecordRepositoryInterface::class),
            $c->get(LedgerRepositoryInterface::class),
            $c->get(CategoryMap::class),
            $c->has(\Tecteb\Marketplace\Modules\Product\Application\ProductImageLibraryInterface::class)
                ? $c->get(\Tecteb\Marketplace\Modules\Product\Application\ProductImageLibraryInterface::class)
                : null
        ));
        $c->bind(CategoryMap::class, static fn (ContainerInterface $c) => new CategoryMap(
            $c->get(OptionStoreInterface::class)
        ));
        $c->bind(StaffRoleMap::class, static fn (ContainerInterface $c) => new StaffRoleMap(
            $c->get(OptionStoreInterface::class)
        ));
        $c->bind(GrantImportedStaff::class, static fn (ContainerInterface $c) => new GrantImportedStaff(
            $c->get(ShopRecordRepositoryInterface::class),
            $c->get(StaffRoleMap::class),
            $c->get(StaffRepositoryInterface::class),
            $c->get(StaffUserDirectoryInterface::class),
            $c->get(AuditLogger::class),
            $c->get(CapabilityCheckerInterface::class)
        ));
        $c->bind(FinanceHandoverRepositoryInterface::class, static fn (ContainerInterface $c) => new DbFinanceHandoverRepository(
            $c->get(DatabaseInterface::class),
            $c->get(ClockInterface::class)
        ));
        // The same object the repositories write through, so the lock the
        // decision takes and the writes an import makes are on one connection
        // pair and really do contend.
        $c->bind(TransactionInterface::class, static fn (ContainerInterface $c) => $c->get(DatabaseInterface::class));
        $c->bind(ReconcileDokanFinance::class, static fn (ContainerInterface $c) => new ReconcileDokanFinance(
            $c->get(ShopRecordRepositoryInterface::class),
            $c->get(FinanceHandoverRepositoryInterface::class),
            $c->get(TransactionInterface::class),
            $c->get(AuditLogger::class),
            $c->get(ClockInterface::class),
            $c->get(CapabilityCheckerInterface::class),
            // Read only, and optional: the report says «this marketplace's own
            // engine holds nothing for this shop» and must be able to say it
            // without the finance module loaded.
            $c->has(LedgerRepositoryInterface::class) ? $c->get(LedgerRepositoryInterface::class) : null,
            $c->has(WithdrawalRepositoryInterface::class) ? $c->get(WithdrawalRepositoryInterface::class) : null
        ));
        // What a shop's records look like BEFORE anybody imports them. Read
        // only — it has no write method of any kind — so «اولین گام پس از
        // نصب فقط دیدن پیش‌نمایش سوابق باشد» is a property of the class and
        // not a rule the page has to keep.
        $c->bind(ShopRecordPreview::class, static fn (ContainerInterface $c) => new ShopRecordPreview(
            $c->get(DokanReaderInterface::class),
            // Optional on purpose: an install with nowhere to keep records
            // reports «هنوز بررسی نشده», which is what is true, rather than
            // «صفر سابقه», which is not.
            $c->has(ShopRecordRepositoryInterface::class)
                ? $c->get(ShopRecordRepositoryInterface::class)
                : null
        ));
        // Where each of the migration's numbers comes from. Read only, and
        // nothing on it can change a figure: the job rows it prints are the
        // record of what those jobs did.
        $c->bind(MigrationCountReport::class, static fn (ContainerInterface $c) => new MigrationCountReport(
            $c->get(ImportFromDokan::class),
            $c->get(ProductRepositoryInterface::class),
            $c->get(VendorRepositoryInterface::class),
            // Optional, and `read: false` rather than nought when absent —
            // «نتوانستم بپرسم» is not «کار چیزی اعلام نکرده بود».
            $c->has(JobRepositoryInterface::class) ? $c->get(JobRepositoryInterface::class) : null
        ));
        $c->bind(MigrationCompleteness::class, static fn (ContainerInterface $c) => new MigrationCompleteness(
            $c->get(ShopRecordRepositoryInterface::class),
            $c->get(StaffRoleMap::class),
            $c->get(ReconcileDokanFinance::class),
            $c->get(VendorRepositoryInterface::class),
            $c->get(ProductRepositoryInterface::class),
            $c->get(DokanReaderInterface::class),
            $c->get(CategoryMap::class)
        ));

        // Products this shop already has. The reader has no write method, so
        // «ورود بدون ساخت محصول جدید ووکامرس» is a property of the
        // dependency rather than a rule somebody has to remember.
        $c->bind(CatalogueReaderInterface::class, static fn (ContainerInterface $c) => new WpCatalogueReader(
            $c->get(DatabaseInterface::class),
            // For the author's vendor paperwork. Optional: without it the
            // status reads as unknown, which pushes a product towards
            // «ambiguous» — the safe direction.
            $c->has(VendorRepositoryInterface::class) ? $c->get(VendorRepositoryInterface::class) : null
        ));
        $c->bind(CatalogueInventory::class, static fn (ContainerInterface $c) => new CatalogueInventory(
            $c->get(CatalogueReaderInterface::class)
        ));
        $c->bind(ImportExistingProducts::class, static fn (ContainerInterface $c) => new ImportExistingProducts(
            $c->get(CatalogueReaderInterface::class),
            $c->get(CatalogueInventory::class),
            $c->get(ProductRepositoryInterface::class),
            $c->get(VendorRepositoryInterface::class),
            $c->get(OptionStoreInterface::class),
            $c->get(AuditLogger::class),
            $c->get(ClockInterface::class),
            $c->get(CapabilityCheckerInterface::class),
            // Asked one question: does this product carry an unanswered
            // proposal? Optional so a build without the revision store still
            // constructs — and then nothing is reported as having one, which
            // makes the rollback keep fewer rows, so the absence is stated
            // rather than relied on.
            $c->has(ProductRevisionRepositoryInterface::class)
                ? $c->get(ProductRevisionRepositoryInterface::class)
                : null,
            // The unit of work an intake, a repair and a rollback each are.
            // Optional in the constructor and REFUSED when absent, so a build
            // without one does nothing rather than half of something.
            $c->has(TransactionInterface::class) ? $c->get(TransactionInterface::class) : null
        ));

        // Leaving «Min Max Control». Three pieces, each replaceable on its
        // own: a reader that never writes, a ledger that remembers what the
        // destination held before, and the service that decides. The
        // transaction is the one piece that is NOT optional in practice:
        // `MigrateMinMax` refuses before the first write without it and says
        // so, rather than silently doing the first half (`alpha.49`). The
        // parameter stays nullable so a build without a transaction gets a
        // named refusal on the page instead of a container error on every
        // admin request — the refusal is visible, the error is not.
        $c->bind(MinMaxReaderInterface::class, static fn (ContainerInterface $c) => new WpMinMaxReader(
            $c->get(DatabaseInterface::class)
        ));
        $c->bind(ShopQuantityPortInterface::class, static fn (ContainerInterface $c) => new WpShopQuantityPort(
            $c->get(DatabaseInterface::class)
        ));
        $c->bind(MinMaxHandoverRepositoryInterface::class, static fn (ContainerInterface $c) => new DbMinMaxHandoverRepository(
            $c->get(DatabaseInterface::class)
        ));
        $c->bind(MigrateMinMax::class, static fn (ContainerInterface $c) => new MigrateMinMax(
            $c->get(MinMaxReaderInterface::class),
            $c->get(MinMaxHandoverRepositoryInterface::class),
            $c->get(ShopQuantityPortInterface::class),
            $c->has(TransactionInterface::class) ? $c->get(TransactionInterface::class) : null
        ));
    }

    public function boot(ContainerInterface $c): void
    {
        // Registered on the ONE runner in the container, at module load, so the
        // cron tick later in this same request finds a handler for the type it
        // claims. A runner built at tick time would know nothing.
        $c->get(JobRunner::class)->register(new DokanImportJob($c->get(ImportFromDokan::class)));
        // And the records — staff, balance ledger, withdrawal requests — as a
        // SECOND handler rather than a fourth phase of the first.
        //
        // ⛔ Deliberately separate, because job #1 on the owner's staging has
        // finished («انجام شد») and reopening a finished job to add work to it
        // would destroy the one record of what that import did. They also
        // answer to different decisions: products are a catalogue the manager
        // then reviews, and records are history nobody has to accept. One
        // button each, one job row each, one cursor each.
        $c->get(JobRunner::class)->register(new DokanRecordImportJob($c->get(ImportFromDokan::class)));

        $page = new MigrationPage($c);
        // Importing and handing over are two pages on purpose. The first is
        // reversible bookkeeping; the second is a person deciding who may
        // touch orders and who owes money. On one screen, the second gets
        // clicked through on the way to the first.
        $handover = new HandoverPage($c);
        // And a third, for the other plugin being left behind. On the handover
        // page it would sit under decisions about money and access, which are
        // not the same kind of decision as a purchase-quantity rule.
        $minmax = new MinMaxExitPage($c);
        // There is no fourth. «ورود محصولات موجود» had a menu entry of its
        // own in `alpha.55` and it is gone from `alpha.56`: it listed
        // WooCommerce posts while the review page listed marketplace rows,
        // and a product on both sides appeared on both screens with nothing
        // saying it was one product. Its capability and its old address live
        // on in `ProductIntakePage`, which now only redirects.
        // On `admin_page_access_denied`, and that is a MEASUREMENT rather
        // than a preference. The first version of this hooked `admin_init`,
        // which reads correctly — `wp-admin/admin.php` fires it at line 180
        // and looks the page hook up at 189 — and never ran: line 163 of the
        // same file requires `wp-admin/menu.php` FIRST, and
        // `wp-admin/includes/menu.php:375` ends with
        // `if (!user_can_access_admin_page()) { do_action(
        // 'admin_page_access_denied'); wp_die(…, 403); }`. So a `page=` slug
        // nothing registered is dead before `admin_init` exists, and the old
        // address answered 403 «Sorry, you are not allowed to access this
        // page» — the exact sentence `RetiredIntakeAddressTest` was written
        // to prevent, with that test passing all the while because it calls
        // the redirect directly. Only the upgrade run in a browser found it.
        //
        // `admin_page_access_denied` is WordPress's own hook for this, fired
        // immediately before the refusal; the callback answers for ONE slug
        // and only for somebody who may do intakes, so every other denied
        // page still gets core's refusal.
        add_action('admin_page_access_denied', static function (): void {
            ProductIntakePage::redirectOldAddress('tmc-product-review');
        }, 1);
        add_filter(AdminExtensions::FILTER, static function (array $pages) use ($page, $handover, $minmax): array {
            $pages[] = [
                'slug' => MigrationPage::SLUG,
                'page_title' => MigrationPage::menuLabel(),
                'menu_label' => MigrationPage::menuLabel(),
                'capability' => MigrationPage::CAPABILITY,
                'render' => [$page, 'render'],
            ];
            $pages[] = [
                'slug' => HandoverPage::SLUG,
                'page_title' => HandoverPage::menuLabel(),
                'menu_label' => HandoverPage::menuLabel(),
                'capability' => HandoverPage::CAPABILITY,
                'render' => [$handover, 'render'],
            ];
            $pages[] = [
                'slug' => MinMaxExitPage::SLUG,
                'page_title' => MinMaxExitPage::menuLabel(),
                'menu_label' => MinMaxExitPage::menuLabel(),
                'capability' => MinMaxExitPage::CAPABILITY,
                'render' => [$minmax, 'render'],
            ];
            return $pages;
        });
    }

    private function version(): string
    {
        return class_exists(\Tecteb\Marketplace\Infrastructure\WordPress\Bootstrap::class, false)
            ? \Tecteb\Marketplace\Infrastructure\WordPress\Bootstrap::pluginVersion()
            : '0.0.0';
    }
}
