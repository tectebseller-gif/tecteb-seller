<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Infrastructure\WooCommerce;

use Tecteb\Marketplace\Modules\Product\Application\CatalogProjectorInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductCategoryDirectoryInterface;
use Tecteb\Marketplace\Modules\Product\Domain\ApprovedBaseline;
use Tecteb\Marketplace\Modules\Product\Domain\CategorySet;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\FieldMerge;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\ProductAttribute;
use Tecteb\Marketplace\Modules\Product\Application\SpecTemplateRepositoryInterface;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;
use Tecteb\Marketplace\Modules\Product\Domain\ProjectedStatus;
use Tecteb\Marketplace\Modules\Product\Domain\ProductType;
use Tecteb\Marketplace\Modules\Product\Domain\ShopEditMerge;
use Tecteb\Marketplace\Modules\Product\Domain\ProductVariation;
use Tecteb\Marketplace\Modules\Product\Domain\StorefrontImages;

/**
 * The marketplace product, written into WooCommerce (ADR-008).
 *
 * Three rules govern every line below, and they are the ones the owner asked
 * for by name:
 *
 *  - **no duplicates.** The link is stored on both sides and a projection
 *    updates the linked post or creates exactly one. A post that is not ours
 *    is never adopted, however convincing its title.
 *  - **no restored stock.** On CREATE the stock comes from the marketplace,
 *    because WooCommerce has none yet. On UPDATE stock is not touched at all:
 *    it moved when something sold, and that number is the true one. The only
 *    write is `writeStock()`, which is the vendor's explicit edit.
 *  - **no foreign writes.** Every write is preceded by `owns()`, so a shop
 *    product or a Dokan product is never modified, re-statused or deleted.
 */
final class WooCommerceProjector implements CatalogProjectorInterface
{
    /**
     * The address, stamped like every other projected field — but kept OUT of
     * `ProjectedFieldOwnership::FIELDS` on purpose: the slug is the manager's
     * either way, so it is a write to stop rather than a disagreement to put
     * a button on.
     */
    public const SLUG_FIELD = 'slug';

    /** Whether the run in progress wrote the address; see `applySeo()`. */
    private bool $wroteSlug = false;

    public const PRODUCT_META = '_tmc_product_id';
    public const VENDOR_META = '_tmc_vendor_id';
    /**
     * Set when the last projection LEFT THE SHOP'S PRICE ALONE because this
     * marketplace has none for the product.
     *
     * Its own key rather than a flag inside another record: the question «is
     * this product unsellable because nobody has priced it?» is asked by the
     * review list and by the health page, on requests that are nowhere near
     * the projection that answered it.
     */
    public const PRICE_HELD_META = '_tmc_price_not_projected';

    /**
     * The status a claimed post had before this plugin took it over.
     *
     * Only ever written by claimStorefrontPost(), and only for a post this
     * plugin did not create. It is what makes «انتقال مالکیت عملیاتی»
     * reversible rather than one-way.
     */
    /**
     * A FACT ON DISK: this projection did not write the product's status.
     *
     * The sibling of `PRICE_HELD_META`, and for the same reason it is meta
     * rather than a return value only: the manager's review page and the
     * health page ask it on requests nowhere near the projection that
     * answered it.
     *
     * Set while `Product::storefrontStatusIsHeld()` is true — an intaken
     * product whose storefront status nobody inside this marketplace has
     * decided — and deleted the moment a decision releases it. The catalogue
     * visibility is held under the same key, because «is this product
     * supposed to be seen» is ONE question and giving it two answers is what
     * `alpha.66` warned about two rounds ago.
     */
    public const STATUS_HELD_META = '_tmc_status_not_projected';

    public const CLAIMED_FROM_STATUS_META = '_tmc_claimed_from_status';
    public const VARIATION_META = '_tmc_variation_id';
    /** Marketplace categories live under their own slugs, so no shop term is renamed. */
    public const CATEGORY_SLUG_PREFIX = 'tmc-';

    /**
     * The spec-template repository is back, for the labels and the units.
     *
     * `alpha.41` removed it because the only thing reading it was the
     * description `project()` used to GENERATE from the brand and the medical
     * specification — and «توضیحات کامل» became the vendor's own field, so
     * nothing generated a description any more. Removing the generator was
     * right; letting the specification stop reaching the storefront with it
     * was not. It is a separate block now (`factAttributes()`), and a block
     * needs the labels and units that only the template knows.
     */
    public function __construct(
        private readonly SpecTemplateRepositoryInterface $templates,
        private readonly ?ProductCategoryDirectoryInterface $categories = null
    )
    {
    }

    public function isAvailable(): bool
    {
        return class_exists('WooCommerce') && function_exists('wc_get_product') && class_exists('WC_Product_Simple');
    }

    public function project(Product $product, array $attributes = [], array $variations = []): array
    {
        if (!$this->isAvailable()) {
            return ['ok' => false, 'code' => 'woocommerce_missing', 'wc_product_id' => 0, 'variation_links' => []];
        }
        $linked = $this->linkedProduct($product);
        $isNew = $linked === null;
        $wcProduct = $linked ?? $this->blank($product);
        if ($wcProduct === null) {
            return ['ok' => false, 'code' => 'storage_failed', 'wc_product_id' => 0, 'variation_links' => []];
        }

        $details = $product->details;

        // Text the manager may have edited in WooCommerce. Each one is written
        // only while it is still what we last wrote; otherwise the vendor's
        // value is held as a proposal and the manager decides.
        //
        // `$isNew` travels with every one of them. A post created a moment
        // ago by this call is ours in full; an EXISTING post with no stamp is
        // not, however much it looks the same from here — that is a product
        // an older version projected, and whatever is in it may be the
        // manager's own text.
        $outcome = [];
        $this->writeOwned(
            $wcProduct,
            'title',
            $details->title !== '' ? $details->title : __('بدون عنوان', 'tecteb-marketplace-core'),
            static fn (\WC_Product $p): string => (string) $p->get_name(),
            static fn (\WC_Product $p, string $v): mixed => $p->set_name($v),
            $outcome,
            $isNew,
            $product->baseline
        );
        $this->writeOwned(
            $wcProduct,
            'short_description',
            $details->shortDescription,
            static fn (\WC_Product $p): string => (string) $p->get_short_description(),
            static fn (\WC_Product $p, string $v): mixed => $p->set_short_description($v),
            $outcome,
            $isNew,
            $product->baseline
        );
        // The long description, and ONLY when there is one to write.
        //
        // `null` means this product predates the field (migration 23 adds the
        // column with no backfill), so nobody has asked for anything and
        // WooCommerce's own text is left exactly as it is — along with the
        // manager's edits to it and their SEO. That is «توضیحات کامل موجود در
        // ووکامرس را با متن کوتاه یا متن تولیدی جایگزین نکن», and skipping
        // the field entirely is the only way to honour it: `writeOwned()` with
        // an empty string would EMPTY the storefront text, and with the
        // generated text would put words nobody wrote under the vendor's name.
        //
        // `''` is a vendor's deliberate clear and is written like any value.
        if ($details->description !== null) {
            $this->writeOwned(
                $wcProduct,
                'description',
                $details->description,
                static fn (\WC_Product $p): string => (string) $p->get_description(),
                static fn (\WC_Product $p, string $v): mixed => $p->set_description($v),
                $outcome,
                $isNew,
                $product->baseline
            );
        }
        // THE STATUS, and the one case in which it is NOT written.
        //
        // ⛔ Until `alpha.67` these two lines were unconditional, and that is
        // the §1 finding. `project()` reduced six marketplace states to two
        // storefront ones, so a WooCommerce product taken in as «پیش‌نویس»
        // had `draft` written over whatever it held — measured on
        // `alpha.66`'s installed bytes, walking the owner's own path: a
        // `pending` product survived the intake, survived accepting
        // management and survived an ordinary save, and the FIRST PROJECTION
        // made it `draft` and dropped it out of the catalogue and out of
        // search. Two public changes, neither asked for, on a product whose
        // status this marketplace had never decided.
        //
        // The fix is not a better mapping: `pending` has no marketplace
        // lifecycle state (§4.2 fixes the six) and inventing one would put
        // the product in the review queue with an identity of `s0.r0.b0`. The
        // fix is that a field nobody decided is not ours to write —
        // `alpha.44`'s rule, and `alpha.66`'s shape for an absent price one
        // field over. `mirrored_status` records what the intake SAW, and
        // `updateStatus()` clears it the moment a human in this marketplace
        // decides; from then on the status is written as it always was.
        //
        // The catalogue visibility is held WITH it. It answers the same
        // question — «is this product supposed to be seen» — and giving one
        // question two answers is how `alpha.66` produced a green banner over
        // a shut gate.
        //
        // ⛔ And the two values come from `ProjectedStatus` rather than from a
        // ternary here, because from `alpha.92` the staged transfer REFUSES a
        // row whose projection would change the shop's publish state — and a
        // guard that predicted the write from its own copy of the rule would
        // be right only until somebody edited one of the two
        // (`alpha.78`). One function, two callers, and
        // `ProjectedStatusIsOneRuleTest` pins that this method asks it.
        $statusHeld = $product->storefrontStatusIsHeld();
        if (!$statusHeld) {
            $wcProduct->set_status(ProjectedStatus::statusOf($product->status));
            $wcProduct->set_catalog_visibility(ProjectedStatus::visibilityOf($product->status));
        }
        // THE PRICE, THE SKU AND THE WEIGHT — asked BEFORE any of them is
        // written, which until `alpha.83` nothing did.
        //
        // ⛔ These three were the last unconditional writes in this method,
        // and the only condition any of them had was emptiness. So the
        // sequence the owner described — take a product in, edit it in
        // WooCommerce, let any later projection run — put the marketplace's
        // old copy back over a person's edit: measured on `alpha.82`'s
        // delivered bytes as `field_price_before=480000
        // field_price_after=450000 field_price_overwritten=yes`, and the same
        // for the SKU and the weight, while the three TEXT fields beside them
        // survived because `ProjectedFieldOwnership` has bound ownership to
        // the value we wrote since `alpha.26`.
        //
        // The rule is `ShopEditMerge` and it is NOT this file's business to
        // repeat it. What belongs here is the shop read, the record and the
        // one thing a rule cannot know: `$isNew`, which says every byte of
        // this post was written a moment ago by this call.
        //
        // Read before the writes below and not after, obviously — but also
        // before `applySku()` on the line it replaced, because that call
        // would otherwise be the edit this comparison is looking for.
        $shopFields = ProjectedShopFields::shopValues($wcProduct);
        $wantedFields = [
            ShopEditMerge::PRICE => $details->type !== ProductType::VARIABLE && $details->hasPrice()
                ? (string) $details->priceMinor
                : '',
            ShopEditMerge::SKU => $details->sku,
            // Kilograms, because that is the unit the shop column holds and
            // the comparison has to happen in one unit; `ShopEditMerge`
            // converts both sides to grams, which is the exact inverse of
            // this very expression.
            ShopEditMerge::WEIGHT => $details->weightGrams > 0
                ? (string) round($details->weightGrams / 1000, 3)
                : '',
        ];
        $shopFieldsMerged = ProjectedShopFields::merge(
            $shopFields,
            $wantedFields,
            $isNew ? [] : ProjectedShopFields::record((int) $wcProduct->get_id()),
            $isNew
        );

        if ($shopFieldsMerged['may'][ShopEditMerge::SKU]) {
            $this->applySku($wcProduct, $details->sku);
        }
        $this->applySeo($wcProduct, $product);

        if ($details->weightGrams > 0 && $shopFieldsMerged['may'][ShopEditMerge::WEIGHT]) {
            $wcProduct->set_weight((string) round($details->weightGrams / 1000, 3));
        }
        // Pictures and category follow the same rule as the text: a gallery
        // the manager rearranged in WooCommerce, or a category they moved the
        // product into, is not undone by the vendor's next save.
        $this->writeOwned(
            $wcProduct,
            'images',
            // Main named, gallery in ITS order, nothing sorted: swapping the
            // featured picture or dragging the gallery about are the two
            // edits a manager actually makes, and the sorted form made both
            // of them invisible.
            ProjectedFieldOwnership::imagesToValue($product->mainImageId, $product->imageIds),
            static fn (\WC_Product $p): string => ProjectedFieldOwnership::imagesToValue(
                (int) $p->get_image_id(),
                $p->get_gallery_image_ids()
            ),
            static function (\WC_Product $p) use ($product): void {
                // Built from the same value object the comparison above is
                // built from, so «what we want» and «what we write» cannot
                // drift apart the way they did when one of them filtered the
                // list by hand.
                $images = StorefrontImages::of($product->mainImageId, $product->imageIds);
                // UNCONDITIONAL, and that is the whole of this fix. The line
                // this replaces was `if ($product->mainImageId > 0)`, so zero
                // never reached WooCommerce: a vendor who removed the
                // featured picture kept it on the shop for ever, and it was
                // the one change the marketplace owned and could not make.
                // Zero is a value here — `main:0` — not a missing one.
                $p->set_image_id($images->main);
                // The gallery is written as it stands. Nothing is promoted
                // into an emptied featured slot: WooCommerce draws its
                // placeholder, which is what «بدون تصویر اصلی» looks like,
                // and quietly publishing the next picture instead would be
                // this plugin choosing somebody's main photo for them.
                $p->set_gallery_image_ids($images->gallery);
            },
            $outcome,
            $isNew,
            $product->baseline
        );
        $wantCategories = $this->categoryIds(
            $details,
            array_map('intval', $wcProduct->get_category_ids()),
            $product->imported
        );
        $this->writeOwned(
            $wcProduct,
            'category',
            ProjectedFieldOwnership::idsToValue($wantCategories),
            static fn (\WC_Product $p): string => ProjectedFieldOwnership::idsToValue(
                array_map('intval', $p->get_category_ids())
            ),
            static fn (\WC_Product $p): mixed => $p->set_category_ids($wantCategories),
            $outcome,
            $isNew,
            $product->baseline
        );

        // The brand and the medical specification, as a block of their own.
        //
        // Until `alpha.40` they were rendered INTO the description, which is
        // why removing the generator in `alpha.41` took them off the product
        // page altogether. They are structured data and they belong in
        // WooCommerce's own «اطلاعات بیشتر» table, where every theme that
        // renders WooCommerce's tabs already shows them and the vendor's own
        // text is left alone — «آن‌ها را به‌صورت اجباری به متن فروشنده
        // نچسبان».
        //
        // MERGED, never `set_attributes()` over the top: that call replaces
        // the whole set, so an attribute a manager added by hand to one of
        // our products would be deleted by the next projection. Only the keys
        // THIS plugin owns are rewritten, and a retired specification
        // disappears because its key is no longer among them.
        //
        // `alpha.42` recognised its own attributes by a `tmc-` key prefix and
        // could not: `set_attributes()` files every attribute under
        // `sanitize_title($attribute->get_name())` and discards the keys it
        // was given, so the prefix was gone before the call returned. The
        // record is `ProjectedAttributes::OWNED_META` now, and the SAME
        // record answers both questions the owner asked — which attributes
        // this plugin may rewrite or drop, and which belong to a manager and
        // are never touched — for a simple product and a variable one alike.
        $ours = $details->type === ProductType::VARIABLE
            // A variation attribute and a fact under one name is one
            // attribute, and the variation attribute wins: it is the one the
            // shop needs in order to build variations at all. Both are ours
            // either way, so this is an internal precedence, not a conflict.
            ? $this->wcAttributes($attributes) + $this->factAttributes($product)
            : $this->factAttributes($product);
        $merged = ProjectedAttributes::merge(
            $wcProduct->get_attributes(),
            $ours,
            ProjectedAttributes::normalise(
                $this->storedAttributeRecord((int) $wcProduct->get_id())
            )
        );
        $wcProduct->set_attributes($merged['attributes']);

        // THE PURCHASE-QUANTITY RULE, on the shop's own product.
        //
        // Until `alpha.45` nothing wrote this anywhere: `min_purchase` and
        // `max_purchase` were stored, formed, validated and exported, and no
        // projection, filter or check ever read them. Measured on `alpha.44`
        // with real WooCommerce — `row_min=2 row_max=10` and every candidate
        // meta key on the shop product `__absent__`.
        //
        // Staged through `update_meta_data()` rather than `update_post_meta()`
        // so it rides the ONE save below: a new product has no post id yet,
        // and two writes where one would do is a second thing that can half
        // happen.
        $quantityMerged = self::mergeQuantities($wcProduct, $product);
        foreach ($quantityMerged['values'] as $metaKey => $metaValue) {
            $wcProduct->update_meta_data($metaKey, $metaValue);
        }

        // THE PRICE IS WRITTEN ONLY WHEN THERE IS ONE.
        //
        // ⛔ Until `alpha.66` this call was unconditional, and
        // `ProductDetails::missingFields()` has named `price` for `<= 0`
        // since the four-step form existed — so the model already said nought
        // is «قیمتی ثبت نشده» and the projector wrote it to the shop as a
        // price anyway. Measured on the installed `alpha.65` bytes with the
        // intake of an existing product: a PUBLISHED WooCommerce product with
        // no `_regular_price` row at all came out of one projection with
        // `_regular_price = '0'`, `_price = '0'` and a price of «۰ تومان»
        // where there had been nothing. An intake must not change the public
        // product (§1-ج) and must not write a value nobody recorded (§1-ب).
        //
        // Held rather than written, the `writeOwned()` shape one property
        // down: WooCommerce keeps whatever it has, the field is reported, and
        // the product stays unapprovable until somebody sets a price —
        // `ProductReadiness` already refuses it by name.
        $priceHeld = false;
        if ($details->type !== ProductType::VARIABLE) {
            if ($details->hasPrice()) {
                // And only while the shop still holds what we last wrote.
                // `$priceHeld` is deliberately NOT set when the merge refuses:
                // that flag means «the marketplace has no price», the review
                // list and the health page read it as exactly that, and
                // overloading it with «somebody edited the shop's» would make
                // both of those pages say something untrue. The refusal has
                // its own report, with both numbers on it.
                if ($shopFieldsMerged['may'][ShopEditMerge::PRICE]) {
                    $wcProduct->set_regular_price((string) $details->priceMinor);
                    // `false`: a projection mirrors a row that may be months
                    // old, so it may not REMOVE a sale price it never
                    // recorded. `writePrice()` passes `true`, because there
                    // the vendor typed the change one statement earlier.
                    $this->applySale($wcProduct, $product, false);
                }
            } else {
                // The sale price is held with it: a sale off a price that does
                // not exist is a second invented number.
                $priceHeld = true;
            }
            // NOTHING ABOUT STOCK IS WRITTEN TO A PRODUCT WE DID NOT CREATE.
            //
            // ⛔ `set_manage_stock(true)` was the last unconditional write in
            // this method, and `$isNew` guarded only the NUMBER beside it. So
            // on a product taken in from the shop — every one of shop 102's
            // 184 — the first projection after a transfer switched stock
            // management ON and wrote no quantity, and a managed product with
            // no `_stock` row is a product WooCommerce can report as out of
            // stock. `alpha.93` measured that and could only disclose it;
            // this is the write itself going away.
            //
            // The rule it now follows is the one ADR-008 already states:
            // «موجودی پس از اولین projection مال ووکامرس» — stock belongs to
            // WooCommerce after the first projection. Re-forcing the flag on
            // contradicted that for a product whose manager had deliberately
            // switched it off, and for an intaken product it invented a
            // setting nobody chose (`alpha.44`'s rule: a value we never wrote
            // is not ours).
            //
            // The VENDOR's own stock edit is a different caller and keeps the
            // unconditional write: `writeStock()` turns management on because
            // somebody just typed a number. That split is the whole of
            // `alpha.83` in one field.
            if ($isNew) {
                // Only here: afterwards WooCommerce's numbers are the true
                // ones, the flag included.
                $wcProduct->set_manage_stock(true);
                $wcProduct->set_stock_quantity($details->stock);
                $wcProduct->set_stock_status($details->stock > 0 ? 'instock' : 'outofstock');
            }
        }

        try {
            $wcProductId = (int) $wcProduct->save();
        } catch (\Throwable) {
            return ['ok' => false, 'code' => 'storage_failed', 'wc_product_id' => 0, 'variation_links' => []];
        }
        if ($wcProductId <= 0) {
            return ['ok' => false, 'code' => 'storage_failed', 'wc_product_id' => 0, 'variation_links' => []];
        }

        update_post_meta($wcProductId, self::PRODUCT_META, $product->id);
        update_post_meta($wcProductId, self::VENDOR_META, $product->vendorUserId);
        // Written AFTER the save, and from what the SHOP HOLDS rather than
        // from what was sent — WooCommerce filters on the way in, and a
        // fingerprint of our own input would call the stored value edited on
        // the very next run (the `alpha.26` rule).
        $this->recordAttributeKeys($wcProductId, $merged['wrote'], $merged['held']);
        $this->recordQuantityKeys($wcProductId, $quantityMerged['wrote'], $quantityMerged['held']);
        ProjectedShopFields::store(
            $wcProductId,
            $wantedFields,
            $shopFieldsMerged['may'],
            $shopFieldsMerged['report']
        );
        // Stamp AFTER the save and from a fresh read: WooCommerce runs its own
        // filters on the way in, so the value that comes back is routinely not
        // the one that went out. Stamping what we *sent* would mark every
        // product manager-edited on its next projection.
        $this->stampOwned($wcProductId, $outcome);
        // ONLY when this run actually wrote it. Stamping an address we
        // refused to touch would launder somebody else's slug into ours, and
        // the projection after that would happily overwrite it — the same
        // «don't stamp what you did not write» rule `alpha.27` established
        // for every other field, arriving late for this one.
        if ($this->wroteSlug) {
            $this->stampSlug($wcProductId);
        }
        // The author is the vendor, so WordPress' own "posts by this user"
        // views and any theme byline attribute the product correctly.
        wp_update_post(['ID' => $wcProductId, 'post_author' => $product->vendorUserId]);

        $variationLinks = $details->type === ProductType::VARIABLE
            ? $this->projectVariations($wcProductId, $product, $attributes, $variations)
            : [];
        $this->recordHeldPrice($wcProductId, $priceHeld);
        $this->recordHeldStatus($wcProductId, $statusHeld);
        return [
            'ok' => true,
            'code' => 'projected',
            'wc_product_id' => $wcProductId,
            'variation_links' => $variationLinks,
            // Additive, so every existing caller keeps working: the two that
            // care read it, the rest ignore it (`alpha.32`).
            'price_held' => $priceHeld,
            'status_held' => $statusHeld,
            // One answer per field, so a caller that wants to say what
            // happened does not have to guess from a boolean. Additive like
            // the two above.
            'shop_fields' => $shopFieldsMerged['answers'],
        ];
    }

    /**
     * Takes the product out of the shop — and then CHECKS that it is out.
     *
     * Three things happen here in order, and the order is the whole design:
     *
     *  1. The clean path: `WC_Product::save()`, which writes the status, the
     *     catalogue visibility and a dozen meta rows at once.
     *  2. If that throws, or if it returned without the status actually
     *     landing, a **single-row fallback** — `wp_update_post()` writing only
     *     `post_status`. A save that fails on some meta row must not leave a
     *     product on sale, and one column is the least that can fail.
     *  3. A re-read. The answer this method returns is what WordPress says the
     *     status IS, not what we asked it to be.
     *
     * Why the re-read matters more than it looks: the caller reports success
     * to a manager who is about to replace the package, and after that our
     * code is gone. `post_status = draft` is a fact WooCommerce honours on its
     * own — `is_purchasable()` requires `publish` — so it survives our
     * absence. A boolean we returned optimistically does not.
     */
    public function withdraw(Product $product, string $reason = ''): bool
    {
        if (!$this->isAvailable()) {
            return false;
        }
        $wcProduct = $this->linkedProduct($product);
        if ($wcProduct === null) {
            return false;
        }
        $wcProductId = (int) $wcProduct->get_id();
        // Draft, never trash: an order that referenced this product must keep
        // resolving, and the master spec forbids destructive rewrites.
        try {
            $wcProduct->set_status('draft');
            $wcProduct->set_catalog_visibility('hidden');
            $wcProduct->save();
        } catch (\Throwable) {
            // fall through to the single-row write below
        }
        if (self::storefrontStatusOf($wcProductId) !== 'draft') {
            wp_update_post(['ID' => $wcProductId, 'post_status' => 'draft']);
            clean_post_cache($wcProductId);
        }
        if (self::storefrontStatusOf($wcProductId) !== 'draft') {
            return false;       // it is still on sale; say so
        }
        if ($reason !== '') {
            update_post_meta($wcProductId, '_tmc_withdrawn_reason', $reason);
        }
        return true;
    }

    /** What WordPress says this post's status IS, read fresh. */
    public function storefrontStatus(int $wcProductId): string
    {
        return self::storefrontStatusOf($wcProductId);
    }

    private static function storefrontStatusOf(int $wcProductId): string
    {
        return (string) get_post_status($wcProductId);
    }

    /**
     * The stock WooCommerce holds — from the ROW when there is one.
     *
     * **`wc_get_product()` is an instance cache, and that was measured, not
     * assumed.** WooCommerce 11.0.1 ships the `product_instance_caching`
     * feature ENABLED (`WC_Product_Factory::get_product()` lines 35-63), so a
     * second call inside one request can hand back the object built by the
     * first one. Measured here: another process reduced the row from 9 to 7,
     * a direct read of the row in this process said 7, and
     * `wc_get_product()->get_stock_quantity()` in the same breath still said
     * 9.
     *
     * That matters because this number is what the approval guards its write
     * ON (`writeStockIfUnchanged()`), and a guard that expects a number read
     * from a cached object is a guard about the past. The row is the thing a
     * shopper is held to, so the row is what this answers — and it is read
     * numerically, because the same stock reaches that row as «7» or as
     * «7.000000» depending on which code last wrote it.
     *
     * The object is still the fallback, and deliberately: a product whose
     * stock is managed elsewhere (a variation under its parent) has no row of
     * its own, and for one of those the object's answer is the right one.
     */
    public function readStock(Product $product): ?int
    {
        $wcProduct = $this->linkedProduct($product);
        if ($wcProduct === null) {
            return null;
        }
        $fromRow = self::storedStock((int) $wcProduct->get_stock_managed_by_id());
        if ($fromRow !== null) {
            return $fromRow;
        }
        $stock = $wcProduct->get_stock_quantity();
        return $stock === null ? null : (int) $stock;
    }

    public function writeStock(Product $product, int $stock): bool
    {
        $wcProduct = $this->linkedProduct($product);
        if ($wcProduct === null) {
            return false;
        }
        $wcProduct->set_manage_stock(true);
        $wcProduct->set_stock_quantity(max(0, $stock));
        $wcProduct->set_stock_status($stock > 0 ? 'instock' : 'outofstock');
        try {
            $wcProduct->save();
        } catch (\Throwable) {
            return false;
        }
        return true;
    }

    /**
     * The approved stock, written only if the shop still holds `$expected`.
     *
     * See `CatalogProjectorInterface::writeStockIfUnchanged()` for WHY this is
     * one statement. Here is HOW, and every part of it is WooCommerce's own:
     *
     *  - the statement is the one `update_product_stock()` builds for `set`,
     *    so the value lands in the dialect WooCommerce writes
     *    (`number_format($n, WC_ROUNDING_PRECISION)` — «7.000000», not «7»),
     *    the `_stock` row is ensured to exist by its own `add_post_meta()`,
     *    and the post-meta cache, the `wc_product_meta_lookup` table and the
     *    `woocommerce_product_before_set_stock` / `_set_stock` /
     *    `woocommerce_updated_product_stock` hooks all run as they always do;
     *  - the GUARD rides in on `woocommerce_update_product_stock_query`, the
     *    filter that method passes its SQL through
     *    (`class-wc-product-data-store-cpt.php:1827`). One statement, one row,
     *    one lock. Nothing here re-implements what WooCommerce does with the
     *    number afterwards;
     *  - `$updating` is TRUE so WooCommerce does not `save()` the product
     *    object for us. It would do that from the number it was ASKED for, and
     *    on a refusal that number is not the number on the row: the status
     *    would be synced to a quantity nobody wrote. The status is synced below
     *    instead, from what the row actually says.
     *
     * The comparison is NUMERIC, and that is not tidiness: the same stock
     * reaches that row in two spellings. `WC_Product::save()` stores the prop
     * through `update_post_meta()` as «7», and the direct path stores
     * «7.000000». A string comparison would be a guard that passes or fails on
     * which code last touched the product (the `alpha.42` lesson, on a new
     * row).
     *
     * @return array{outcome:string, found:?int}
     */
    public function writeStockIfUnchanged(Product $product, int $stock, int $expected): array
    {
        $wcProduct = $this->linkedProduct($product);
        if ($wcProduct === null) {
            return ['outcome' => 'not_linked', 'found' => null];
        }
        if (!$wcProduct->managing_stock()) {
            // WooCommerce is not keeping a number for this product, so there
            // is no row to guard and `wc_update_product_stock()` would do
            // nothing at all — silently. Named instead.
            return ['outcome' => 'not_managed', 'found' => null];
        }
        // Stock can be managed by the parent (a variation), and that is the row
        // the guard has to be about — the same id WooCommerce itself writes.
        $stockId = (int) $wcProduct->get_stock_managed_by_id();
        $amount = (int) wc_stock_amount(max(0, $stock));

        // AN EARLY ANSWER, AND NOT THE GUARD. The distinction matters enough to
        // write down, because `alpha.49`'s whole defect was mistaking one for
        // the other: reading the row here cannot make the write safe — anything
        // can happen between this line and the next — and the condition inside
        // the statement below is what does. This is here for a different
        // reason: it is the only way to tell «the statement was blocked» from
        // «the statement wrote a number the row already had». Both leave the row
        // equal to `$amount`, so the read-back after the write cannot separate
        // them, and a blocked write would be reported as a successful one.
        // Measured on this round's own first build: expecting 9 over a row of 4
        // answered `written`.
        $before = self::storedStock($stockId);
        if ($before === null || $before !== $expected) {
            return ['outcome' => 'moved', 'found' => $before];
        }
        // An integer cast is the whole sanitisation an integer needs, so this
        // class stays off `$wpdb` entirely.
        $condition = ' AND meta_value + 0 = ' . $expected;
        $guard = static function (
            string $sql,
            int $id,
            mixed $newStock,
            string $operation
        ) use ($stockId, $condition): string {
            return $operation === 'set' && $id === $stockId ? $sql . $condition : $sql;
        };
        add_filter('woocommerce_update_product_stock_query', $guard, 10, 4);
        try {
            wc_update_product_stock($wcProduct, $amount, 'set', true);
        } catch (\Throwable) {
            remove_filter('woocommerce_update_product_stock_query', $guard, 10);
            return ['outcome' => 'not_written', 'found' => null];
        }
        remove_filter('woocommerce_update_product_stock_query', $guard, 10);

        // What the ROW says now — not what the object thinks. WooCommerce has
        // just dropped this post's meta cache, so this read is fresh, and the
        // function's own return value is no use here: it reports the number it
        // COMPUTED, not the number it stored.
        //
        // Reached only when the row still held `$expected` a moment ago, so a
        // row that no longer holds `$amount` means the statement's condition
        // held and somebody else's number is there. The one case this still
        // calls `written` is a competing write that set the row to exactly the
        // approved number — the shop holds what was approved and nothing was
        // lost, which is the truth `written` tells.
        $found = self::storedStock($stockId);
        if ($found === null || $found !== $amount) {
            return ['outcome' => 'moved', 'found' => $found];
        }
        $this->syncStockStatus($stockId, $amount);
        return ['outcome' => 'written', 'found' => $amount];
    }

    /** The `_stock` row, read numerically so either spelling answers the same. */
    private static function storedStock(int $stockId): ?int
    {
        if (!metadata_exists('post', $stockId, '_stock')) {
            return null;
        }
        $raw = get_post_meta($stockId, '_stock', true);
        if ($raw === '' || $raw === null) {
            return null;
        }
        return (int) round((float) $raw);
    }

    /**
     * The stock status, brought in line with the number that is on the row.
     *
     * WooCommerce does this inside `wc_update_product_stock()` when it is not
     * «updating»; this round asks it not to (see above), so the same job is
     * done here and only when it has something to change. The rule is the one
     * `writeStock()` has always used, so the two paths cannot disagree.
     */
    private function syncStockStatus(int $stockId, int $amount): void
    {
        wc_delete_product_transients($stockId);
        $fresh = wc_get_product($stockId);
        if (!$fresh instanceof \WC_Product) {
            return;
        }
        $wanted = $amount > 0 ? 'instock' : 'outofstock';
        if ($fresh->get_stock_status() === $wanted) {
            return;
        }
        try {
            wc_update_product_stock_status($stockId, $wanted);
        } catch (\Throwable) {
            // The number is on the row, which is what a shopper is held to.
            // A status that lags is visible and fixable; a wrong number is not.
        }
    }

    public function claimStorefrontPost(Product $product, int $wcProductId): bool
    {
        if (!$this->isAvailable() || $wcProductId <= 0) {
            return false;
        }
        $post = get_post($wcProductId);
        if ($post === null || !in_array($post->post_type, ['product', 'product_variation'], true)) {
            return false;
        }
        $existing = (int) get_post_meta($wcProductId, self::PRODUCT_META, true);
        if ($existing > 0 && $existing !== $product->id) {
            // Another marketplace row already owns this post. Two owners is
            // not a state any later question could resolve.
            return false;
        }
        // The ONLY write this plugin ever makes to a post it did not create,
        // and it writes exactly three keys: the link, the vendor, and the
        // status the post had at this moment. Nothing about the product
        // itself — not its title, price, stock or author — is touched.
        //
        // The third key is what makes the transfer reversible, and it was
        // added because leaving it out was measurably not reversible: take
        // ownership, stop selling, give ownership back, and the Dokan
        // vendor's product stayed a draft with nothing left to restore it.
        update_post_meta($wcProductId, self::PRODUCT_META, $product->id);
        update_post_meta($wcProductId, self::VENDOR_META, $product->vendorUserId);
        if (get_post_meta($wcProductId, self::CLAIMED_FROM_STATUS_META, true) === '') {
            update_post_meta($wcProductId, self::CLAIMED_FROM_STATUS_META, (string) get_post_status($wcProductId));
        }
        clean_post_cache($wcProductId);
        return $this->owns($wcProductId, $product->id);
    }

    public function releaseStorefrontPost(Product $product, int $wcProductId): bool
    {
        if (!$this->isAvailable() || !$this->owns($wcProductId, $product->id)) {
            return false;
        }
        // Put the post back the way it was found, THEN stop owning it. A
        // product taken over, withdrawn by a stop and then handed back must
        // not be left on the shelf as a draft: from the shop's point of view
        // the whole episode has to be undoable.
        $claimedFrom = (string) get_post_meta($wcProductId, self::CLAIMED_FROM_STATUS_META, true);
        if ($claimedFrom !== '' && (string) get_post_status($wcProductId) !== $claimedFrom) {
            wp_update_post(['ID' => $wcProductId, 'post_status' => $claimedFrom]);
        }
        delete_post_meta($wcProductId, self::PRODUCT_META);
        delete_post_meta($wcProductId, self::VENDOR_META);
        delete_post_meta($wcProductId, self::CLAIMED_FROM_STATUS_META);
        clean_post_cache($wcProductId);
        return !$this->owns($wcProductId, $product->id);
    }

    public function increaseStock(Product $product, int $by): ?int
    {
        if ($by <= 0) {
            return null;
        }
        $wcProduct = $this->linkedProduct($product);
        if ($wcProduct === null || !function_exists('wc_update_product_stock')) {
            return null;
        }
        if (!$wcProduct->get_manage_stock()) {
            // WooCommerce is not counting this product, so there is no number
            // to correct. Saying so is the honest answer; inventing a stock
            // level for a product whose shop chose not to track it is not.
            return null;
        }
        // WooCommerce's own atomic increment — one UPDATE with `+ %d`, not a
        // read and a write, so a sale landing between the two cannot be lost.
        $after = wc_update_product_stock($wcProduct, $by, 'increase');
        if ($after === false || $after === null) {
            return null;
        }
        wc_delete_product_transients((int) $wcProduct->get_id());
        return (int) $after;
    }

    public function readVariationStock(Product $product): array
    {
        if (!$this->isAvailable() || !$product->isProjected()) {
            return [];
        }
        $out = [];
        foreach ($this->existingVariationIds((int) $product->wcProductId) as $tmcId => $wcVariationId) {
            $variation = wc_get_product($wcVariationId);
            if (!$variation) {
                continue;
            }
            $stock = $variation->get_stock_quantity();
            if ($stock !== null) {
                $out[$tmcId] = (int) $stock;
            }
        }
        return $out;
    }

    public function owns(int $wcProductId, int $productId): bool
    {
        if ($wcProductId <= 0 || $productId <= 0) {
            return false;
        }
        $post = get_post($wcProductId);
        if ($post === null || !in_array($post->post_type, ['product', 'product_variation'], true)) {
            return false;
        }
        return (int) get_post_meta($wcProductId, self::PRODUCT_META, true) === $productId;
    }

    // ------------------------------------------------------------ internals

    /** The linked WooCommerce product, or null when there is none we own. */
    private function linkedProduct(Product $product): mixed
    {
        if (!$this->isAvailable() || !$product->isProjected()) {
            return null;
        }
        $wcProductId = (int) $product->wcProductId;
        if (!$this->owns($wcProductId, $product->id)) {
            return null;     // the post went away, or was never ours
        }
        $wcProduct = wc_get_product($wcProductId);
        return $wcProduct instanceof \WC_Product ? $wcProduct : null;
    }

    private function blank(Product $product): mixed
    {
        return $product->details->type === ProductType::VARIABLE
            ? new \WC_Product_Variable()
            : new \WC_Product_Simple();
    }

    /**
     * A SKU WooCommerce already knows belongs elsewhere throws; the product is
     * still worth publishing without one, and the vendor's own SKU check has
     * already made it unique within their shop.
     */
    private function applySku(mixed $wcProduct, string $sku): void
    {
        if (trim($sku) === '') {
            return;
        }
        try {
            $wcProduct->set_sku($sku);
        } catch (\Throwable) {
            // left as it was
        }
    }

    /**
     * The sale price — and the one case in which it is not ours to remove.
     *
     * ⛔ **Measured.** `ImportExistingProducts::detailsFrom()` reads the sale
     * price through `exactInteger()`, so a shop sale price with a fraction
     * becomes `salePriceMinor = null` — «no sale» — while the shop still has
     * one. The regular price cannot reach this state (intake REFUSES a
     * fractional one by name, `price_not_an_integer`), so the fractional SALE
     * price is the only half of the `price_scale` risk an intaken row can
     * carry. And on a re-snapshotted row the price write is permitted —
     * `ShopEditMerge::decide()` answers `WRITE` when the two agree, which
     * after a refresh they do — so this method ran and CLEARED the shop's
     * sale price together with both of its dates.
     *
     * `$oursIsFresh` is the same flag `ShopEditMerge` has taken since
     * `alpha.83`, from the same two callers and for the same reason: a
     * projection mirrors a row that may be months old, the vendor's own price
     * change is fresh by construction. So a projection keeps a sale price it
     * never recorded, and the vendor who removes their sale still removes it.
     *
     * Only the CLEARING branch asks. Writing a sale price we do hold is the
     * vendor's value going out, which no rule here delays.
     */
    private function applySale(mixed $wcProduct, Product $product, bool $oursIsFresh): void
    {
        $details = $product->details;
        if ($details->salePriceMinor === null) {
            if (!$oursIsFresh && (string) $wcProduct->get_sale_price() !== '') {
                return;
            }
            $wcProduct->set_sale_price('');
            $wcProduct->set_date_on_sale_from(null);
            $wcProduct->set_date_on_sale_to(null);
            return;
        }
        $wcProduct->set_sale_price((string) $details->salePriceMinor);
        $wcProduct->set_date_on_sale_from($details->saleFrom);
        $wcProduct->set_date_on_sale_to($details->saleTo);
    }

    /**
     * The public address, and the one rule that was missing from it.
     *
     * `set_slug()` ran on every projection while the marketplace had a slug
     * — with no ownership test at all. So a manager who corrected the address
     * in WooCommerce or in Rank Math had it silently put back the next time
     * the VENDOR pressed save, which is the one thing a vendor is explicitly
     * not allowed to touch (Master A.5: «فروشنده فیلد تخصصی SEO ندارد»).
     *
     * So the slug gets the same stamp everything else has. We write it while
     * it is still the one we wrote; the moment somebody else changes it, it
     * is theirs and this method stops. It is deliberately NOT added to the
     * review screen's field list: the address belongs to the manager either
     * way, so there is no disagreement to put a button on — only a write to
     * stop making.
     */
    private function applySeo(mixed $wcProduct, Product $product): void
    {
        $seo = $product->seo;
        $wcProductId = (int) $wcProduct->get_id();
        $currentSlug = (string) $wcProduct->get_slug();
        $slugStamp = $wcProductId > 0
            ? (string) get_post_meta($wcProductId, ProjectedFieldOwnership::STAMP_PREFIX . self::SLUG_FIELD, true)
            : '';
        // A post this projection is creating has no address yet; anything
        // else must still be carrying OUR address for us to move it.
        $slugIsOurs = $wcProductId <= 0
            || $currentSlug === ''
            || ($slugStamp !== '' && hash_equals($slugStamp, ProjectedFieldOwnership::fingerprint($currentSlug)));
        $this->wroteSlug = trim($seo->slug) !== '' && $slugIsOurs;
        if ($this->wroteSlug) {
            $wcProduct->set_slug($seo->slug);
        }
        if ($wcProductId <= 0) {
            return;    // set after save, on the next projection
        }
        if (trim($seo->title) !== '') {
            update_post_meta($wcProductId, '_tmc_seo_title', $seo->title);
        }
        if (trim($seo->description) !== '') {
            update_post_meta($wcProductId, '_tmc_seo_description', $seo->description);
        }
    }

    /**
     * Stamp the slug from what WordPress KEPT, after the save.
     *
     * `sanitize_title()` runs on the way in and `wp_unique_post_slug()` may
     * append `-2`, so the value that comes back is routinely not the one that
     * went out — stamping what we sent would mark the address foreign on its
     * very next projection.
     */
    /**
     * The manager's explicit decision about the address.
     *
     * A projection is evidence-driven and will not move a slug somebody else
     * chose. This is the other path: the manager typing an address on the
     * review screen, which is a decision and is applied once — and stamped,
     * so the next projection knows the address is ours again.
     */
    public function applySlug(Product $product, string $slug): bool
    {
        $slug = trim($slug);
        if (!$this->isAvailable() || !$product->isProjected() || $slug === '') {
            return false;
        }
        $wcProductId = (int) $product->wcProductId;
        if (!$this->owns($wcProductId, $product->id)) {
            return false;       // not ours; never rename somebody else's post
        }
        $updated = wp_update_post(['ID' => $wcProductId, 'post_name' => $slug], true);
        if (is_wp_error($updated)) {
            return false;
        }
        clean_post_cache($wcProductId);
        $this->stampSlug($wcProductId);
        return true;
    }

    private function stampSlug(int $wcProductId): void
    {
        $fresh = get_post($wcProductId);
        if (!$fresh instanceof \WP_Post) {
            return;
        }
        update_post_meta(
            $wcProductId,
            ProjectedFieldOwnership::STAMP_PREFIX . self::SLUG_FIELD,
            ProjectedFieldOwnership::fingerprint((string) $fresh->post_name)
        );
    }

    /** The ids `project()` would write for the category, for a caller that compares. */
    public function storefrontCategoryFor(Product $product, array $current = []): string
    {
        return ProjectedFieldOwnership::idsToValue(
            $this->categoryIds($product->details, array_map('intval', $current), $product->imported)
        );
    }

    /**
     * Write a field, or refuse and say why — and record which it was.
     *
     * @param callable(\WC_Product):string        $read    what WooCommerce has now
     * @param callable(\WC_Product,string):mixed  $write   how to set it
     * @param array<string,string>                $outcome filled with what happened
     *
     * `$outcome[$field]` is how `stampOwned()` knows what actually happened:
     * `wrote` gets a stamp, `held` gets a pending proposal, and `frozen` gets
     * NEITHER. That last one is new in `alpha.27` and it is the point of the
     * whole change: a field on a product older than the stamps must come out
     * of a projection with the marketplace having touched nothing and
     * claimed nothing.
     */
    private function writeOwned(
        \WC_Product $wcProduct,
        string $field,
        string $want,
        callable $read,
        callable $write,
        array &$outcome,
        bool $createdByUs,
        ?ApprovedBaseline $baseline = null
    ): void {
        $id = (int) $wcProduct->get_id();
        $stamp = $id > 0 ? (string) get_post_meta($id, ProjectedFieldOwnership::STAMP_PREFIX . $field, true) : '';
        $current = (string) $read($wcProduct);
        // Before asking who owns it: a GENERATED field that no longer matches
        // our stamp has been edited in WooCommerce by a person, and that is
        // recorded now rather than rediscovered on every save.
        $this->recordDerivedTakeover($id, $field, $stamp, $current);
        $managerOwns = $id > 0 && (string) get_post_meta($id, ProjectedFieldOwnership::MANAGER_PREFIX . $field, true) === '1';

        // Three values, not two. `$want` is what the marketplace row says,
        // `$current` is what the shop holds, and the baseline is what the
        // vendor's edit was measured from — without which «the manager
        // changed a field nobody asked about» and «the two sides disagree»
        // are the same fact.
        $verdict = FieldMerge::decide(
            $baseline !== null && $baseline->has($field),
            $baseline?->get($field) ?? '',
            $want,
            $current,
            $stamp,
            $managerOwns,
            $createdByUs,
            !in_array($field, ProjectedFieldOwnership::ROUND_TRIP, true)
        );

        switch ($verdict) {
            case FieldMerge::WRITE:
                $write($wcProduct, $want);
                $outcome[$field] = 'wrote';
                return;

            case FieldMerge::SKIP:
                // The vendor did not touch this field. Whatever the manager
                // did with it stands, and NOTHING is recorded: no write, no
                // proposal, no question. This one line is what turns one
                // vendor edit back into one question instead of five.
                $outcome[$field] = 'skipped';
                return;

            case FieldMerge::CONFLICT:
                // A real disagreement: both sides moved it, to different
                // values. Recording a proposal equal to what is already there
                // would show the manager a «change» that changes nothing, and
                // `decide()` has already ruled that case out.
                $outcome[$field] = 'held';
                $outcome[$field . ':value'] = $want;
                return;

            case FieldMerge::MANAGER:
                // `description` is the field this matters most for. The
                // marketplace BUILDS that text, so once a manager has edited
                // it every short-description change would otherwise re-raise
                // the same question for ever.
                $outcome[$field] = 'frozen';
                return;

            default:
                // `unsettled`: older than the stamps, and nobody knows who
                // wrote what is there. Not ours to write and not ours to
                // stamp — agreeing with a value is not the same as having
                // written it. But the vendor's value IS recorded beside it,
                // exactly as `alpha.27` recorded it, because the «فیلدهای
                // بدون سابقه» block is where somebody settles this and a
                // block with nothing to compare against settles nothing.
                if (ProjectedFieldOwnership::fingerprint($want) !== ProjectedFieldOwnership::fingerprint($current)) {
                    $outcome[$field] = 'held';
                    $outcome[$field . ':value'] = $want;
                    return;
                }
                $outcome[$field] = 'frozen';
                return;
        }
    }

    /**
     * A generated field the manager has edited belongs to the manager — and
     * that is recorded rather than re-derived every run.
     *
     * `description` is not authored by anyone here: the projector renders it
     * out of the short description, the brand and the medical specification.
     * So if the stamp says we wrote X and the shop holds Y, the only thing
     * that can have happened is that somebody edited it in WooCommerce. That
     * is evidence, not a guess, and the safe conclusion — «stop writing it» —
     * is recorded once, with an audit line, instead of being rediscovered on
     * every save. The manager can hand the field back from the review screen.
     */
    private function recordDerivedTakeover(int $wcProductId, string $field, string $stamp, string $current): void
    {
        if ($wcProductId <= 0 || $stamp === '' || $field !== 'description') {
            return;
        }
        if (hash_equals($stamp, ProjectedFieldOwnership::fingerprint($current))) {
            return;
        }
        update_post_meta($wcProductId, ProjectedFieldOwnership::MANAGER_PREFIX . $field, '1');
        delete_post_meta($wcProductId, ProjectedFieldOwnership::PENDING_PREFIX . $field);
    }

    /**
     * Record what we just wrote, and what we did not.
     *
     * @param array<string,string> $outcome field => wrote|held|frozen, plus
     *        `<field>:value` for the ones held back
     */
    private function stampOwned(int $wcProductId, array $outcome): void
    {
        $wcProduct = wc_get_product($wcProductId);
        if (!$wcProduct instanceof \WC_Product) {
            return;
        }
        $now = [
            'title' => (string) $wcProduct->get_name(),
            'short_description' => (string) $wcProduct->get_short_description(),
            'description' => (string) $wcProduct->get_description(),
            'images' => ProjectedFieldOwnership::imagesToValue(
                (int) $wcProduct->get_image_id(),
                $wcProduct->get_gallery_image_ids()
            ),
            'category' => ProjectedFieldOwnership::idsToValue(
                array_map('intval', $wcProduct->get_category_ids())
            ),
        ];
        foreach (ProjectedFieldOwnership::FIELDS as $field) {
            $pending = ProjectedFieldOwnership::PENDING_PREFIX . $field;
            switch ($outcome[$field] ?? 'frozen') {
                case 'wrote':
                    delete_post_meta($wcProductId, $pending);
                    update_post_meta(
                        $wcProductId,
                        ProjectedFieldOwnership::STAMP_PREFIX . $field,
                        ProjectedFieldOwnership::fingerprint($now[$field] ?? '')
                    );
                    break;
                case 'held':
                    // A proposal the manager has not answered yet. The stamp
                    // is deliberately left alone: the field is still theirs.
                    update_post_meta($wcProductId, $pending, $outcome[$field . ':value'] ?? '');
                    break;
                default:
                    // `frozen`: either the manager owns it, or nobody knows
                    // who does. Not ours to stamp. Stamping would say «the
                    // marketplace wrote this», and the next projection would
                    // believe it and overwrite — the exact failure this whole
                    // mechanism exists to stop.
                    break;
            }
        }
    }

    /**
     * The WooCommerce term this product belongs to — resolved, never created.
     *
     * Until `alpha.24` this built a `tmc-…` slug out of the template key and
     * called `wp_insert_term()` when it did not exist. On a shop with 1,070
     * real categories that is a second, invisible taxonomy: the product lands
     * under a term the shop's menus, filters, Elementor templates and Rank
     * Math sitemap have never heard of, and the category the owner actually
     * uses stays empty. The owner's instruction is explicit — «دسته‌بندی
     * موازی یا تعریف دوبارهٔ آن‌ها نمی‌خواهیم» — so nothing here writes to the
     * taxonomy any more.
     *
     * `$current` is what the product already carries. An unresolvable value
     * KEEPS it rather than clearing it: a stored key whose term somebody
     * renamed or deleted is a reason to leave the product where the shop put
     * it, not a reason to strip its category on the next sync.
     *
     * ⛔ **And it returns the whole SET, never one id.** Until `alpha.81` this
     * resolved the single `category_key` and answered `[$that]`, which
     * `set_category_ids()` then wrote — and that call REPLACES. Measured on
     * `alpha.81`'s installed bytes, on a product carrying a parent and its own
     * child: `terms_before=[244,245]` → `terms_after=[244]`,
     * `terms_lost=[245]`, with the screen reporting success
     * (`docs/evidence/alpha82-audit/before-alpha81.txt`). The owner's
     * instruction is that this must not happen at all: «مجموعهٔ کامل دسته‌ها
     * باید حفظ شود… هیچ رابطه‌ای خودکار حذف یا اضافه نشود.»
     *
     * So the set the product RECORDS is what is written, and an id in it that
     * no longer resolves keeps its place in `$current` rather than being
     * dropped — the same reason an unresolvable single key kept the product
     * where the shop put it.
     *
     * **And nothing is ever removed.** The answer is the union of the recorded
     * set and what the product already carries, because a relationship this
     * marketplace never recorded is not this marketplace's to take away. A
     * category is detached in WooCommerce, by a human, on WooCommerce's own
     * screen; this method's job is to make sure ours are present.
     *
     * @param list<int> $current
     * @return list<int>
     */
    private function categoryIds(
        ProductDetails $details,
        array $current = [],
        bool $imported = false
    ): array {
        $current = CategorySet::of($current);
        if (!taxonomy_exists('product_cat')) {
            return $current;
        }
        // ⛔ THE SINGLE-KEY FALLBACK IS NOT A RELATIONSHIP ON AN IMPORTED ROW.
        //
        // `categorySet()` answers the recorded set, or — when nothing is
        // recorded — the single `category_key`. For a row the marketplace
        // created that key is the vendor's own choice on their form, and
        // attaching it IS what publishing a category means. For an IMPORTED
        // row it can be a mapping of an old DOKAN category, written by
        // `ApplyCategoryMapping` into the marketplace's own column, which the
        // medical spec template reads and WooCommerce never said.
        //
        // Measured on `alpha.86`: a product carrying only `default_product_cat`
        // took a mapped key and the union below answered `{715, 703}` — a
        // `product_cat` relationship this plugin invented. «هیچ رابطه‌ای
        // خودکار حذف یا اضافه نشود.» It was unreachable only because every
        // imported row is `observed` and `SyncCatalog` refuses to project one
        // — a STATE, not a guard, and an ownership transfer removes it.
        //
        // So an imported row projects the ids it RECORDED and nothing else.
        // Every one of those came from the product's own relationship
        // (`ApplyCategoryLinks` reads them from WooCommerce), so the union
        // stays a no-op for them and the shop is still never narrowed.
        $claimed = $imported ? $details->categoryIds : $details->categorySet();
        $wanted = [];
        foreach ($claimed as $id) {
            // Resolved, never created — and asked by id, which is what the
            // directory has been keyed on since `alpha.25`.
            if ($this->categories?->find((string) $id) !== null) {
                $wanted[] = $id;
            }
        }
        if ($wanted === []) {
            return $current;
        }
        return CategorySet::of(array_merge($current, $wanted));
    }

    /**
     * @param list<ProductAttribute> $attributes
     * @return array<string,\WC_Product_Attribute>
     */

    /**
     * The brand and the answered specification fields, as WooCommerce attributes.
     *
     * Read from the rows the vendor already filled in on step 3 — «نیازی به
     * ورود دوبارهٔ مشخصات توسط فروشنده نباشد». Empty answers are skipped
     * (UX §6.2) and retired fields are not asked for, so a field the manager
     * retires stops appearing without anybody editing a product.
     *
     * `set_variation(false)`: these describe the product, they do not generate
     * variations. A visible, non-variation custom attribute is exactly what
     * the «اطلاعات بیشتر» table is for.
     *
     * @return array<string,\WC_Product_Attribute>
     */
    private function factAttributes(Product $product): array
    {
        $out = [];
        $position = 100;        // after the variation attributes, which start at 0
        if (trim($product->details->brand) !== '') {
            $out += $this->attribute(
                __('برند', 'tecteb-marketplace-core'),
                $product->details->brand,
                $position++
            );
        }
        $template = $this->templates->findByCategory($product->details->categoryKey);
        foreach ($template?->askedFields() ?? [] as $field) {
            $value = trim($product->specs[$field->key] ?? '');
            if ($value === '') {
                continue;
            }
            // Keyed by the LABEL, because that is the key WooCommerce will
            // use. Two asked fields that happen to share a label are one
            // attribute on the shop whatever we do here, so the first one
            // keeps the key rather than the last one silently replacing it.
            $out += $this->attribute(
                $field->label,
                $field->unit !== '' ? $value . ' ' . $field->unit : $value,
                $position++
            );
        }
        return $out;
    }

    /** Whatever is on disk, in whatever shape; `normalise()` reads it. */
    private function storedAttributeRecord(int $wcProductId): mixed
    {
        return $wcProductId <= 0
            ? null
            : get_post_meta($wcProductId, ProjectedAttributes::OWNED_META, true);
    }

    /**
     * Record what the shop ACTUALLY holds for the keys we just wrote.
     *
     * Three things this will not do, and each of them was a way to claim
     * ownership of something we do not own:
     *
     *  - it does not fingerprint the attribute we SENT. WooCommerce filters
     *    input, so the stored value can differ from the submitted one, and a
     *    record of the submitted one would read as «the manager edited this»
     *    forever after.
     *  - it does not record a key the save did not land. A key we asked for
     *    and the shop does not hold is a write that failed; recording it
     *    would license overwriting whatever IS there next time.
     *  - it does not trust `update_post_meta()`'s return value. That function
     *    answers `false` both for a failure and for «the value is already
     *    this», which are opposite facts. The record is READ BACK and
     *    compared; if it did not store, the record is REMOVED rather than
     *    left stale — an absent record is decided by the no-op test, and a
     *    stale one would be believed.
     *
     * @param list<string> $wrote keys this projection put into the set
     * @param list<string> $held  keys somebody else holds
     */
    private function recordAttributeKeys(int $wcProductId, array $wrote, array $held): void
    {
        $stored = [];
        $fresh = wc_get_product($wcProductId);
        if ($fresh instanceof \WC_Product) {
            $now = $fresh->get_attributes();
            foreach ($wrote as $key) {
                $attribute = $now[$key] ?? null;
                if ($attribute instanceof \WC_Product_Attribute) {
                    $stored[$key] = ProjectedAttributes::fingerprint($attribute);
                }
            }
        }

        $problem = [];
        if ($stored === []) {
            delete_post_meta($wcProductId, ProjectedAttributes::OWNED_META);
        } else {
            update_post_meta($wcProductId, ProjectedAttributes::OWNED_META, $stored);
            $readBack = ProjectedAttributes::normalise(
                get_post_meta($wcProductId, ProjectedAttributes::OWNED_META, true)
            );
            if ($readBack !== $stored) {
                delete_post_meta($wcProductId, ProjectedAttributes::OWNED_META);
                $problem[] = ProjectedAttributes::RECORD_NOT_STORED;
            }
        }

        // A conflict that has gone away must stop being reported, so this is
        // written on every run rather than only when there is one.
        $report = array_values(array_unique([...$held, ...$problem]));
        if ($report === []) {
            delete_post_meta($wcProductId, ProjectedAttributes::CONFLICT_META);
        } else {
            update_post_meta($wcProductId, ProjectedAttributes::CONFLICT_META, $report);
        }
    }

    /**
     * Which of the three quantity rows this write may touch — one answer, two
     * callers.
     *
     * `project()` stages the result through `update_meta_data()` so it rides
     * the one save (a new product has no post id yet), and `writeQuantities()`
     * writes it straight onto a product that already exists. Both ask THIS,
     * because two places computing «may I write this row» is two rules about
     * one thing, and the day they disagree the disagreement is about whether a
     * manager's edit survives.
     *
     * @return array{values:array<string,string>, wrote:list<string>, held:list<string>}
     */
    private static function mergeQuantities(mixed $wcProduct, Product $product): array
    {
        $current = [];
        foreach (ProjectedQuantity::keys() as $metaKey) {
            // ABSENT and «present but empty» are different answers and
            // `get_meta()` gives `''` for both — the `alpha.28` rule. The
            // product's own meta-data list is the only place that can tell
            // them apart before a save.
            if ($wcProduct->meta_exists($metaKey)) {
                $current[$metaKey] = (string) $wcProduct->get_meta($metaKey, true);
            }
        }
        return ProjectedQuantity::merge(
            $current,
            ProjectedQuantity::values($product->details->purchaseQuantity()),
            ProjectedQuantity::normalise(
                (int) $wcProduct->get_id() > 0
                    ? get_post_meta((int) $wcProduct->get_id(), ProjectedQuantity::OWNED_META, true)
                    : []
            )
        );
    }

    /**
     * The three quantity rows, written at once and nothing else with them.
     *
     * Read back per row rather than trusted: `update_post_meta()` answers
     * `false` both for «it failed» and for «it already said that» (the
     * `alpha.44` rule), so the only honest question is what the shop holds
     * afterwards. A row that would not store is named in `failed` and keeps
     * its PREVIOUS value — which is the conservative direction, because the
     * previous value is a restriction that exists and absence would be a
     * licence that nobody granted (`alpha.47`).
     *
     * @return array{ok:bool, code:string, wrote:list<string>, held:list<string>, failed:list<string>}
     */
    public function writePrice(Product $product): array
    {
        $blank = ['wrote' => [], 'held' => [], 'failed' => []];
        if (!$this->isAvailable()) {
            return ['ok' => false, 'code' => 'woocommerce_missing', ...$blank];
        }
        if (!$product->isProjected() || !$this->owns((int) $product->wcProductId, $product->id)) {
            return ['ok' => false, 'code' => 'not_ours', ...$blank];
        }
        $details = $product->details;
        if ($details->type === ProductType::VARIABLE) {
            // A variable product's own price is derived by WooCommerce from
            // its variations, and `project()` has never written one. Saying
            // so is not a failure.
            return ['ok' => true, 'code' => 'price_from_variations', ...$blank];
        }
        if (!$details->hasPrice()) {
            // «قیمتی ثبت نشده» is a state of the marketplace row, named by
            // `missingFields()` since the four-step form existed, and writing
            // nought as a price is the `alpha.66` defect. Not this method's
            // business to report twice.
            return ['ok' => true, 'code' => 'price_not_recorded', ...$blank];
        }
        $wcProduct = $this->linkedProduct($product);
        if (!$wcProduct instanceof \WC_Product) {
            // A read that failed is not «the shop holds nothing».
            return ['ok' => false, 'code' => 'storefront_unreadable', ...$blank];
        }
        $wcProductId = (int) $product->wcProductId;
        $wanted = [ShopEditMerge::PRICE => (string) $details->priceMinor];
        // ⛔ `true`: our value is fresh BY CONSTRUCTION on this path.
        // `ManageProducts::saveAsRevision()` writes the vendor's new price one
        // statement earlier and calls this as its mirror, so «the copy we are
        // holding» is the change the vendor just made — not a stale row. That
        // is the whole difference between this call and a projection, and it
        // is what keeps «این اختیار نباید محدود شود» true on a product that
        // was taken in before any record existed and then edited by hand.
        $merged = ProjectedShopFields::merge(
            ProjectedShopFields::shopValues($wcProduct),
            $wanted,
            ProjectedShopFields::record($wcProductId),
            false,
            true
        );
        if (!$merged['may'][ShopEditMerge::PRICE]) {
            // Somebody edited the shop's price by hand. It stays, and the
            // record of what we last wrote stays true, so nothing is stored
            // here beyond the report.
            ProjectedShopFields::store($wcProductId, $wanted, [], $merged['report']);
            return [
                'ok' => true,
                'code' => 'price_kept',
                'wrote' => [],
                'held' => [ShopEditMerge::PRICE],
                'failed' => [],
            ];
        }
        $wcProduct->set_regular_price((string) $details->priceMinor);
        // `true`: fresh by construction on this path, as above — so the
        // vendor who clears their own sale price still clears it.
        $this->applySale($wcProduct, $product, true);
        try {
            $saved = (int) $wcProduct->save();
        } catch (\Throwable) {
            $saved = 0;
        }
        // `WC_Product::save()` returns the id whether it wrote anything or
        // not and swallows its own exceptions, so the id proves nothing
        // (`alpha.11`). The shop is asked instead.
        $fresh = $saved > 0 ? wc_get_product($wcProductId) : null;
        $landed = $fresh instanceof \WC_Product
            && ShopEditMerge::canonical(ShopEditMerge::PRICE, (string) $fresh->get_regular_price())
                === ShopEditMerge::canonical(ShopEditMerge::PRICE, (string) $details->priceMinor);
        if (!$landed) {
            ProjectedShopFields::store($wcProductId, $wanted, [], $merged['report']);
            return [
                'ok' => false,
                'code' => 'price_not_written',
                'wrote' => [],
                'held' => [],
                'failed' => [ShopEditMerge::PRICE],
            ];
        }
        ProjectedShopFields::store($wcProductId, $wanted, [ShopEditMerge::PRICE => true], $merged['report']);
        return [
            'ok' => true,
            'code' => 'price_written',
            'wrote' => [ShopEditMerge::PRICE],
            'held' => [],
            'failed' => [],
        ];
    }

    public function writeQuantities(Product $product): array
    {
        $blank = ['wrote' => [], 'held' => [], 'failed' => []];
        if (!$this->isAvailable()) {
            return ['ok' => false, 'code' => 'woocommerce_missing', ...$blank];
        }
        if (!$product->isProjected() || !$this->owns((int) $product->wcProductId, $product->id)) {
            return ['ok' => false, 'code' => 'not_ours', ...$blank];
        }
        $wcProduct = $this->linkedProduct($product);
        if (!$wcProduct instanceof \WC_Product) {
            // A read that failed is not «no rule is stored». Saying so is what
            // keeps the caller from reporting a success it did not get.
            return ['ok' => false, 'code' => 'storefront_unreadable', ...$blank];
        }
        $wcProductId = (int) $product->wcProductId;
        $merged = self::mergeQuantities($wcProduct, $product);

        $wrote = [];
        $failed = [];
        foreach ($merged['values'] as $metaKey => $metaValue) {
            update_post_meta($wcProductId, $metaKey, $metaValue);
            if (metadata_exists('post', $wcProductId, $metaKey)
                && (string) get_post_meta($wcProductId, $metaKey, true) === $metaValue) {
                $wrote[] = $metaKey;
                continue;
            }
            $failed[] = $metaKey;
        }
        // The record is taken from what the SHOP HOLDS, by the same method
        // `project()` uses, so a row written here is owned on exactly the
        // terms a projected row is owned.
        $record = ProjectedQuantity::normalise(get_post_meta($wcProductId, ProjectedQuantity::OWNED_META, true));
        $retain = [];
        foreach ($failed as $metaKey) {
            if (isset($record[$metaKey])) {
                $retain[$metaKey] = $record[$metaKey];
            }
        }
        $this->recordQuantityKeys($wcProductId, $wrote, $merged['held'], $retain);

        return [
            'ok' => $failed === [],
            'code' => $failed === [] ? ($merged['held'] === [] ? 'limits_written' : 'limits_partly_held') : 'limits_not_written',
            'wrote' => $wrote,
            'held' => $merged['held'],
            'failed' => $failed,
        ];
    }

    /**
     * What the shop HOLDS for each quantity row we wrote, fingerprinted.
     *
     * The same four rules as `recordAttributeKeys()`, and the same reasons:
     *
     *  - read from a FRESH product, because WooCommerce filters on the way in
     *    and a fingerprint of our own input would call the stored value edited
     *    on the very next run (`alpha.26`);
     *  - a key the shop does not hold after the save is NOT recorded, because
     *    recording it would be a licence to overwrite whatever is there next
     *    time;
     *  - the record is READ BACK and compared, because `update_post_meta()`
     *    answers `false` both for a failure and for «it was already this»
     *    (`alpha.44`), and a record that did not store is DELETED rather than
     *    left stale — an absent record is decided conservatively, a stale one
     *    is believed;
     *  - the conflict list is written on every run, so a conflict that has
     *    gone away stops being reported.
     *
     * `$retain` is the fifth rule, and it exists because a row that would not
     * store must not change hands. A key whose write FAILED is not in `$wrote`,
     * so without this its fingerprint would be dropped — and the next run would
     * find a row with no record holding a value that differs from the one it
     * wants, read that as somebody else's, and hand a transient write failure
     * the manager's veto for ever. So a failed key keeps the fingerprint it
     * already had, and only while the shop still holds exactly that value.
     *
     * @param list<string> $wrote
     * @param list<string> $held
     * @param array<string,string> $retain `key => fingerprint` to keep for keys
     *                                     this run did not write
     */
    private function recordQuantityKeys(int $wcProductId, array $wrote, array $held, array $retain = []): void
    {
        $stored = [];
        $fresh = wc_get_product($wcProductId);
        if ($fresh instanceof \WC_Product) {
            foreach ($wrote as $key) {
                if (!$fresh->meta_exists($key)) {
                    continue;
                }
                $stored[$key] = ProjectedQuantity::fingerprint((string) $fresh->get_meta($key, true));
            }
            foreach ($retain as $key => $fingerprint) {
                if (isset($stored[$key]) || !in_array($key, ProjectedQuantity::keys(), true)) {
                    continue;
                }
                if (!$fresh->meta_exists($key)) {
                    continue;
                }
                if (hash_equals($fingerprint, ProjectedQuantity::fingerprint((string) $fresh->get_meta($key, true)))) {
                    $stored[$key] = $fingerprint;
                }
            }
        }

        $problem = [];
        if ($stored === []) {
            delete_post_meta($wcProductId, ProjectedQuantity::OWNED_META);
        } else {
            update_post_meta($wcProductId, ProjectedQuantity::OWNED_META, $stored);
            $readBack = ProjectedQuantity::normalise(
                get_post_meta($wcProductId, ProjectedQuantity::OWNED_META, true)
            );
            if ($readBack !== $stored) {
                delete_post_meta($wcProductId, ProjectedQuantity::OWNED_META);
                $problem[] = ProjectedQuantity::RECORD_NOT_STORED;
            }
        }

        $report = array_values(array_unique([...$held, ...$problem]));
        if ($report === []) {
            delete_post_meta($wcProductId, ProjectedQuantity::CONFLICT_META);
        } else {
            update_post_meta($wcProductId, ProjectedQuantity::CONFLICT_META, $report);
        }
    }

    /**
     * Writes down that the shop's own price was left alone, or clears it.
     *
     * A meta row and not only a return value, because the person who has to
     * act on it arrives on a later request: the review list and the health
     * page read it, and a value that lived only in one projection's return
     * would be gone by then. Cleared on the first projection that does carry
     * a price, so the row means «right now», never «once».
     */
    private function recordHeldPrice(int $wcProductId, bool $held): void
    {
        if ($held) {
            update_post_meta($wcProductId, self::PRICE_HELD_META, '1');
            return;
        }
        delete_post_meta($wcProductId, self::PRICE_HELD_META);
    }

    /**
     * Records that this projection left the product's status alone.
     *
     * Written AFTER the save, like every other stamp here, and deleted rather
     * than set to `'0'` when the hold is gone: a page asking «is the status
     * held» must not have to tell `'0'` from absent (`alpha.60`).
     */
    private function recordHeldStatus(int $wcProductId, bool $held): void
    {
        if ($held) {
            update_post_meta($wcProductId, self::STATUS_HELD_META, '1');
            return;
        }
        delete_post_meta($wcProductId, self::STATUS_HELD_META);
    }

    /**
     * One fact, under the key WooCommerce would give it.
     *
     * Returns a single-entry map rather than the object, so no caller can
     * compute the key a second way. `+=` on the caller's side then makes «a
     * label already used» keep the first answer instead of losing one
     * silently to an overwrite.
     *
     * @return array<string,\WC_Product_Attribute>
     */
    private function attribute(string $label, string $value, int $position): array
    {
        $attribute = new \WC_Product_Attribute();
        $attribute->set_name($label);
        $attribute->set_options([$value]);
        $attribute->set_position($position);
        $attribute->set_visible(true);
        $attribute->set_variation(false);
        return [ProjectedAttributes::keyFor($label) => $attribute];
    }

    private function wcAttributes(array $attributes): array
    {
        $out = [];
        foreach ($attributes as $index => $attribute) {
            if (!$attribute->isUsable()) {
                continue;
            }
            $wcAttribute = new \WC_Product_Attribute();
            $wcAttribute->set_name($attribute->label);
            $wcAttribute->set_options($attribute->options);
            $wcAttribute->set_position($index);
            $wcAttribute->set_visible(true);
            $wcAttribute->set_variation(true);
            // `+` on the caller's side gives the FIRST writer the key, and
            // `alpha.42` used it with the stored set on the left — so an old
            // attribute beat the new options and a removed one survived. The
            // left side here is this plugin's own data; the record in
            // `ProjectedAttributes` is what decides against the shop's.
            $out[ProjectedAttributes::keyFor($attribute->label)] = $wcAttribute;
        }
        return $out;
    }

    /**
     * @param list<ProductAttribute> $attributes
     * @param list<ProductVariation> $variations
     * @return array<int,int> tmc variation id => the storefront variation it became
     */
    private function projectVariations(int $wcProductId, Product $product, array $attributes, array $variations): array
    {
        $links = [];
        $labels = [];
        foreach ($attributes as $attribute) {
            $labels[$attribute->key] = $attribute->label;
        }
        $existing = $this->existingVariationIds($wcProductId);

        foreach ($variations as $variation) {
            $wcVariationId = $existing[$variation->id] ?? 0;
            $isNew = $wcVariationId <= 0;
            $wcVariation = $isNew ? new \WC_Product_Variation() : wc_get_product($wcVariationId);
            if (!$wcVariation instanceof \WC_Product_Variation) {
                $wcVariation = new \WC_Product_Variation();
                $isNew = true;
            }
            $wcVariation->set_parent_id($wcProductId);
            $wcVariation->set_status($variation->enabled ? 'publish' : 'private');
            $chosen = [];
            foreach ($variation->attributes as $key => $value) {
                $chosen[sanitize_title($labels[$key] ?? $key)] = $value;
            }
            $wcVariation->set_attributes($chosen);
            // THE SAME RULE AS THE PARENT'S, because it was the same defect.
            //
            // A guard on half a set is the same as no guard (`alpha.22`): a
            // manager who corrects one variation's price in WooCommerce has
            // done exactly what the owner said must be preserved, and these
            // two lines wrote over it on every projection just as the
            // parent's did. There is no weight here — `ProductVariation` has
            // none — so the merge is asked for two fields and the record is
            // stored without one.
            $variationWanted = [
                ShopEditMerge::PRICE => (string) $variation->priceMinor,
                ShopEditMerge::SKU => $variation->sku,
            ];
            $variationMerged = ProjectedShopFields::merge(
                ProjectedShopFields::shopValues($wcVariation, false),
                $variationWanted,
                $isNew ? [] : ProjectedShopFields::record($wcVariationId),
                $isNew
            );
            if ($variationMerged['may'][ShopEditMerge::PRICE]) {
                $wcVariation->set_regular_price((string) $variation->priceMinor);
                // The sale travels with the price, as it does on the parent:
                // a sale off a price somebody else set is a number nobody
                // decided.
                $wcVariation->set_sale_price($variation->salePriceMinor === null ? '' : (string) $variation->salePriceMinor);
            }
            if ($variation->sku !== '' && $variationMerged['may'][ShopEditMerge::SKU]) {
                try {
                    $wcVariation->set_sku($variation->sku);
                } catch (\Throwable) {
                    // keep whatever it had
                }
            }
            if ($variation->mediaId > 0) {
                $wcVariation->set_image_id($variation->mediaId);
            }
            $wcVariation->set_manage_stock(true);
            if ($isNew) {
                $wcVariation->set_stock_quantity($variation->stock);
                $wcVariation->set_stock_status($variation->stock > 0 ? 'instock' : 'outofstock');
            }
            try {
                $savedId = (int) $wcVariation->save();
            } catch (\Throwable) {
                continue;
            }
            if ($savedId > 0) {
                update_post_meta($savedId, self::VARIATION_META, $variation->id);
                update_post_meta($savedId, self::PRODUCT_META, $product->id);
                ProjectedShopFields::store(
                    $savedId,
                    $variationWanted,
                    $variationMerged['may'],
                    $variationMerged['report'],
                    false
                );
                $links[$variation->id] = $savedId;
                unset($existing[$variation->id]);
            }
        }

        // Combinations the vendor removed: hidden, not deleted, for the same
        // reason the parent is drafted rather than trashed.
        foreach ($existing as $staleWcId) {
            $stale = wc_get_product($staleWcId);
            if ($stale instanceof \WC_Product_Variation) {
                $stale->set_status('private');
                $stale->set_stock_status('outofstock');
                try {
                    $stale->save();
                } catch (\Throwable) {
                    continue;
                }
            }
        }
        \WC_Product_Variable::sync($wcProductId);
        return $links;
    }

    /** @return array<int,int> tmc variation id => WooCommerce variation id */
    private function existingVariationIds(int $wcProductId): array
    {
        $parent = wc_get_product($wcProductId);
        if (!$parent instanceof \WC_Product_Variable) {
            return [];
        }
        $out = [];
        foreach ($parent->get_children() as $childId) {
            $tmcId = (int) get_post_meta((int) $childId, self::VARIATION_META, true);
            if ($tmcId > 0) {
                $out[$tmcId] = (int) $childId;
            }
        }
        return $out;
    }
}
