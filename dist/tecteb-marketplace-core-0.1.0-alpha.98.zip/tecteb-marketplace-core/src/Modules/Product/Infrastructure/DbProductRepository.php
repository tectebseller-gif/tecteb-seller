<?php
declare(strict_types=1);

namespace Tecteb\Marketplace\Modules\Product\Infrastructure;

use Tecteb\Marketplace\Contracts\ClockInterface;
use Tecteb\Marketplace\Contracts\DatabaseInterface;
use Tecteb\Marketplace\Modules\Product\Application\ProductRepositoryInterface;
use Tecteb\Marketplace\Modules\Product\Domain\ApprovedBaseline;
use Tecteb\Marketplace\Modules\Product\Domain\Product;
use Tecteb\Marketplace\Modules\Product\Domain\PersianCollation;
use Tecteb\Marketplace\Modules\Product\Domain\ProductCreation;
use Tecteb\Marketplace\Modules\Product\Domain\CategorySet;
use Tecteb\Marketplace\Modules\Product\Domain\ProductDetails;
use Tecteb\Marketplace\Modules\Product\Domain\ProductSeo;
use Tecteb\Marketplace\Modules\Product\Domain\LinkOwnership;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRevision;
use Tecteb\Marketplace\Modules\Product\Domain\ProductSort;
use Tecteb\Marketplace\Modules\Product\Domain\ProductRowVersion;
use Tecteb\Marketplace\Modules\Product\Domain\ProductStatus;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0010LinkOwnership;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0019BaselineAndDecisions;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0023ProductDescriptionAndCreateToken;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0032ProductMirroredStatus;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0024PurchaseStep;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0035ProductCategorySet;
use Tecteb\Marketplace\Modules\Product\Infrastructure\WooCommerce\WpProductCategoryLinkReader;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0036DefaultCategoryAcceptance;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0025BrandRegistry;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0005CreateProductTables as T;
use Tecteb\Marketplace\Modules\Product\Infrastructure\Migrations\M0006CatalogAndOrders as C;

/**
 * Products on the plugin's own tables.
 *
 * `findOwned()` exists next to `find()` so the caller cannot forget the owner:
 * the vendor area calls the first, the manager's queue calls the second, and
 * a query that should have been scoped is visible as such when reading.
 */
final class DbProductRepository implements ProductRepositoryInterface
{
    /**
     * The scope every "is this ours?" query carries.
     *
     * Written as constants rather than repeated strings so that adding a
     * query which forgets the scope is a visible omission rather than an
     * invisible one.
     */
    private const OWNED = M0010LinkOwnership::COLUMN . " = '" . 'marketplace' . "'";
    private const OBSERVED = M0010LinkOwnership::COLUMN . " = '" . 'observed' . "'";

    /** One `information_schema` read for the whole request. */
    private ?ProductTableShape $shape = null;

    public function __construct(
        private readonly DatabaseInterface $db,
        private readonly ClockInterface $clock
    ) {
    }

    public function find(int $productId): ?Product
    {
        $row = $this->db->getRow('SELECT * FROM `' . $this->products() . '` WHERE id = %d', [$productId]);
        return $row === null ? null : $this->hydrate($row);
    }

    public function findOwned(int $productId, int $vendorUserId): ?Product
    {
        $row = $this->db->getRow(
            'SELECT * FROM `' . $this->products() . '` WHERE id = %d AND vendor_user_id = %d',
            [$productId, $vendorUserId]
        );
        return $row === null ? null : $this->hydrate($row);
    }

    public function findMany(array $productIds): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $productIds), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }
        $placeholders = implode(', ', array_fill(0, count($ids), '%d'));
        $out = [];
        foreach ($this->db->getResults(
            'SELECT * FROM `' . $this->products() . '` WHERE id IN (' . $placeholders . ')',
            $ids
        ) as $row) {
            $product = $this->hydrate($row);
            $out[$product->id] = $product;
        }
        return $out;
    }

    public function forVendor(
        int $vendorUserId,
        ?ProductStatus $status = null,
        int $limit = 200,
        int $offset = 0,
        string $search = ''
    ): array {
        [$where, $params] = $this->scope($vendorUserId, $status, $search);
        $params[] = max(1, $limit);
        $params[] = max(0, $offset);
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '`' . $where . ' ORDER BY updated_at DESC, id DESC LIMIT %d OFFSET %d',
            $params
        ));
    }

    public function countForVendor(int $vendorUserId, ?ProductStatus $status = null, string $search = ''): int
    {
        [$where, $params] = $this->scope($vendorUserId, $status, $search);
        return (int) $this->db->getVar('SELECT COUNT(*) FROM `' . $this->products() . '`' . $where, $params);
    }

    /**
     * The manager's catalogue: every product of every shop, filterable.
     *
     * Until now the only manager view was `inStatus(Submitted)`, so a product
     * that had been decided ANY way vanished from the marketplace side of the
     * admin while its WooCommerce post carried on existing. «محصول پس از
     * خروج از صف بررسی، از صفحهٔ مدیریت بازارگاه ناپدید می‌شود.»
     *
     * @return list<Product>
     */
    public function forManager(
        ?ProductStatus $status = null,
        string $search = '',
        int $limit = 20,
        int $offset = 0,
        int $vendorUserId = 0,
        ?ProductSort $sort = null,
        bool $onlyNeedsReview = false
    ): array {
        return array_column(
            $this->forManagerWithSubmission($status, $search, $limit, $offset, $vendorUserId, $sort, $onlyNeedsReview),
            'product'
        );
    }

    /**
     * The same page of rows, each with the identity of the submission on it.
     *
     * **One statement, and that is the whole point.** The red count is now per
     * manager and cleared by opening the list, so the page has to record WHICH
     * submission it showed. Read in a second query, that token could be newer
     * than the row above it — a vendor submitting between the two reads would
     * have their submission marked as seen by somebody who was looking at the
     * previous one. Selected here as part of the row, there is no «between».
     *
     * The token is the pair of append-only ids that ALREADY name a submission:
     * the newest `submitted` row in the decision trail, and the id of the
     * unanswered proposal. Neither is a timestamp and neither is the status, so
     * an ordinary edit — a price, a stock number, a title — does not move it,
     * and a resubmission always does.
     *
     * Both subqueries are correlated and indexed, and they run for the rows of
     * ONE page (`LIMIT` is in the statement), not for the catalogue.
     *
     * @return list<array{product:Product, submission:string}>
     */
    public function forManagerWithSubmission(
        ?ProductStatus $status = null,
        string $search = '',
        int $limit = 20,
        int $offset = 0,
        int $vendorUserId = 0,
        ?ProductSort $sort = null,
        bool $onlyNeedsReview = false
    ): array {
        [$where, $params] = $this->managerScope($status, $search, $vendorUserId, $onlyNeedsReview);
        [$columns, $columnParams] = ReviewQueueSql::submissionColumns($this->db);
        $params = array_merge($columnParams, $params);
        $params[] = max(1, $limit);
        $params[] = max(0, $offset);
        $rows = $this->db->getResults(
            'SELECT p.*, ' . $columns . ' FROM `' . $this->products() . '` p'
                . str_replace('`' . $this->products() . '`.', 'p.', $where)
                . ' ORDER BY ' . self::order($sort) . ' LIMIT %d OFFSET %d',
            $params
        );
        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'product' => $this->hydrate($row),
                'submission' => ReviewQueueSql::token($row),
            ];
        }
        return $out;
    }

    /**
     * One product, its pending proposal and its submission identity — together.
     *
     * **The detail page's half of the one-statement rule.** `alpha.36` read the
     * product with `find()`, the proposal with `pendingFor()` and the token with
     * `submissionsOf()`: three statements, and a submission landing between the
     * first and the third let the page show the previous content while recording
     * the newer identity as seen. Moving the token read a few lines up would not
     * have proved anything — the window is between two reads, wherever they sit.
     *
     * So the product row and the two append-only ids come back from ONE SELECT,
     * and `revisionId` names the exact proposal that identity refers to. The
     * caller loads that proposal BY ID: a revision row is append-only, so
     * fetching it by its own id returns the payload this token is about even if
     * a newer proposal has superseded it in the meantime — and that newer one
     * then carries a different token and is correctly still unseen.
     *
     * `waiting` comes out of the SAME statement, and it is what the caller
     * records on rather than the token. `s0.r0` is a REAL token — a product
     * submitted before the decision trail existed (`alpha.29`) has one — so
     * «is there a submission to have seen» cannot be answered by looking at the
     * token. It is answered by the queue predicate, read here, beside the row.
     * The detail page shows published products too, and those have nothing to
     * mark.
     *
     * @return array{product:Product, submission:string, revisionId:int, waiting:bool}|null
     */
    public function findWithSubmission(int $productId): ?array
    {
        if ($productId <= 0) {
            return null;
        }
        [$columns, $columnParams] = ReviewQueueSql::submissionColumns($this->db);
        [$waiting, $waitingParams] = ReviewQueueSql::waiting($this->db);
        $row = $this->db->getRow(
            'SELECT p.*, ' . $columns . ', ' . $waiting . ' AS tmc_waiting'
                . ' FROM `' . $this->products() . '` p WHERE p.id = %d',
            array_merge($columnParams, $waitingParams, [$productId])
        );
        if ($row === null) {
            return null;
        }
        return [
            'product' => $this->hydrate($row),
            'submission' => ReviewQueueSql::token($row),
            'revisionId' => (int) ($row['tmc_revision_id'] ?? 0),
            'waiting' => (int) ($row['tmc_waiting'] ?? 0) === 1,
        ];
    }

    /**
     * Which of these products are waiting, and under which submission.
     *
     * Used for the badge: the manager's recorded marks are the input, so the
     * query is bounded by how many things they have looked at rather than by
     * the size of the queue. A product that has LEFT the queue is simply absent
     * from the answer, which is what stops a decided product subtracting from a
     * count it is no longer part of.
     *
     * @param list<int> $productIds
     * @return array<int,string> product id => submission token
     */
    public function submissionsOf(array $productIds): array
    {
        $ids = array_values(array_unique(array_map('intval', $productIds)));
        $ids = array_values(array_filter($ids, static fn (int $id): bool => $id > 0));
        if ($ids === []) {
            // Asking the database about nothing is how an `IN ()` syntax error
            // reaches a page that had nothing to ask about (`alpha.32`).
            return [];
        }
        [$columns, $columnParams] = ReviewQueueSql::submissionColumns($this->db);
        [$waiting, $waitingParams] = ReviewQueueSql::waiting($this->db);
        $rows = $this->db->getResults(
            'SELECT p.id, ' . $columns . ' FROM `' . $this->products() . '` p'
                . ' WHERE p.id IN (' . implode(',', array_map('intval', $ids)) . ')'
                . ' AND ' . $waiting,
            array_merge($columnParams, $waitingParams)
        );
        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['id']] = ReviewQueueSql::token($row);
        }
        return $out;
    }

    public function countForManager(
        ?ProductStatus $status = null,
        string $search = '',
        int $vendorUserId = 0,
        bool $onlyNeedsReview = false
    ): int {
        [$where, $params] = $this->managerScope($status, $search, $vendorUserId, $onlyNeedsReview);
        return (int) $this->db->getVar('SELECT COUNT(*) FROM `' . $this->products() . '`' . $where, $params);
    }

    public function countAwaitingReview(): int
    {
        // One query, and one row per product: `OR EXISTS` rather than a union
        // of two counts, because a product that is both submitted and carries
        // a proposal would otherwise be counted twice and the badge would ask
        // the manager to find a decision that does not exist.
        [$waiting, $params] = ReviewQueueSql::waiting($this->db);
        return (int) $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` p WHERE ' . $waiting,
            $params
        );
    }

    /**
     * The ORDER BY for one sort case — a whitelist, and the only place in this
     * read where a column name comes from anything the request influenced.
     *
     * The fragment is built from the enum, never from the string that
     * arrived: `ProductSort::fromKey()` has already turned anything unknown
     * into the default, so no request value reaches SQL. Every case ends in
     * `id` because `updated_at` has second precision, and a page boundary
     * inside one second is one row shown twice and another never shown.
     */
    private static function order(?ProductSort $sort): string
    {
        return match ($sort ?? ProductSort::LastChanged) {
            ProductSort::OldestChanged => 'updated_at ASC, id ASC',
            // The stored key, not the title: ordering by the column itself is
            // the ARABIC alphabet, which puts پ چ ژ گ after ی (see
            // `PersianCollation`). The key is ASCII and the index is on
            // (title_sort, id), so this is one index scan over the whole
            // result — not a sort of the page, and not every row in PHP.
            ProductSort::Title => 'title_sort ASC, id ASC',
            ProductSort::LastChanged => 'updated_at DESC, id DESC',
        };
    }

    /**
     * How many products are in each status, across every shop.
     *
     * The same GROUP BY the vendor's own counters use, minus the owner
     * filter — one query, so the chips cannot disagree with each other.
     *
     * @return array<string,int>
     */
    public function countsByStatusForManager(
        string $search = '',
        int $vendorUserId = 0,
        bool $onlyNeedsReview = false
    ): array {
        [$where, $params] = $this->managerScope(null, $search, $vendorUserId, $onlyNeedsReview);
        $rows = $this->db->getResults(
            'SELECT status, COUNT(*) AS n FROM `' . $this->products() . '`' . $where . ' GROUP BY status',
            $params
        );
        $counts = [];
        foreach ($rows as $row) {
            $counts[(string) $row['status']] = (int) $row['n'];
        }
        return $counts;
    }

    /** @return array{0:string, 1:list<mixed>} */
    private function managerScope(
        ?ProductStatus $status,
        string $search,
        int $vendorUserId = 0,
        bool $onlyNeedsReview = false
    ): array {
        // `1 = 1` so every branch below can append with AND and the clause is
        // never empty — a `WHERE` with nothing after it is a syntax error and
        // an `if` on the first condition is how that gets forgotten.
        $where = ' WHERE 1 = 1';
        $params = [];
        if ($vendorUserId > 0) {
            $where .= ' AND vendor_user_id = %d';
            $params[] = $vendorUserId;
        }
        if ($status !== null) {
            $where .= ' AND status = %s';
            $params[] = $status->value;
        }
        $search = trim($search);
        if ($search !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
            $where .= ' AND (title LIKE %s OR sku LIKE %s OR brand LIKE %s)';
            array_push($params, $like, $like, $like);
        }
        if ($onlyNeedsReview) {
            // THE SAME FRAGMENT THE BADGE AND THE COUNTER USE, from
            // `alpha.48`. It was a hand-written `EXISTS` on pending revisions
            // alone, which made this filter one definition of «needs review»
            // and `countAwaitingReview()` another — and the owner's screen
            // showed both at once: «در انتظار بررسی ۰» above a published
            // product whose card said a proposal was waiting.
            //
            // The clause is the same WHERE as the list, so the chips, the
            // total and the pager are answers about one set of rows. A second
            // query that collected ids and handed them to an `IN (…)` would be
            // a second moment, and the number under the pager would disagree
            // with the rows above it the first time a vendor proposed a change
            // between the two.
            [$waiting, $waitingParams] = ReviewQueueSql::waiting($this->db, '`' . $this->products() . '`');
            $where .= ' AND ' . $waiting;
            array_push($params, ...$waitingParams);
        }
        return [$where, $params];
    }

    /**
     * One WHERE clause for the list and its count, so the number under the
     * pager can never disagree with the rows above it.
     *
     * The search term is escaped for LIKE before it becomes a parameter:
     * a `%` a vendor types is a percent sign they are looking for, not a
     * wildcard that quietly matches everything.
     *
     * @return array{0:string, 1:list<mixed>}
     */
    private function scope(int $vendorUserId, ?ProductStatus $status, string $search): array
    {
        $where = ' WHERE vendor_user_id = %d';
        $params = [$vendorUserId];
        if ($status !== null) {
            $where .= ' AND status = %s';
            $params[] = $status->value;
        }
        $search = trim($search);
        if ($search !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
            $where .= ' AND (title LIKE %s OR sku LIKE %s OR brand LIKE %s)';
            array_push($params, $like, $like, $like);
        }
        return [$where, $params];
    }

    public function countsByStatus(int $vendorUserId): array
    {
        $rows = $this->db->getResults(
            'SELECT status, COUNT(*) AS n FROM `' . $this->products() . '` WHERE vendor_user_id = %d GROUP BY status',
            [$vendorUserId]
        );
        $counts = [];
        foreach ($rows as $row) {
            $counts[(string) $row['status']] = (int) $row['n'];
        }
        return $counts;
    }

    public function inStatus(ProductStatus $status, int $limit = 200, int $offset = 0): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '` WHERE status = %s ORDER BY updated_at ASC, id ASC LIMIT %d OFFSET %d',
            [$status->value, max(1, $limit), max(0, $offset)]
        ));
    }

    public function countInStatus(ProductStatus $status): int
    {
        return (int) $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` WHERE status = %s',
            [$status->value]
        );
    }

    public function create(
        int $vendorUserId,
        ProductDetails $details,
        ProductStatus $status,
        LinkOwnership $ownership = LinkOwnership::Marketplace,
        ?int $wcProductId = null,
        string $importRunId = '',
        string $createToken = '',
        string $mirroredStatus = ''
    ): int {
        return $this->insertRow(
            $vendorUserId,
            $details,
            $status,
            $ownership,
            $wcProductId,
            $importRunId,
            $createToken,
            $mirroredStatus
        )->productId;
    }

    /**
     * The same insert, for the ONE caller that needs to know who made the row.
     *
     * The form path cannot act on an id alone: a refused insert resolves to a
     * row this request did not create, and writing the gallery and the
     * specifications over it is writing over the winner's work — or, on a
     * replay, over whatever the vendor has edited since. See
     * `ProductCreation`.
     */
    public function createForForm(
        int $vendorUserId,
        ProductDetails $details,
        ProductStatus $status,
        string $createToken
    ): ProductCreation {
        return $this->insertRow(
            $vendorUserId,
            $details,
            $status,
            LinkOwnership::Marketplace,
            null,
            '',
            $createToken,
            // The form path NEVER observes a storefront status: the product
            // does not exist in the shop yet, so its status is this
            // marketplace's own from the first byte.
            ''
        );
    }

    private function insertRow(
        int $vendorUserId,
        ProductDetails $details,
        ProductStatus $status,
        LinkOwnership $ownership,
        ?int $wcProductId,
        string $importRunId,
        string $createToken,
        string $mirroredStatus = ''
    ): ProductCreation {
        if (!$this->mayWrite()) {
            // NOT an id, and not a half-written row. The columns that are
            // wrong are named by `unsoundColumns()`; this is the floor under
            // every caller (`mayWrite()`).
            return ProductCreation::failed();
        }
        $now = $this->now();
        [$columns, $placeholders, $params] = $this->detailColumns($details);

        // The WooCommerce link and the import run go in THIS insert, not in an
        // UPDATE after it.
        //
        // The migration used to do three writes per product: create, stamp,
        // link. A process killed between the first and the third left a row
        // with `wc_product_id = NULL` — and NULL is invisible to both
        // `findByWcProduct()` and `findObservedByWcProduct()`, so the resumed
        // run judged that Dokan product «not imported yet» and made a SECOND
        // row. The unique key on `wc_product_id` could not stop it, because the
        // orphan's value was NULL and MySQL lets NULL repeat.
        //
        // Written together, the row either exists complete or does not exist:
        // there is no state in which it is half made. The resume then finds it
        // by its wc id and skips, and the unique key is a real second line of
        // defence rather than one the orphan slipped past.
        $extraColumns = [];
        $extraPlaceholders = [];
        $extraParams = [];
        if ($wcProductId !== null && $wcProductId > 0) {
            $extraColumns[] = 'wc_product_id';
            $extraPlaceholders[] = '%d';
            $extraParams[] = $wcProductId;
            $extraColumns[] = 'synced_at';
            $extraPlaceholders[] = '%s';
            $extraParams[] = $now;
        }
        if ($importRunId !== '') {
            $extraColumns[] = 'import_run_id';
            $extraPlaceholders[] = '%s';
            $extraParams[] = mb_substr($importRunId, 0, 64);
        }
        // The one-create-per-form token. Written in THIS insert and nowhere
        // else, so the unique key on `(vendor_user_id, create_token)` is what
        // decides — a replayed POST loses at the index rather than at a check
        // between a read and a write, which is a check two simultaneous
        // requests both pass. Left out when there is no token, so the column
        // stays NULL and cannot collide with any other row (the property
        // `wc_product_id` above relies on for exactly the same reason).
        if ($createToken !== '') {
            $extraColumns[] = M0023ProductDescriptionAndCreateToken::CREATE_TOKEN;
            $extraPlaceholders[] = '%s';
            $extraParams[] = mb_substr($createToken, 0, 64);
        }
        // THE OBSERVED STOREFRONT STATUS, in this insert and nowhere else.
        //
        // The same argument as the two above, and it bites harder: this value
        // is what stops the first projection overwriting a status nobody in
        // this marketplace decided. A row that exists without it for one
        // request is a row whose `pending` the next projection turns into
        // `draft` — measured on `alpha.66`. Left out entirely when there is
        // nothing to record, so the column stays NULL and «never observed»
        // is told apart from «observed as empty».
        if (trim($mirroredStatus) !== '') {
            $extraColumns[] = M0032ProductMirroredStatus::MIRRORED;
            $extraPlaceholders[] = '%s';
            $extraParams[] = mb_substr(trim($mirroredStatus), 0, 20);
        }

        $sql = 'INSERT INTO `' . $this->products() . '` (vendor_user_id, ' . implode(', ', $columns)
            . ', status, ' . M0010LinkOwnership::COLUMN
            . ($extraColumns === [] ? '' : ', ' . implode(', ', $extraColumns))
            . ', created_at, updated_at) VALUES (%d, '
            . implode(', ', $placeholders) . ', %s, %s'
            . ($extraPlaceholders === [] ? '' : ', ' . implode(', ', $extraPlaceholders))
            . ', %s, %s)';
        $ok = $this->db->execute(
            $sql,
            array_merge(
                [$vendorUserId],
                $params,
                [$status->value, $ownership->value],
                $extraParams,
                [$now, $now]
            )
        );
        if ($ok === null) {
            // A REFUSED INSERT IS NOT THE SAME AS NO ROW — the `alpha.28`
            // rule, and `alpha.39` paid for the other half of it. When a
            // token was given, the one thing that refuses this insert is its
            // unique key, which means THIS form has already created its
            // product: the replay's answer is that product, not a failure
            // about a product that exists. Asked of the data rather than
            // inferred from the error string.
            //
            // And `resolved`, not `made`: the row is somebody else's write.
            if ($createToken === '') {
                return ProductCreation::failed();
            }
            $existing = $this->findByCreateToken($vendorUserId, $createToken);
            return $existing > 0 ? ProductCreation::resolved($existing) : ProductCreation::failed();
        }
        // Connection-scoped, so two vendors inserting at the same moment
        // cannot be handed each other's id — which "ORDER BY id DESC" would.
        $made = (int) $this->db->getVar('SELECT LAST_INSERT_ID()');
        if ($made > 0) {
            // The set belongs to the row that was just made, so it is written
            // once that row has an id and not before. A create that carries
            // no categories writes no link rows — the same «absent is not
            // empty» rule the column itself follows.
            $this->syncCategorySet($made, $details);
            return ProductCreation::made($made);
        }
        return ProductCreation::failed();
    }

    /**
     * The product one submitted create form made, if it made one.
     *
     * Scoped to the vendor as well as the token: a token is a random string
     * from one vendor's form and has no business reaching another shop's row,
     * and the unique key is over both columns for the same reason.
     */
    public function findByCreateToken(int $vendorUserId, string $createToken): int
    {
        if (trim($createToken) === '') {
            return 0;
        }
        return (int) $this->db->getVar(
            'SELECT id FROM `' . $this->products() . '` WHERE vendor_user_id = %d AND `'
            . M0023ProductDescriptionAndCreateToken::CREATE_TOKEN . '` = %s',
            [$vendorUserId, mb_substr($createToken, 0, 64)]
        );
    }

    /**
     * Write the details, and — when a version is given — only if nobody else
     * has written since the caller read.
     *
     * The version belongs in the WHERE clause and nowhere else. `alpha.13`
     * compared it in PHP between a read and a write, which is a check two
     * concurrent editors both pass: both read version 4, both find it equal,
     * both write, and the second silently replaces the first. Here the database
     * decides, `row_version` moves by one in the same statement, and the loser
     * gets zero rows.
     *
     * An empty `$expectedVersion` skips the check. A form rendered by an older
     * build carries no version, and refusing those would break saving for
     * anybody mid-edit across an upgrade.
     */
    public function unsoundColumns(): array
    {
        return $this->shape()->unsoundColumns();
    }

    public function structureKnown(): bool
    {
        return $this->shape()->isKnown();
    }

    /**
     * The shape guard, built once and kept.
     *
     * Lazily, and on this object, so the one `information_schema` read is
     * shared by every write of the request — and so that a repository
     * constructed by a test that never writes costs nothing.
     */
    private function shape(): ProductTableShape
    {
        return $this->shape ??= new ProductTableShape($this->db, $this->products());
    }

    /**
     * The guard every write goes through, and the reason it is HERE.
     *
     * `ManageProducts` asks `unsoundColumns()` first and refuses with a
     * message that names the columns — which is where a person finds out. This
     * is the second half: a path that forgot to ask must still not be able to
     * store wrong data. The `alpha.45` finding is exactly that shape — the
     * migration's `verify()` refused the mis-shaped column and the product
     * write landed anyway, because nothing on the write path was asking.
     */
    private function mayWrite(): bool
    {
        // `isSound()` is KNOWN and nothing wrong in it. Until `alpha.49` the
        // unknown case answered true here and every write went through on a
        // question nobody could answer.
        return $this->shape()->isSound();
    }

    public function brandTermIdOf(int $productId): ?int
    {
        $value = $this->db->getVar(
            'SELECT `' . M0025BrandRegistry::BRAND_TERM . '` FROM `' . $this->products() . '` WHERE id = %d',
            [$productId]
        );
        return $value === null ? null : (int) $value;
    }

    public function setBrandTerm(int $productId, string $brand, ?int $termId): bool
    {
        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '`
                SET brand = %s, `' . M0025BrandRegistry::BRAND_TERM . '` = ' . ($termId === null ? 'NULL' : '%d') . ',
                    updated_at = %s, row_version = row_version + 1
              WHERE id = %d',
            $termId === null
                ? [$brand, $this->now(), $productId]
                : [$brand, $termId, $this->now(), $productId]
        );
        // `row_version = row_version + 1` changes a column on every write, so
        // zero rows means the id matched nothing — not «it already said that».
        return $written !== null && $written > 0;
    }

    public function updateDetails(int $productId, ProductDetails $details, string $expectedVersion = ''): bool
    {
        if (!$this->mayWrite()) {
            return false;
        }
        [$columns, $placeholders, $params] = $this->detailColumns($details);
        $assignments = [];
        foreach ($columns as $i => $column) {
            $assignments[] = $column . ' = ' . $placeholders[$i];
        }
        $params[] = $this->now();
        $params[] = $productId;

        // A token this layer cannot compare is a REFUSAL, never a waiver.
        // Until alpha.15 an empty or unrecognised token simply dropped the
        // guard and the write went through unchecked — which is the race the
        // counter exists to stop, reachable by any form that happened not to
        // carry a stamp.
        if (!ProductRowVersion::permitsWrite($expectedVersion)) {
            return false;
        }
        $guard = '';
        if (ProductRowVersion::isUsable($expectedVersion)) {
            $guard = ' AND row_version = %d';
            $params[] = (int) $expectedVersion;
        }

        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '`
             SET ' . implode(', ', $assignments) . ', updated_at = %s, row_version = row_version + 1
             WHERE id = %d' . $guard,
            $params
        );
        if ($written === null) {
            return false;                       // a real storage failure
        }
        if ($guard === '') {
            // AFTER the row, never before: a set written beside a detail
            // write that then loses its guard would record a relationship for
            // a change that did not happen.
            $this->syncCategorySet($productId, $details);
            return true;                        // unguarded: nothing to lose to
        }
        // `row_version = row_version + 1` changes a column on every guarded
        // write, so zero rows here really does mean «the WHERE did not match»
        // rather than the «nothing changed» ambiguity the job queue hit.
        if ($written > 0) {
            $this->syncCategorySet($productId, $details);
            return true;
        }
        return false;
    }

    public function bumpVersion(int $productId, string $expectedVersion): bool
    {
        // Same rule as `updateDetails()`. This used to answer «true — nothing
        // to check against», which let the revision path write a proposal on
        // top of somebody else's without ever looking.
        if (!ProductRowVersion::permitsWrite($expectedVersion)) {
            return false;
        }
        if (ProductRowVersion::isDeliberatelyUnguarded($expectedVersion)) {
            return true;
        }
        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '`
             SET row_version = row_version + 1, updated_at = %s
             WHERE id = %d AND row_version = %d',
            [$this->now(), $productId, (int) $expectedVersion]
        );
        return $written !== null && $written > 0;
    }

    public function rowVersion(int $productId): string
    {
        $value = $this->db->getVar(
            'SELECT row_version FROM `' . $this->products() . '` WHERE id = %d',
            [$productId]
        );
        return $value === null ? '' : (string) (int) $value;
    }

    public function stampImportRun(int $productId, string $runId): bool
    {
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET import_run_id = %s WHERE id = %d',
            [mb_substr($runId, 0, 64), $productId]
        ) !== null;
    }

    public function importRunIds(): array
    {
        return array_map(
            static fn (array $row): string => (string) $row['import_run_id'],
            $this->db->getResults(
                'SELECT DISTINCT import_run_id FROM `' . $this->products() . '`
                 WHERE import_run_id <> %s ORDER BY import_run_id DESC',
                ['']
            )
        );
    }

    public function duplicateWcMappings(int $limit = 50): array
    {
        $limit = max(1, min(500, $limit));
        return array_map(
            static fn (array $row): int => (int) $row['wc_product_id'],
            $this->db->getResults(
                'SELECT wc_product_id FROM `' . $this->products() . '`
                 WHERE wc_product_id IS NOT NULL AND wc_product_id > 0
                 GROUP BY wc_product_id HAVING COUNT(*) > 1
                 ORDER BY wc_product_id ASC LIMIT ' . $limit
            )
        );
    }

    public function idsFromImportRun(string $runId): array
    {
        if ($runId === '') {
            return [];
        }
        return array_map(
            static fn (array $row): int => (int) $row['id'],
            $this->db->getResults(
                'SELECT id FROM `' . $this->products() . '` WHERE import_run_id = %s ORDER BY id ASC',
                [$runId]
            )
        );
    }

    public function importedWithoutCategory(int $limit = 500): array
    {
        // THE SAME QUESTION ITS OWN TOTAL ASKS.
        //
        // ⛔ Until `alpha.87` this asked `category_key = ''` ALONE while
        // `countImportedWithoutCategory()` — the number the same card prints
        // beside this list, and the half the `categories_mapped` gate reads —
        // also asked `NOT EXISTS (<link row>)`. The two diverge on exactly one
        // shape, and it is the common one: `recordCategorySet()` writes the
        // single key only for a ONE-term set ({@see CategorySet::soleKey()},
        // deliberately — «اولین دسته را خودسرانه انتخاب نکن»), so a
        // multi-category product whose whole WooCommerce relationship IS
        // recorded keeps `category_key = ''` for ever and the key-only
        // predicate counted it as unanswered for ever.
        //
        // Measured on `alpha.86` from the post-import state: list 2 against a
        // total of 1, with the recorded product printed under «آنچه اعمال
        // نمی‌شود» as `unmapped`
        // (`docs/evidence/alpha86-category-gate/counters.txt`). A list and the
        // figure next to it have to answer one question, or the screen is
        // wrong however right each half is (`alpha.79`).
        // ⛔ ONE PREDICATE, BUILT IN ONE PLACE. Until `alpha.88` this method
        // and its own total each spelled the condition out, and `alpha.87`
        // had already paid for that once: a list and the figure beside it
        // have to answer one question, or the screen is wrong however right
        // each half is (`alpha.79`). Now the only way they can diverge is a
        // change to `withoutCategoryWhere()`, and
        // `OneWithoutCategoryPredicateTest` forbids either method from
        // writing the clause itself.
        $predicate = $this->withoutCategoryWhere('p');
        $sql = 'SELECT p.id, p.vendor_user_id, p.wc_product_id, p.title
                   FROM `' . $this->products() . '` p
                  WHERE ' . $predicate['sql']
            . ' ORDER BY p.id ASC LIMIT ' . max(1, min(1000, $limit));
        // ⛔ On a FAILED read (`null`) the clause is left off and every
        // key-empty row is listed. That is deliberate and it is not a claim:
        // the caller gets `-1` from `countImportedWithoutCategory()` in the
        // same breath, so `CategoryMapping::plan()` reports `finished = false`
        // and the screen says the count could not be read — and the WRITE is
        // guarded on its own (`setCategoryWhenEmpty()` refuses outright when
        // this read fails), so a row listed here by mistake still cannot be
        // written over.
        return array_map(
            static fn (array $row): array => [
                'id' => (int) $row['id'],
                'vendor_user_id' => (int) $row['vendor_user_id'],
                // NULL is possible on this column, and nought is the honest
                // reading: a row with no WooCommerce product behind it cannot
                // have its source category looked up, and the caller names it
                // rather than skipping it.
                'wc_product_id' => (int) ($row['wc_product_id'] ?? 0),
                'title' => (string) $row['title'],
            ],
            $this->db->getResults($sql, $predicate['params']) ?? []
        );
    }

    public function countImportedWithoutCategory(int $vendorUserId = 0): int
    {
        // «WITHOUT A CATEGORY» MEANS NEITHER THE KEY NOR THE SET SAYS ANYTHING.
        //
        // Until `alpha.81` this asked the key alone, and measured on that
        // package the gate read `waiting_total=0` while nine products had
        // their relationship recorded nowhere — the intake had quietly stored
        // the first id, so the column was non-empty and the counter was
        // satisfied. A product whose SET is recorded is answered; a product
        // with neither is not; and a row with a legacy slug key still counts
        // as answered, because that key is what the aliasing template
        // repository still understands.
        $predicate = $this->withoutCategoryWhere('p');
        if (!$predicate['readable']) {
            // A read this predicate depends on failed. `-1` keeps the gate
            // OPEN (`alpha.67`): nought here would read as «nothing left to
            // decide» about a statement that never ran.
            return -1;
        }
        $sql = 'SELECT COUNT(*) FROM `' . $this->products() . '` p
                 WHERE ' . $predicate['sql'];
        $params = $predicate['params'];
        if ($vendorUserId > 0) {
            $sql .= ' AND p.vendor_user_id = %d';
            $params[] = $vendorUserId;
        }
        $value = $this->db->getVar($sql, $params);
        // ⛔ A failed read is NOT nought here, and nought is «nothing left to
        // decide» — the exact reading that would close a gate on a statement
        // that never ran (`alpha.67`). `-1` is returned so the caller has to
        // look, and `MigrationCompleteness` keeps the gate OPEN on it.
        return $value === null ? -1 : (int) $value;
    }

    /**
     * «NEITHER THE KEY, NOR THE SET, NOR AN ACCEPTED DEFAULT TERM» — once.
     *
     * The single place the `categories_mapped` question is spelled out. Three
     * consumers read it and they must not be able to disagree: the list
     * ({@see self::importedWithoutCategory()}), the figure beside that list
     * ({@see self::countImportedWithoutCategory()}), and the gate in
     * `MigrationCompleteness::forVendor()` which reads that figure. «شمارنده،
     * فهرست محصولات و دروازهٔ `categories_mapped` باید یک منطق مشترک داشته
     * باشند» is therefore a property of there being one builder, not a rule
     * three methods keep.
     *
     * ⛔ **The acceptance clause is the owner's option ج, and it compares
     * TERM IDS rather than trusting a flag.** A live acceptance stops the row
     * counting only while BOTH halves still hold:
     *
     *  - the accepted term is still the shop's `default_product_cat`, so
     *    changing that setting in WooCommerce makes every acceptance stop
     *    counting by itself — no sweep, no stored copy to go stale;
     *  - and the product's `product_cat` set is still EXACTLY that one term,
     *    so attaching a real category makes the acceptance stop counting too.
     *
     * That is «اگر ترم محصول یا تنظیم پیش‌فرض تغییر کرد، تأیید قدیمی نباید
     * بی‌صدا معتبر بماند» written as a `WHERE` rather than as a cron job. In
     * both cases the product becomes `DEFINITE` on the screen and its own
     * relationship is recordable with one click, which is the state it should
     * have been in all along.
     *
     * ⛔ **And the two unreadable states answer differently, on purpose.**
     * An ABSENT acceptance table is schema 35: the feature does not exist, so
     * the clause is left off and this package behaves exactly as `alpha.88`
     * shipped — which is also what makes rolling back need no database work.
     * An UNREADABLE one is `readable = false`, which the count turns into
     * `-1` and the gate reads as «still open»: a statement that never ran
     * must never close a gate (`alpha.67`). The same split applies to the
     * link table, whose list half deliberately keeps `alpha.87`'s behaviour
     * of listing every key-empty row — the write is guarded on its own
     * ({@see self::setCategoryWhenEmpty()}), so a row listed by mistake still
     * cannot be written over.
     *
     * @return array{sql:string, params:list<mixed>, readable:bool}
     */
    private function withoutCategoryWhere(string $alias): array
    {
        $sql = $alias . '.import_run_id <> %s AND ' . $alias . '.category_key = %s';
        $params = ['', ''];
        $readable = true;

        $carried = $this->hasCategoryTable();
        if ($carried === null) {
            $readable = false;
        } elseif ($carried) {
            $sql .= ' AND NOT EXISTS (SELECT 1 FROM `' . $this->categoriesTable()
                . '` c WHERE c.product_id = ' . $alias . '.id)';
        }

        $accepted = $this->hasDefaultCategoryTable();
        $defaultTermId = $accepted === true ? WpProductCategoryLinkReader::readDefaultTermId() : 0;
        if ($accepted === null) {
            $readable = false;
        } elseif ($accepted && $defaultTermId > 0) {
            // ⛔ A term id of nought is «I could not read the setting», and
            // then the clause is left OFF rather than written with a value
            // that matches nothing: the gate stays open, which is the
            // recoverable direction, and the screen is not told that four
            // decisions were never taken.
            $table = M0036DefaultCategoryAcceptance::table($this->db);
            $rel = $this->db->prefix() . 'term_relationships';
            $tax = $this->db->prefix() . 'term_taxonomy';
            $sql .= ' AND NOT EXISTS (
                SELECT 1 FROM `' . $table . '` d
                 WHERE d.live_product_id = ' . $alias . '.id
                   AND d.term_id = %d
                   AND EXISTS (
                         SELECT 1 FROM `' . $rel . '` tr
                         INNER JOIN `' . $tax . '` tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                          WHERE tr.object_id = ' . $alias . '.wc_product_id
                            AND tt.taxonomy = \'product_cat\'
                            AND tt.term_id = d.term_id
                       )
                   AND NOT EXISTS (
                         SELECT 1 FROM `' . $rel . '` tr2
                         INNER JOIN `' . $tax . '` tt2 ON tt2.term_taxonomy_id = tr2.term_taxonomy_id
                          WHERE tr2.object_id = ' . $alias . '.wc_product_id
                            AND tt2.taxonomy = \'product_cat\'
                            AND tt2.term_id <> d.term_id
                       )
            )';
            $params[] = $defaultTermId;
        }

        return ['sql' => $sql, 'params' => $params, 'readable' => $readable];
    }

    /**
     * Whether acceptances can be read on this install, with three answers.
     *
     * Memoised like {@see self::hasCategoryTable()} and for the same reason,
     * including the half that matters: a FAILED read is not memoised, because
     * it is a reason to ask again rather than an answer to remember
     * (`alpha.49`).
     */
    private function hasDefaultCategoryTable(): ?bool
    {
        if ($this->defaultCategoryTable === null) {
            $answer = M0036DefaultCategoryAcceptance::carriedBy($this->db);
            if ($answer === null) {
                return null;
            }
            $this->defaultCategoryTable = $answer;
        }
        return $this->defaultCategoryTable;
    }

    public function countImportedWithoutCategorySet(): int
    {
        $carried = $this->hasCategoryTable();
        if ($carried !== true) {
            // Absent (schema 34) or unreadable — and both are «I could not
            // ask». Answering nought would say every imported row has a
            // recorded relationship, on an install where recording one is not
            // even possible yet.
            //
            // ⛔ And this guard is not what makes the ANSWER honest: with the
            // table gone the statement below fails and `getVar()` returns
            // null, so the method would answer `-1` either way. What it buys
            // is that a failing statement is never sent while an admin page is
            // rendering, because `wpdb` prints «WordPress database error» into
            // the response when it is (`alpha.68`). The answer is decided by
            // the `null` check at the end.
            return -1;
        }
        $value = $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` p
              WHERE p.import_run_id <> %s
                AND NOT EXISTS (
                    SELECT 1 FROM `' . $this->categoriesTable() . '` c WHERE c.product_id = p.id
                )',
            ['']
        );
        return $value === null ? -1 : (int) $value;
    }

    public function importedWithCategoryKeys(int $limit = 500, int $afterId = 0): array
    {
        return array_map(
            static fn (array $row): array => [
                'id' => (int) $row['id'],
                'vendor_user_id' => (int) $row['vendor_user_id'],
                // NULL is possible here, and nought is the honest reading: a
                // row with no WooCommerce product behind it has no
                // relationship to read, and the caller names it rather than
                // skipping it.
                'wc_product_id' => (int) ($row['wc_product_id'] ?? 0),
                'title' => (string) $row['title'],
                'category_key' => (string) ($row['category_key'] ?? ''),
            ],
            $this->db->getResults(
                'SELECT id, vendor_user_id, wc_product_id, title, category_key
                   FROM `' . $this->products() . '`
                  WHERE import_run_id <> %s AND id > %d
                  ORDER BY id ASC LIMIT ' . max(1, min(1000, $limit)),
                ['', max(0, $afterId)]
            )
        );
    }

    public function countImported(): int
    {
        $value = $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` WHERE import_run_id <> %s',
            ['']
        );
        return $value === null ? -1 : (int) $value;
    }

    public function recordMirroredStatusWhenAbsent(int $productId, string $storefrontStatus): bool
    {
        if (!$this->mayWrite()) {
            return false;
        }
        $storefrontStatus = trim($storefrontStatus);
        if ($storefrontStatus === '') {
            // The blank is what «no stamp» already means, so writing it would
            // be a no-op reporting success — and it is also what an
            // unreadable product hands back, which must never settle the
            // guard (`alpha.49`).
            return false;
        }
        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '`
                SET `' . M0032ProductMirroredStatus::MIRRORED . '` = %s
              WHERE id = %d
                AND `' . M0032ProductMirroredStatus::MIRRORED . '` IS NULL',
            [mb_substr($storefrontStatus, 0, 20), $productId]
        );
        // ⛔ Nought rows is TRUE here, and that needs saying because this
        // repository usually reads it the other way. The guarded `UPDATE`
        // matches nothing in exactly one case that matters — the row already
        // carries a stamp — and the caller's question is «does this row have
        // one», not «did I write it». `row_version` is deliberately NOT
        // bumped: this records an observation about somebody else's product,
        // not an edit to ours, and bumping it would make every open vendor
        // form on that product fail its optimistic-lock check (`alpha.44`).
        return $written !== null;
    }

    public function reconcileStatusToStorefront(
        int $productId,
        ProductStatus $target,
        ProductStatus $expectedStatus,
        string $expectedStamp
    ): bool {
        if (!$this->mayWrite()) {
            return false;
        }
        $expectedStamp = trim($expectedStamp);
        if ($expectedStamp === '') {
            // A blank expectation would make the stamp guard match nothing
            // AND would be indistinguishable from «this row has no stamp»,
            // which is the one case this path must never write. Refuse rather
            // than send a statement that cannot succeed (`alpha.49`).
            return false;
        }
        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '`
                SET status = %s, updated_at = %s, row_version = row_version + 1
              WHERE id = %d
                AND status = %s
                AND `' . M0032ProductMirroredStatus::MIRRORED . '` = %s',
            [
                $target->value,
                $this->now(),
                $productId,
                $expectedStatus->value,
                mb_substr($expectedStamp, 0, 20),
            ]
        );
        if ($written === null) {
            return false;                       // a real storage failure
        }
        // `row_version = row_version + 1` changes a column on every match, so
        // zero rows here really does mean the `WHERE` did not match — the
        // stamp was cleared by a manager's decision, or the status moved
        // under a vendor's submission, between the preview and the press.
        //
        // ⛔ And bumping `row_version` is not only for that. The status
        // decides which save path a vendor's form takes
        // (`ProductStatus::isEditableByVendor`), so a form opened while the
        // row said `draft` MUST fail its optimistic-lock check rather than
        // save in place against a product that is live. The opposite of
        // `recordMirroredStatusWhenAbsent`, which records an observation and
        // deliberately leaves the counter alone.
        return (int) $written === 1;
    }

    public function setCategoryWhenEmpty(int $productId, string $categoryKey): string
    {
        if (!$this->mayWrite()) {
            return 'storage_failed';
        }
        $categoryKey = trim($categoryKey);
        if ($categoryKey === '') {
            // The empty string is what this method exists to replace. Writing
            // it back would be a no-op that reported success.
            return 'bad_category';
        }
        // ⛔ A KEY MAY NOT CONTRADICT A RECORDED SET, AND THE CONDITION GOES
        // IN THE STATEMENT (`alpha.50`).
        //
        // The guard above — «the column is empty» — is satisfied by exactly
        // the product that must not be written: a multi-category row whose
        // whole WooCommerce relationship is recorded keeps
        // `category_key = ''`, because the single key is only written for a
        // one-term set. Measured on `alpha.86`: the mapped id landed beside a
        // recorded set that does not contain it — `key=[703]` against
        // `set=[701,702]` — so the key then NAMED a category the product does
        // not have, which the medical spec template (`findByCategory()`) and
        // the review card both read.
        //
        // ⛔ And the refusal is the CONTRADICTION, not «a set is recorded».
        // The first version of this guard refused whenever any link row
        // existed, and `CategoryLinkFlowTest` caught it: a set of exactly
        // `{X}` with the matching key is the state migration 35's backfill
        // leaves, and writing `X` there agrees with it rather than fighting
        // it. A guard wider than the defect is worse than the defect
        // (`alpha.60`). So what is refused is a recorded id this key is NOT.
        //
        // A key that is not all digits can never be a term id, so `0` is the
        // comparison value and every recorded row then contradicts it —
        // which is the honest answer for a pre-`alpha.25` slug sitting beside
        // a real relationship.
        //
        // And a FAILED read is refused rather than written through: refusing a
        // mapping is recoverable, writing a key that contradicts a set nobody
        // could read is not.
        $carried = $this->hasCategoryTable();
        if ($carried === null) {
            return 'category_table_unreadable';
        }
        $asTerm = ctype_digit($categoryKey) ? (int) $categoryKey : 0;
        $written = $this->db->execute(
            'UPDATE `' . $this->products() . '` p
                SET p.category_key = %s, p.updated_at = %s, p.row_version = p.row_version + 1
              WHERE p.id = %d AND p.import_run_id <> %s AND p.category_key = %s'
            . ($carried
                ? ' AND NOT EXISTS (SELECT 1 FROM `' . $this->categoriesTable()
                    . '` c WHERE c.product_id = p.id AND c.term_id <> ' . $asTerm . ')'
                : ''),
            [$categoryKey, $this->now(), $productId, '', '']
        );
        if ($written === null) {
            return 'storage_failed';
        }
        if ($written > 0) {
            return '';
        }
        // Zero rows, and `row_version = row_version + 1` means that really is
        // «the WHERE did not match» rather than «nothing changed». Which half
        // it is has to be READ, because the two are opposite answers — and the
        // row is re-read rather than guessed (`alpha.28`).
        $row = $this->db->getResults(
            'SELECT category_key, import_run_id FROM `' . $this->products() . '` WHERE id = %d',
            [$productId]
        );
        if ($row === null) {
            // The re-read itself failed, so which half it was is unknown —
            // and `getResults()` answers «no rows» and «the read failed»
            // alike (`alpha.8`). Saying `not_found` here would report a
            // missing product on a database that simply did not answer.
            return 'storage_failed';
        }
        if ($row === []) {
            return 'not_found';
        }
        if ((string) $row[0]['import_run_id'] === '') {
            // Not an imported row at all. Its empty category is the vendor's
            // to fill on their own form; no migration decision reaches it.
            return 'not_imported';
        }
        if ((string) $row[0]['category_key'] !== '') {
            return 'already_set';
        }
        // The key is STILL empty, so the clause that refused was the new one:
        // this product's own relationship is already recorded, and that is a
        // named answer rather than a failure.
        $recorded = $carried
            ? $this->db->getVar(
                'SELECT COUNT(*) FROM `' . $this->categoriesTable() . '`
                  WHERE product_id = %d AND term_id <> %d',
                [$productId, $asTerm]
            )
            : '0';
        if ($recorded === null) {
            return 'storage_failed';
        }
        return (int) $recorded > 0 ? 'category_set_recorded' : 'storage_failed';
    }

    /**
     * Record a product's whole relationship — but only on an imported row
     * that has nothing recorded and no single key a human has set.
     *
     * The set sibling of `setCategoryWhenEmpty()`, and it keeps that method's
     * properties, which is why it is here rather than built out of it:
     *
     *  1. **Nothing a manager recorded is replaced.** A recorded set that is
     *     not contained in the incoming one is REFUSED by name
     *     (`category_set_decided`) — «دسته‌ای که مدیر قبلاً صریحاً تعیین کرده
     *     بدون تأیید بازنویسی نشود.»
     *  2. **A recorded set may be COMPLETED, because completing only adds.**
     *     ⛔ This is not a softening; it is what the upgrade makes necessary.
     *     Migration 35 backfills one row from `category_key`, and on staging
     *     that key is `category_ids[0]` — so the owner's nine products arrive
     *     here with `{244}` recorded and `{244,245}` on the product. Refusing
     *     that as «already decided» would leave exactly the products this
     *     round exists for unrecordable, and «مدیر نباید مجبور به انتخاب
     *     مجدد دسته‌های موجود شود». Nothing is ever deleted: a strict subset
     *     gains its missing ids and no row is removed.
     *  3. **Zero rows is read, not guessed** (`alpha.28`): «no row matched»
     *     has two opposite halves and they get different answers.
     *
     * ⛔ **The recorded set is read INSIDE the transaction, with a locking
     * read** (`alpha.64`): the decision «is this a completion or somebody
     * else's decision?» cannot be taken on a value read before the lock. The
     * count comes back in the same row as the ids, because `getResults()`
     * cannot tell «no rows» from «the read failed» (`alpha.8`) and here those
     * are opposite answers — an unreadable set must never be treated as an
     * empty one.
     *
     * ⛔ **And the single key is left ALONE when it already carries one.**
     * `category_key` is written only when it is empty (the condition is in the
     * statement), so the legacy key the pre-`alpha.82` intake stored survives
     * this call untouched. Clearing it would change which spec template that
     * product is held to — and which category's template applies to a
     * multi-category product is the owner's open decision, which this method
     * is not allowed to take (`docs/open-decisions-alpha82.md` §1). For a
     * fresh row with no key and several categories the key stays `''`, which
     * is `CategorySet::soleKey()` saying «there is no single key».
     *
     * @param list<int> $termIds
     */
    public function recordCategorySet(int $productId, array $termIds): string
    {
        if (!$this->mayWrite()) {
            return 'storage_failed';
        }
        $ids = CategorySet::of($termIds);
        if ($productId <= 0 || $ids === []) {
            // Writing an empty set back is a no-op that would report success,
            // the same reason `setCategoryWhenEmpty()` refuses an empty key.
            return 'bad_category';
        }
        $carried = $this->hasCategoryTable();
        if ($carried === null) {
            return 'category_table_unreadable';
        }
        if ($carried === false) {
            return 'category_set_unsupported';
        }
        if (!$this->db->begin()) {
            return 'not_atomic';
        }
        $table = $this->categoriesTable();
        $products = $this->products();

        // THE LOCKING READ, and it is the first statement of the transaction.
        // Everything below depends on what is recorded right now, and on an
        // empty set the gap lock is what makes a concurrent writer wait rather
        // than interleave.
        $locked = $this->db->getResults(
            'SELECT COUNT(*) AS n, GROUP_CONCAT(term_id) AS ids
               FROM `' . $table . '` WHERE product_id = %d FOR UPDATE',
            [$productId]
        );
        if ($locked === null || $locked === []) {
            $this->db->rollback();
            return 'storage_failed';
        }
        $recorded = CategorySet::fromValue((string) ($locked[0]['ids'] ?? ''));
        if (CategorySet::same($recorded, $ids)) {
            $this->db->rollback();
            return 'already_set';
        }
        if (CategorySet::lost($recorded, $ids) !== []) {
            // An id is recorded that this product does not carry: somebody
            // filed it there on purpose. Refused, named, and nothing written.
            $this->db->rollback();
            return 'category_set_decided';
        }

        // THE FIRST MISSING ID IS THE CLAIM, and both of its conditions are
        // INSIDE the statement (`alpha.50`, `alpha.54`): the row must be an
        // imported one, and NO id may be recorded for it that this set does
        // not contain. The locking read above orders two writers; this is what
        // makes the loser lose at the database rather than at a check.
        //
        // Measured consequence of having both: A recording {244,245} and B
        // recording {244,246} off the same `{244}` cannot merge into
        // {244,245,246}. Whichever claims first leaves an id the other's
        // `NOT IN` refuses, so the second gets `category_set_decided` and
        // writes nothing.
        //
        // `FROM DUAL` and not a derived table of all the rows: a derived table
        // names its columns after their VALUES, so a set whose term id equals
        // its sort order would produce two columns of the same name and the
        // statement would fail — on some products and not others.
        $missing = array_values(array_diff($ids, $recorded));
        $placeholders = implode(', ', array_fill(0, count($ids), '%d'));
        $claimed = $this->db->execute(
            'INSERT INTO `' . $table . '` (product_id, term_id, sort_order)
             SELECT %d, %d, %d FROM DUAL
              WHERE EXISTS (
                    SELECT 1 FROM `' . $products . '`
                     WHERE id = %d AND import_run_id <> %s
              )
                AND NOT EXISTS (
                    SELECT 1 FROM `' . $table . '` t
                     WHERE t.product_id = %d AND t.term_id NOT IN (' . $placeholders . ')
              )',
            array_merge(
                [
                    $productId,
                    $missing[0],
                    (int) array_search($missing[0], $ids, true),
                    $productId,
                    '',
                    $productId,
                ],
                $ids
            )
        );
        if ($claimed === null) {
            $this->db->rollback();
            return 'storage_failed';
        }
        if ($claimed < 1) {
            $this->db->rollback();
            // Zero rows, and which of the three it was has to be READ rather
            // than guessed (`alpha.28`): «not an imported row», «there is no
            // such row», and «somebody recorded a set of their own in between»
            // are three different answers and none of them is a failure.
            $row = $this->db->getResults(
                'SELECT import_run_id FROM `' . $products . '` WHERE id = %d',
                [$productId]
            );
            if ($row === null) {
                return 'storage_failed';
            }
            if ($row === []) {
                return 'not_found';
            }
            if ((string) $row[0]['import_run_id'] === '') {
                return 'not_imported';
            }
            return 'category_set_decided';
        }

        // The rest of the missing ids, inside the same transaction, because
        // the claim already decided who is writing. `IGNORE` against the PAIR
        // key, so nothing is overwritten and `sort_order` keeps the set's own
        // order.
        foreach (array_slice($missing, 1) as $termId) {
            if ($this->db->execute(
                'INSERT IGNORE INTO `' . $table . '` (product_id, term_id, sort_order)
                 VALUES (%d, %d, %d)',
                [$productId, $termId, (int) array_search($termId, $ids, true)]
            ) === null) {
                $this->db->rollback();
                return 'storage_failed';
            }
        }

        // The single key, and only into an EMPTY one. Its own guard stays in
        // the statement: a key anybody set — a manager, or the older intake —
        // is never replaced here.
        $sole = CategorySet::soleKey($ids);
        if ($sole !== '') {
            $stamped = $this->db->execute(
                'UPDATE `' . $products . '`
                    SET category_key = %s, updated_at = %s, row_version = row_version + 1
                  WHERE id = %d AND import_run_id <> %s AND category_key = %s',
                [$sole, $this->now(), $productId, '', '']
            );
            if ($stamped === null) {
                $this->db->rollback();
                return 'storage_failed';
            }
        }
        return $this->db->commit() ? 'category_set_written' : 'storage_failed';
    }

    public function observedFromImportRuns(int $limit = 200): array
    {
        return array_map(
            static fn (array $row): int => (int) $row['id'],
            $this->db->getResults(
                'SELECT id FROM `' . $this->products() . '`
                  WHERE import_run_id <> %s AND `' . M0010LinkOwnership::COLUMN . '` = %s
                  ORDER BY id ASC LIMIT ' . max(1, min(500, $limit)),
                ['', LinkOwnership::Observed->value]
            )
        );
    }

    public function vendorsFromImportRuns(): array
    {
        return array_map(
            static fn (array $row): int => (int) $row['vendor_user_id'],
            $this->db->getResults(
                'SELECT DISTINCT vendor_user_id FROM `' . $this->products() . '`
                 WHERE import_run_id <> %s ORDER BY vendor_user_id ASC',
                ['']
            )
        );
    }

    public function updateStatus(int $productId, ProductStatus $status, string $reviewNote = ''): bool
    {
        $published = $status === ProductStatus::Published ? '%s' : 'published_at';
        $params = [$status->value, $reviewNote];
        if ($status === ProductStatus::Published) {
            $params[] = $this->now();
        }
        $params[] = $this->now();
        $params[] = $productId;
        // The hold goes in the SAME statement as the status. A transition
        // whose second half failed would leave a status this marketplace
        // decided beside a hold that stops it being written — the third value
        // `alpha.61` is about, and here it would mean a manager pressing
        // «منتشر کن» and nothing reaching the shop, for ever.
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET status = %s, review_note = %s, published_at = ' . $published
            . ', `' . M0032ProductMirroredStatus::MIRRORED . '` = NULL'
            . ', updated_at = %s WHERE id = %d',
            $params
        ) !== null;
    }

    public function updatePrice(
        int $productId,
        int $priceMinor,
        ?int $salePriceMinor,
        ?string $saleFrom,
        ?string $saleTo
    ): bool {
        if (!$this->mayWrite()) {
            return false;
        }
        // The four columns in ONE statement, for the reason the interface
        // gives: a sale left behind by a half-written price is a number
        // nobody decided. `NULL` is spelled into the SQL rather than bound,
        // because the placeholder would make it the string `''` — and for
        // `sale_price_minor` an empty string is a PRICE OF ZERO, which is the
        // `alpha.28` fault with money in it.
        $sale = $salePriceMinor === null ? 'NULL' : '%d';
        $from = $saleFrom === null ? 'NULL' : '%s';
        $to = $saleTo === null ? 'NULL' : '%s';
        $params = [$priceMinor];
        if ($salePriceMinor !== null) {
            $params[] = $salePriceMinor;
        }
        if ($saleFrom !== null) {
            $params[] = $saleFrom;
        }
        if ($saleTo !== null) {
            $params[] = $saleTo;
        }
        $params[] = $this->now();
        $params[] = $productId;
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET price_minor = %d, sale_price_minor = ' . $sale
            . ', sale_from = ' . $from . ', sale_to = ' . $to
            . ', updated_at = %s WHERE id = %d',
            $params
        ) !== null;
    }

    public function updateInventory(
        int $productId,
        int $stock,
        string $sku,
        int $minPurchase,
        ?int $maxPurchase,
        int $purchaseStep = 1
    ): bool {
        if (!$this->mayWrite()) {
            return false;
        }
        $max = $maxPurchase === null ? 'NULL' : '%d';
        $params = [$stock, $sku, $minPurchase];
        if ($maxPurchase !== null) {
            $params[] = $maxPurchase;
        }
        // The step is on the IMMEDIATE side with the two numbers it works
        // with. Writing the minimum and the maximum now and queueing the step
        // for approval would leave the three in a combination the vendor never
        // asked for — «between 2 and 10, in threes» becoming «between 2 and
        // 10, any quantity» until a manager got to it.
        $params[] = max(1, $purchaseStep);
        $params[] = $this->now();
        $params[] = $productId;
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET stock = %d, sku = %s, min_purchase = %d, max_purchase = ' . $max
            . ', `' . M0024PurchaseStep::STEP . '` = %d, updated_at = %s WHERE id = %d',
            $params
        ) !== null;
    }

    /**
     * The medical answers, together or not at all.
     *
     * The same rule as the gallery, one step down: this one always reported a
     * failure honestly, but it could still leave three fields new and two old
     * and the schema version bumped over the mixture. A caller putting the
     * previous values back has enough to do without having to guess which
     * half of them are already there.
     */
    public function saveSpecs(int $productId, array $values, int $schemaVersion): bool
    {
        $now = $this->now();
        if (!$this->db->begin()) {
            return false;
        }
        foreach ($values as $key => $value) {
            $written = $this->db->execute(
                'INSERT INTO `' . $this->specsTable() . '` (product_id, field_key, value, schema_version, updated_at)
                 VALUES (%d, %s, %s, %d, %s)
                 ON DUPLICATE KEY UPDATE value = VALUES(value), schema_version = VALUES(schema_version), updated_at = VALUES(updated_at)',
                [$productId, (string) $key, (string) $value, $schemaVersion, $now]
            );
            if ($written === null) {
                $this->db->rollback();
                return false;
            }
        }
        $bumped = $this->db->execute(
            'UPDATE `' . $this->products() . '` SET spec_schema_version = %d, updated_at = %s WHERE id = %d',
            [$schemaVersion, $now, $productId]
        );
        if ($bumped === null) {
            $this->db->rollback();
            return false;
        }
        return $this->db->commit();
    }

    public function specs(int $productId): array
    {
        $rows = $this->db->getResults(
            'SELECT field_key, value FROM `' . $this->specsTable() . '` WHERE product_id = %d',
            [$productId]
        );
        $values = [];
        foreach ($rows as $row) {
            $values[(string) $row['field_key']] = (string) ($row['value'] ?? '');
        }
        return $values;
    }

    /**
     * Images are replaced as a set: the gallery the vendor just arranged IS
     * the gallery, so a removed picture disappears instead of lingering
     * because no DELETE matched it. The media items themselves are untouched.
     */
    /**
     * Replace the gallery — all of it, or none of it.
     *
     * This is a REPLACEMENT built out of a `DELETE` and a row per picture, and
     * until `alpha.31` the `DELETE`'s answer was thrown away. Two ways that
     * went wrong, and the first one is the worse:
     *
     *   * the delete fails, the inserts go ahead, and the product ends up with
     *     the old pictures AND the new ones — in a sort order they now share,
     *     so even «which is first» is a coin toss. And the method returned
     *     `true`, so nothing anywhere knew;
     *   * an insert fails halfway, and the gallery is left holding a piece of
     *     the new list with the old one already gone.
     *
     * A transaction is the answer to both, and this is what
     * `DatabaseInterface` grew one for in `alpha.20`. Every step is checked
     * against `null` — `0` rows is a SUCCESS (`alpha.8`'s rule) and a product
     * whose gallery was already empty deletes nothing.
     */
    public function saveImages(int $productId, array $mediaIds, int $mainImageId): bool
    {
        if (!$this->db->begin()) {
            return false;
        }
        if ($this->db->execute('DELETE FROM `' . $this->imagesTable() . '` WHERE product_id = %d', [$productId]) === null) {
            $this->db->rollback();
            return false;
        }
        foreach (array_values($mediaIds) as $sort => $mediaId) {
            $written = $this->db->execute(
                'INSERT INTO `' . $this->imagesTable() . '` (product_id, media_id, sort_order) VALUES (%d, %d, %d)
                 ON DUPLICATE KEY UPDATE sort_order = VALUES(sort_order)',
                [$productId, (int) $mediaId, (int) $sort]
            );
            if ($written === null) {
                $this->db->rollback();
                return false;
            }
        }
        $main = $this->db->execute(
            'UPDATE `' . $this->products() . '` SET main_image_id = %d, updated_at = %s WHERE id = %d',
            [$mainImageId, $this->now(), $productId]
        );
        if ($main === null) {
            $this->db->rollback();
            return false;
        }
        return $this->db->commit();
    }

    /**
     * The link table's name, and whether this database has it.
     *
     * Memoised PER INSTANCE and not statically: a static memo covers the whole
     * process, so a test that changes the table's shape and asks again gets
     * the stale answer — `alpha.67`'s trap, one table over.
     */
    private ?bool $categoryTable = null;

    /** Three answers, like the one above: present, absent, or unread. */
    private ?bool $defaultCategoryTable = null;

    private function categoriesTable(): string
    {
        return M0035ProductCategorySet::table($this->db);
    }

    /**
     * @return bool|null true present, false absent, null the read failed
     */
    private function hasCategoryTable(): ?bool
    {
        if ($this->categoryTable === null) {
            $answer = M0035ProductCategorySet::carriedBy($this->db);
            if ($answer === null) {
                // NOT memoised. A failed read is a reason to ask again, not an
                // answer to remember (`alpha.49`).
                return null;
            }
            $this->categoryTable = $answer;
        }
        return $this->categoryTable;
    }

    /**
     * Every `product_cat` term recorded for this product.
     *
     * Three answers, and the third one matters: `null` means the question
     * could not be asked — the table is not there yet, or the read failed —
     * and the caller must then fall back to the single key rather than treat
     * the relationship as empty. An empty ARRAY means the table was read and
     * holds nothing for this product, which is «not recorded», still not «no
     * categories» (`alpha.8`).
     *
     * @return list<int>|null
     */
    public function categoryIdsFor(int $productId): ?array
    {
        if ($productId <= 0 || $this->hasCategoryTable() !== true) {
            return null;
        }
        $rows = $this->db->getResults(
            'SELECT term_id FROM `' . $this->categoriesTable() . '`
              WHERE product_id = %d ORDER BY sort_order ASC, term_id ASC',
            [$productId]
        );
        if ($rows === null) {
            return null;
        }
        return CategorySet::of(array_map(static fn (array $row): int => (int) $row['term_id'], $rows));
    }

    /**
     * Replace the recorded set for this product, as ONE unit of work.
     *
     * The shape `saveImages()` was given in `alpha.31`, for the same reason:
     * a replacement is a delete and some inserts, and a delete that succeeds
     * beside an insert that fails leaves a relationship nobody asked for. So
     * the transaction is opened FIRST and a build that cannot open one is
     * refused by name rather than writing the first half.
     *
     * ⛔ **An empty set is refused, not written.** «هیچ رابطه‌ای خودکار حذف
     * نشود»: clearing a product's recorded categories is a decision, and no
     * path in this package takes it. Every ordinary save that happens to carry
     * nothing leaves what is recorded alone.
     *
     * The refusal is UNCONDITIONAL, and it used not to be: a `$allowEmpty`
     * parameter stood here for «a caller that means it» and **no caller ever
     * passed it** — so the exception existed only in this signature.
     * `alpha.80`'s rule says that is not a capability, and the cost of
     * pretending otherwise is specific: `syncCategorySet()` below returns
     * early on an empty set too, so a mutation that removed this refusal
     * changed nothing observable and the round's falsification reported it as
     * «survived». Two guards reading as one is how a guard stops being
     * measured. What it would take to clear a relationship on purpose is
     * `docs/open-decisions-alpha82.md` §2, and it is not answered here.
     *
     * @param list<int> $termIds
     * @return string '' on success, otherwise a named refusal
     */
    public function saveCategorySet(int $productId, array $termIds): string
    {
        if ($productId <= 0) {
            return 'bad_product';
        }
        $carried = $this->hasCategoryTable();
        if ($carried === null) {
            return 'category_table_unreadable';
        }
        if ($carried === false) {
            // Running on schema 34. Reading still works (the single key), and
            // writing a SET is refused by name rather than silently dropped —
            // `alpha.67`'s rule: the read falls back, the write refuses.
            return 'category_set_unsupported';
        }
        $ids = CategorySet::of($termIds);
        if ($ids === []) {
            return 'category_set_empty';
        }
        if (!$this->db->begin()) {
            return 'not_atomic';
        }
        if ($this->db->execute(
            'DELETE FROM `' . $this->categoriesTable() . '` WHERE product_id = %d',
            [$productId]
        ) === null) {
            $this->db->rollback();
            return 'storage_failed';
        }
        foreach ($ids as $sort => $termId) {
            if ($this->db->execute(
                'INSERT INTO `' . $this->categoriesTable() . '` (product_id, term_id, sort_order)
                 VALUES (%d, %d, %d) ON DUPLICATE KEY UPDATE sort_order = VALUES(sort_order)',
                [$productId, $termId, $sort]
            ) === null) {
                $this->db->rollback();
                return 'storage_failed';
            }
        }
        return $this->db->commit() ? '' : 'storage_failed';
    }

    /**
     * Keep the recorded set in step with a detail write that just happened.
     *
     * The invariant this maintains: whenever `category_key` is written, the
     * set says the same thing — otherwise a vendor who moves a single-category
     * product from one category to another would leave the OLD id recorded,
     * and every later read of the set would hand back a relationship nobody
     * has.
     *
     * It is deliberately one-directional. A caller carrying a set writes that
     * set; a caller carrying only the old single key writes `[that key]`; and
     * a caller carrying NEITHER writes nothing at all, because «this form said
     * nothing about categories» must not erase what is recorded. That is the
     * direction the owner's instruction makes mandatory, and it is also the
     * only direction in which being wrong is recoverable.
     */
    private function syncCategorySet(int $productId, ProductDetails $details): void
    {
        $ids = $details->categoryIds !== []
            ? CategorySet::of($details->categoryIds)
            : CategorySet::of([$details->categoryKey]);
        if ($ids === []) {
            return;
        }
        $this->saveCategorySet($productId, $ids);
    }

    /**
     * The recorded sets for a page of products, in ONE read.
     *
     * The plan classifies up to five hundred rows and has to know, for each,
     * whether its relationship is already recorded — and asking per row is
     * five hundred queries on a screen that already reads its links in one
     * (`alpha.81`). `null` means the question could not be asked at all, and
     * the caller must then fall back rather than treat every row as unrecorded.
     *
     * @param list<int> $productIds
     * @return array<int,list<int>>|null keyed by product id; a product with no
     *         rows is simply absent from the map
     */
    public function categorySetsFor(array $productIds): ?array
    {
        $ids = [];
        foreach ($productIds as $id) {
            $id = (int) $id;
            if ($id > 0 && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        if ($ids === []) {
            return [];
        }
        if ($this->hasCategoryTable() !== true) {
            return null;
        }
        $rows = $this->db->getResults(
            'SELECT product_id, term_id FROM `' . $this->categoriesTable() . '`
              WHERE product_id IN (' . implode(', ', array_fill(0, count($ids), '%d')) . ')
              ORDER BY product_id ASC, sort_order ASC, term_id ASC',
            $ids
        );
        if ($rows === null) {
            return null;
        }
        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['product_id']][] = (int) $row['term_id'];
        }
        foreach ($out as $productId => $terms) {
            $out[$productId] = CategorySet::of($terms);
        }
        return $out;
    }

    public function images(int $productId): array
    {
        $rows = $this->db->getResults(
            'SELECT media_id FROM `' . $this->imagesTable() . '` WHERE product_id = %d ORDER BY sort_order ASC, id ASC',
            [$productId]
        );
        return array_map(static fn (array $row): int => (int) $row['media_id'], $rows);
    }

    public function mediaInUse(int $mediaId): bool
    {
        if ($mediaId <= 0) {
            return false;
        }
        // Three places an attachment is referenced, and all three are asked.
        // Two of them would be easy to forget: a product's FEATURED picture
        // is a column on the product row, not a gallery row, and a
        // variation's picture is a column on the variation.
        $counts = [
            'SELECT COUNT(*) FROM `' . $this->imagesTable() . '` WHERE media_id = %d',
            'SELECT COUNT(*) FROM `' . $this->products() . '` WHERE main_image_id = %d',
            'SELECT COUNT(*) FROM `' . C::table($this->db, C::VARIATIONS) . '` WHERE media_id = %d',
        ];
        foreach ($counts as $sql) {
            $found = $this->db->getVar($sql, [$mediaId]);
            // A read that FAILED is not «nobody uses it». `null` here would
            // become a deletion, so it is treated as a use: the cost of
            // keeping an unused file is a file, and the cost of the other
            // answer is somebody's photograph.
            if ($found === null || (int) $found > 0) {
                return true;
            }
        }
        return false;
    }

    public function skuTaken(int $vendorUserId, string $sku, int $exceptProductId = 0): bool
    {
        if (trim($sku) === '') {
            return false;       // an empty SKU is "not set", and many may be unset
        }
        return (int) $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` WHERE vendor_user_id = %d AND sku = %s AND id <> %d',
            [$vendorUserId, $sku, $exceptProductId]
        ) > 0;
    }

    public function link(int $productId, ?int $wcProductId): bool
    {
        $value = $wcProductId === null || $wcProductId <= 0 ? 'NULL' : '%d';
        $params = [];
        if ($value === '%d') {
            $params[] = $wcProductId;
        }
        array_push($params, $this->now(), $productId);
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET wc_product_id = ' . $value . ', synced_at = %s WHERE id = %d',
            $params
        ) !== null;
    }

    /**
     * The marketplace row that OWNS this storefront product, if any.
     *
     * Scoped to owned links on purpose. This is the question the purchase
     * guard, the projector and the storefront stop all end at, and an
     * `observed` row — a Dokan product a migration merely mapped — must answer
     * "not ours" to every one of them. Before this scope existed, a dry-run
     * import made another plugin's product unpurchasable.
     */
    public function findByWcProduct(int $wcProductId): ?Product
    {
        if ($wcProductId <= 0) {
            return null;
        }
        $row = $this->db->getRow(
            'SELECT * FROM `' . $this->products() . '` WHERE wc_product_id = %d AND ' . self::OWNED,
            [$wcProductId]
        );
        return $row === null ? null : $this->hydrate($row);
    }

    /** The row that merely POINTS at this storefront product, if any. */
    public function findObservedByWcProduct(int $wcProductId): ?Product
    {
        if ($wcProductId <= 0) {
            return null;
        }
        $row = $this->db->getRow(
            'SELECT * FROM `' . $this->products() . '` WHERE wc_product_id = %d AND ' . self::OBSERVED,
            [$wcProductId]
        );
        return $row === null ? null : $this->hydrate($row);
    }

    /** @return list<Product> rows a migration mapped but nobody took over */
    public function observed(int $limit = 200): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '` WHERE ' . self::OBSERVED . ' ORDER BY id ASC LIMIT %d',
            [max(1, $limit)]
        ));
    }

    public function observedForVendorAfter(int $vendorUserId, int $afterId = 0, int $limit = 50): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '`
              WHERE vendor_user_id = %d AND id > %d AND ' . self::OBSERVED . '
              ORDER BY id ASC LIMIT ' . max(1, min(500, $limit)),
            [$vendorUserId, max(0, $afterId)]
        ));
    }

    public function stampedForVendorAfter(int $vendorUserId, int $afterId = 0, int $limit = 50): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '`
              WHERE vendor_user_id = %d AND id > %d
                AND `' . M0032ProductMirroredStatus::MIRRORED . '` IS NOT NULL
                AND `' . M0032ProductMirroredStatus::MIRRORED . "` <> ''
              ORDER BY id ASC LIMIT " . max(1, min(500, $limit)),
            [$vendorUserId, max(0, $afterId)]
        ));
    }

    public function linkOwnership(int $productId): LinkOwnership
    {
        $value = (string) $this->db->getVar(
            'SELECT ' . M0010LinkOwnership::COLUMN . ' FROM `' . $this->products() . '` WHERE id = %d',
            [$productId]
        );
        return LinkOwnership::tryFrom($value) ?? LinkOwnership::Marketplace;
    }

    public function setLinkOwnership(int $productId, LinkOwnership $ownership): bool
    {
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET ' . M0010LinkOwnership::COLUMN . ' = %s, updated_at = %s WHERE id = %d',
            [$ownership->value, $this->now(), $productId]
        ) !== null;
    }

    public function ownershipTallyForVendor(int $vendorUserId): array
    {
        // ⛔ The TOTAL first, separately, and before the breakdown.
        //
        // `getResults()` answers `[]` for «this shop has no rows» and `[]` for
        // «the statement failed» (`alpha.8`), so until this round a broken
        // read arrived as `marketplace => 0, observed => 0` — indistinguishable
        // from an empty shop, and read as fact by the `ownership_taken` gate
        // and by steps 9, 10 and 12 of the wizard. `MigrationPlanSnapshot`'s
        // own docblock promises «every absent fact arrives as `null`, never as
        // nought»; this read was the one that broke the promise.
        //
        // The count goes through the `tmc_product_owner (vendor_user_id,
        // status)` index of migration 5, so the second statement is an indexed
        // read and not a scan.
        $counted = $this->db->getVar(
            'SELECT COUNT(*) FROM `' . $this->products() . '` WHERE vendor_user_id = %d',
            [$vendorUserId]
        );
        if ($counted === null) {
            return ['marketplace' => 0, 'observed' => 0, 'readable' => false];
        }
        $rows = $this->db->getResults(
            'SELECT ' . M0010LinkOwnership::COLUMN . ' AS ownership, COUNT(*) AS rows_seen
               FROM `' . $this->products() . '` WHERE vendor_user_id = %d
              GROUP BY ' . M0010LinkOwnership::COLUMN,
            [$vendorUserId]
        );
        $tally = ['marketplace' => 0, 'observed' => 0];
        $seen = 0;
        foreach ($rows as $row) {
            // An unrecognised value counts as marketplace, matching
            // `linkOwnership()`: the column was added by migration 10 and a
            // row written before it has no value at all, which has always
            // meant «ours».
            $key = (LinkOwnership::tryFrom((string) $row['ownership']) ?? LinkOwnership::Marketplace)->value;
            $tally[$key] += (int) $row['rows_seen'];
            $seen += (int) $row['rows_seen'];
        }
        // A breakdown that does not add up to the total is a read that came up
        // short, and a tally with a hole in it is not a tally (`alpha.81`).
        $tally['readable'] = $seen === (int) $counted;
        return $tally;
    }

    public function mirrorStock(int $productId, int $stock): bool
    {
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET stock = %d, synced_at = %s WHERE id = %d',
            [$stock, $this->now(), $productId]
        ) !== null;
    }

    public function updateSeo(int $productId, ProductSeo $seo): bool
    {
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET seo_slug = %s, seo_title = %s, seo_description = %s, updated_at = %s WHERE id = %d',
            [$seo->slug, $seo->title, $seo->description, $this->now(), $productId]
        ) !== null;
    }

    public function allForVendor(int $vendorUserId): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '` WHERE vendor_user_id = %d AND ' . self::OWNED . ' ORDER BY id ASC',
            [$vendorUserId]
        ));
    }

    public function stockSummary(int $vendorUserId, int $lowThreshold): array
    {
        // One pass, three answers. `SUM(condition)` rather than three queries,
        // because three queries over the same rows can disagree with each other
        // when somebody sells something between them — and a report whose
        // «موجود» and «رو به اتمام» do not add up is worse than a slow one.
        $row = $this->db->getRow(
            'SELECT COUNT(*) AS on_sale,
                    SUM(CASE WHEN stock <= 0 THEN 1 ELSE 0 END) AS out_of_stock,
                    SUM(CASE WHEN stock > 0 AND stock < %d THEN 1 ELSE 0 END) AS low
             FROM `' . $this->products() . '`
             WHERE vendor_user_id = %d AND status = %s AND ' . self::OWNED,
            [max(1, $lowThreshold), $vendorUserId, ProductStatus::Published->value]
        );
        return [
            'on_sale' => (int) ($row['on_sale'] ?? 0),
            'out' => (int) ($row['out_of_stock'] ?? 0),
            'low' => (int) ($row['low'] ?? 0),
        ];
    }

    /**
     * Every product this marketplace has on the storefront — and only those.
     *
     * The storefront stop walks this list and drafts what it finds, so an
     * `observed` row here would mean a stop taking another plugin's product
     * off sale. That is the single most damaging thing the ownership column
     * prevents, so the scope is not optional.
     */
    public function projected(int $limit = 500): array
    {
        return array_map([$this, 'hydrate'], $this->db->getResults(
            'SELECT * FROM `' . $this->products() . '` WHERE wc_product_id IS NOT NULL AND ' . self::OWNED
            . ' ORDER BY id ASC LIMIT %d',
            [max(1, $limit)]
        ));
    }

    /**
     * The detail columns, their placeholders and their values, in one place.
     *
     * The three nullable columns choose a literal NULL instead of a
     * placeholder for the same reason the store table does: a placeholder
     * cannot carry NULL through wpdb::prepare(), and an empty string reaching
     * a DATE column is rejected by strict mode.
     *
     * @return array{0:list<string>,1:list<string>,2:list<mixed>}
     */
    private function detailColumns(ProductDetails $d): array
    {
        // `title_sort` is written HERE and nowhere else, because this is the
        // one place both `create()` and `updateDetails()` build their column
        // list from — so the form, the CSV import, a manager's correction and
        // an approved revision all maintain it without any of them knowing it
        // exists. A key written in some paths and not others is worse than no
        // key: the list would order most rows correctly and quietly misplace
        // the ones last touched by the path that forgot.
        $columns = ['title', 'title_sort', 'type', 'category_key', 'brand', 'short_description', 'price_minor'];
        $placeholders = ['%s', '%s', '%s', '%s', '%s', '%s', '%d'];
        $params = [
            $d->title,
            PersianCollation::sortKey($d->title),
            $d->type,
            $d->categoryKey,
            $d->brand,
            $d->shortDescription,
            $d->priceMinor,
        ];

        foreach ([
            ['sale_price_minor', '%d', $d->salePriceMinor],
            ['sale_from', '%s', $d->saleFrom],
            ['sale_to', '%s', $d->saleTo],
            // `description` joins these three because it shares their shape:
            // NULL is a meaning, not an absence. NULL says this product has
            // never had a long description and the storefront's own text must
            // be left alone; `''` says the vendor cleared it.
            [M0023ProductDescriptionAndCreateToken::DESCRIPTION, '%s', $d->description],
        ] as [$column, $placeholder, $value]) {
            $columns[] = $column;
            if ($value === null) {
                $placeholders[] = 'NULL';
                continue;
            }
            $placeholders[] = $placeholder;
            $params[] = $value;
        }

        $columns = array_merge($columns, ['sku', 'stock', 'min_purchase', 'weight_grams', 'dimensions', 'tax_class']);
        $placeholders = array_merge($placeholders, ['%s', '%d', '%d', '%d', '%s', '%s']);
        array_push($params, $d->sku, $d->stock, $d->minPurchase, $d->weightGrams, $d->dimensions, $d->taxClass);

        $columns[] = 'max_purchase';
        if ($d->maxPurchase === null) {
            $placeholders[] = 'NULL';
        } else {
            $placeholders[] = '%d';
            $params[] = $d->maxPurchase;
        }

        // The step travels with the two numbers it works with, so `create()`,
        // `updateDetails()`, a CSV import, a manager's correction and an
        // approved proposal all maintain it without any of them knowing it
        // exists — the same reason `title_sort` is written here and nowhere
        // else. A rule written on some paths and not others is worse than no
        // rule: most products would step correctly and the ones last touched
        // by the path that forgot would quietly stop.
        $columns[] = M0024PurchaseStep::STEP;
        $placeholders[] = '%d';
        $params[] = max(1, $d->purchaseStep);

        return [$columns, $placeholders, $params];
    }

    /** @param array<string,mixed> $row */
    private function hydrate(array $row): Product
    {
        $details = new ProductDetails(
            (string) $row['title'],
            (string) $row['type'],
            (string) $row['category_key'],
            (string) $row['brand'],
            (string) ($row['short_description'] ?? ''),
            (int) $row['price_minor'],
            $row['sale_price_minor'] === null ? null : (int) $row['sale_price_minor'],
            $row['sale_from'] === null ? null : (string) $row['sale_from'],
            $row['sale_to'] === null ? null : (string) $row['sale_to'],
            (string) $row['sku'],
            (int) $row['stock'],
            (int) $row['min_purchase'],
            $row['max_purchase'] === null ? null : (int) $row['max_purchase'],
            (int) $row['weight_grams'],
            (string) $row['dimensions'],
            (string) $row['tax_class'],
            // `??` and not `?? ''`: a row from before migration 23, and a row
            // whose column is genuinely NULL, must both arrive as `null` so
            // the projector knows nobody has asked for anything. Casting here
            // would turn «never set» into «set to empty» and empty a
            // manager's long description on the next approval.
            ($row[M0023ProductDescriptionAndCreateToken::DESCRIPTION] ?? null) === null
                ? null
                : (string) $row[M0023ProductDescriptionAndCreateToken::DESCRIPTION],
            // `?? 1` rather than `?? 0`: a row read by a build mid-upgrade —
            // or by a query written before migration 24 — has no step, and
            // «no step» is 1. Nought would be coerced back to 1 by
            // `PurchaseQuantity::of()` anyway, which is precisely why it must
            // not be written here: the coercion is a safety net, not the
            // meaning.
            (int) ($row[M0024PurchaseStep::STEP] ?? 1),
            // THE RELATIONSHIP, read from the link table — and `?? []` is not
            // a fallback here, it is the honest answer twice over. A `null`
            // from `categoryIdsFor()` means the table is absent (schema 34) or
            // the read failed; an empty array means it was read and holds
            // nothing. `ProductDetails::categorySet()` turns BOTH into «fall
            // back to the single key», which can only ever narrow, never
            // widen — the safe direction for a relationship.
            $this->categoryIdsFor((int) $row['id']) ?? []
        );
        $id = (int) $row['id'];
        return new Product(
            $id,
            (int) $row['vendor_user_id'],
            $details,
            ProductStatus::from((string) $row['status']),
            $this->specs($id),
            $this->images($id),
            (int) $row['main_image_id'],
            (string) ($row['review_note'] ?? ''),
            (int) $row['spec_schema_version'],
            $row['published_at'] === null ? null : (string) $row['published_at'],
            (string) $row['updated_at'],
            ($row['wc_product_id'] ?? null) === null ? null : (int) $row['wc_product_id'],
            new ProductSeo(
                (string) ($row['seo_slug'] ?? ''),
                (string) ($row['seo_title'] ?? ''),
                (string) ($row['seo_description'] ?? '')
            ),
            // Absent on a row read before migration 14 ran; an empty version
            // means the form carries nothing to compare and the write is
            // unguarded, which is what a mid-upgrade save needs.
            isset($row['row_version']) ? (string) (int) $row['row_version'] : '',
            // Absent before migration 19, and NULL for every product that has
            // not been approved since. `decode()` answers null for both,
            // which is the honest answer: «no record of agreement».
            ApprovedBaseline::decode(
                isset($row[M0019BaselineAndDecisions::BASELINE_COLUMN])
                    ? (string) $row[M0019BaselineAndDecisions::BASELINE_COLUMN]
                    : null
            ),
            // A query that does not select the column reads as `marketplace`,
            // matching `ownershipTallyForVendor()`'s rule for an
            // unrecognised value. It is a DISPLAY fallback and nothing more:
            // every path that decides whether this plugin may act on a
            // storefront product — the purchase policy, the stop, the
            // projector — asks its own scoped query and does not read this.
            (string) ($row[M0010LinkOwnership::COLUMN] ?? LinkOwnership::MARKETPLACE_VALUE),
            // Absent on a row read before migration 32, and NULL for every
            // row the marketplace created itself. `array_key_exists` rather
            // than `??`, because a query that did not SELECT the column and a
            // row whose column is NULL are the same answer here — «no
            // observed status» — and both must read as «the status is ours».
            // `''` is normalised to null so that one reader
            // (`storefrontStatusIsHeld()`) answers the question.
            array_key_exists(M0032ProductMirroredStatus::MIRRORED, $row)
                && trim((string) ($row[M0032ProductMirroredStatus::MIRRORED] ?? '')) !== ''
                    ? trim((string) $row[M0032ProductMirroredStatus::MIRRORED])
                    : null,
            // Whether an import made this row. Absent only on a row read
            // before migration 14, which cannot carry a Dokan mapping either,
            // so «not imported» is both the honest and the harmless answer.
            trim((string) ($row['import_run_id'] ?? '')) !== ''
        );
    }

    /**
     * Record what both sides agreed on, for the next edit to be measured from.
     *
     * Only an approval or an explicit decision calls this. A projection does
     * not: projecting is the marketplace writing, not the two sides agreeing,
     * and a baseline written on every sync would make «the vendor changed
     * this» permanently false.
     */
    public function saveBaseline(int $productId, ?ApprovedBaseline $baseline): bool
    {
        return $this->db->execute(
            'UPDATE `' . $this->products() . '` SET `' . M0019BaselineAndDecisions::BASELINE_COLUMN . '` = %s WHERE id = %d',
            [$baseline?->encode() ?? '', $productId]
        ) !== null;
    }

    public function deleteDraft(int $productId): bool
    {
        $product = $this->find($productId);
        if ($product === null || $product->status !== ProductStatus::Draft) {
            return false;
        }
        // The specs and images go with it — they are rows OF this draft, not
        // records about it. The WooCommerce post the link points at is not
        // touched: it was never ours to remove.
        $this->db->execute('DELETE FROM `' . $this->specsTable() . '` WHERE product_id = %d', [$productId]);
        $this->db->execute('DELETE FROM `' . $this->imagesTable() . '` WHERE product_id = %d', [$productId]);
        // The link rows are rows OF this draft too, and leaving them would
        // leave a relationship recorded for a product id that no longer
        // exists — and that id is reused by AUTO_INCREMENT on a fresh table.
        // Guarded, because a build on schema 34 has no such table.
        if ($this->hasCategoryTable() === true) {
            $this->db->execute(
                'DELETE FROM `' . $this->categoriesTable() . '` WHERE product_id = %d',
                [$productId]
            );
        }
        $removed = $this->db->execute('DELETE FROM `' . $this->products() . '` WHERE id = %d AND status = %s', [
            $productId,
            ProductStatus::Draft->value,
        ]);
        return $removed !== null && $removed > 0;
    }

    public function deleteObservedFromRun(int $productId, string $runId): string
    {
        if ($productId <= 0 || $runId === '') {
            return 'bad_arguments';
        }
        // The guard is the `WHERE`, not a read-then-write: between a read and
        // a delete somebody can accept the product into marketplace
        // management, and this must not remove a row the marketplace now runs.
        $removed = $this->db->execute(
            'DELETE FROM `' . $this->products() . '`
              WHERE id = %d AND import_run_id = %s AND `' . M0010LinkOwnership::COLUMN . '` = %s',
            [$productId, $runId, LinkOwnership::Observed->value]
        );
        if ($removed === null) {
            return 'product_row';
        }
        if ($removed < 1) {
            // Zero rows here is NOT the `alpha.8` success: this statement
            // deletes or it does not, so zero means the guard did not match —
            // another run's row, or one already accepted.
            return 'not_this_run';
        }
        // Rows OF the deleted row, after it rather than before: if the delete
        // above had been refused, clearing these would have emptied a product
        // that is still there. And EVERY result is read — `alpha.31`'s rule,
        // which this method was breaking: specs and images were deleted with
        // their answers thrown away, so a half-emptied row reported success.
        //
        // The caller wraps this in a transaction, so naming the part that
        // would not go is what lets the whole unit be undone rather than
        // leaving a deleted product with its images still in the table.
        foreach ([
            // The two append-only ledgers first, then the rows OF the row.
            // Their names come from the migrations that made them, because a
            // hand-written table name is a `DELETE` that silently removes
            // nothing (`alpha.10`).
            'revisions' => T::table($this->db, T::REVISIONS),
            'decisions' => M0019BaselineAndDecisions::table($this->db, M0019BaselineAndDecisions::DECISIONS),
            'specs' => $this->specsTable(),
            'images' => $this->imagesTable(),
        ] + ($this->hasCategoryTable() === true ? ['categories' => $this->categoriesTable()] : [])
         as $part => $table) {
            if ($this->db->execute('DELETE FROM `' . $table . '` WHERE product_id = %d', [$productId]) === null) {
                return (string) $part;
            }
        }
        return '';
    }

    private function products(): string
    {
        return T::table($this->db, T::PRODUCTS);
    }

    private function specsTable(): string
    {
        return T::table($this->db, T::PRODUCT_SPECS);
    }

    private function imagesTable(): string
    {
        return T::table($this->db, T::PRODUCT_IMAGES);
    }

    private function now(): string
    {
        return $this->clock->now()->format('Y-m-d H:i:s');
    }
}
